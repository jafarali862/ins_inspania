@extends('dashboard.layout.app')
@section('title', 'Add Company')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-plus me-2 text-primary"></i> Add User
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('company.list') }}">Companies</a></li>
                    <li class="breadcrumb-item active">Add Company</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-plus me-2"></i>
                            <h5 class="mb-0">Add Company</h5>
                            

                              <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none">
    <i class="fa fa-check-circle me-2"></i>
    <span id="successText"></span>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
                        </div>



                        
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                           
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Add User Form -->
                     <!-- Add User Form -->
                    

              <form id="companyForm" method="POST" action="{{ route('companies.store') }}" novalidate>
    @csrf

    <!-- Company Name -->
    <div class="mb-3">
        <label for="name" class="form-label fw-bold">Company Name <span class="text-danger">*</span></label>
        <input type="text" 
               class="form-control" 
               id="name" 
               name="name" 
               value="{{ old('name') }}" 
               placeholder="Enter company name" 
               required>
        <span id="name-error" class="text-danger error"></span>
    </div>

    <!-- Tabs for Insurance Types -->
    <!-- <div class="card mb-3">
        <div class="card-header p-2">
            <ul class="nav nav-pills">
                <li class="nav-item"><a class="nav-link" href="#garage" data-toggle="tab">Garage Data</a></li>
                <li class="nav-item"><a class="nav-link" href="#driver" data-toggle="tab">Driver Data</a></li>
                <li class="nav-item"><a class="nav-link" href="#spot" data-toggle="tab">Spot Data</a></li>
                <li class="nav-item"><a class="nav-link" href="#meeting" data-toggle="tab">Owner Data</a></li>
                <li class="nav-item"><a class="nav-link" href="#accident" data-toggle="tab">Accident Data</a></li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div class="tab-pane" id="garage"></div>
                <div class="tab-pane" id="driver"></div>
                <div class="tab-pane" id="spot"></div>
                <div class="tab-pane" id="meeting"></div>
                <div class="tab-pane" id="accident"></div>
            </div>
        </div>
    </div> -->


    <div class="card mb-3">
    <div class="card-header p-2">
        <ul class="nav nav-pills" id="questionTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="garage-tab" data-bs-toggle="tab" href="#garage" role="tab" aria-controls="garage" aria-selected="false">Garage Data</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="driver-tab" data-bs-toggle="tab" href="#driver" role="tab" aria-controls="driver" aria-selected="false">Driver Data</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="spot-tab" data-bs-toggle="tab" href="#spot" role="tab" aria-controls="spot" aria-selected="false">Spot Data</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="meeting-tab" data-bs-toggle="tab" href="#meeting" role="tab" aria-controls="meeting" aria-selected="false">Owner Data</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="accident-tab" data-bs-toggle="tab" href="#accident" role="tab" aria-controls="accident" aria-selected="false">Accident Data</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="questionTabsContent">
            <div class="tab-pane fade" id="garage" role="tabpanel" aria-labelledby="garage-tab"></div>
            <div class="tab-pane fade" id="driver" role="tabpanel" aria-labelledby="driver-tab"></div>
            <div class="tab-pane fade" id="spot" role="tabpanel" aria-labelledby="spot-tab"></div>
            <div class="tab-pane fade" id="meeting" role="tabpanel" aria-labelledby="meeting-tab"></div>
            <div class="tab-pane fade" id="accident" role="tabpanel" aria-labelledby="accident-tab"></div>
        </div>
    </div>
</div>


    <!-- Contact Person -->
    <div class="mb-3">
        <label for="contact_person" class="form-label fw-bold">Contact Person <span class="text-danger">*</span></label>
        <input type="text" 
               class="form-control" 
               id="contact_person" 
               name="contact_person" 
               value="{{ old('contact_person') }}"
               placeholder="Enter contact person" 
               required>
        <span id="contact_person-error" class="text-danger error"></span>
    </div>

    <!-- Phone Number -->
    <div class="mb-3">
        <label for="phone" class="form-label fw-bold">Phone Number <span class="text-danger">*</span></label>
        <input type="tel" 
               class="form-control" 
               id="phone" 
               name="phone" 
               value="{{ old('phone') }}"
               placeholder="Enter phone number" 
               required>
        <span id="phone-error" class="text-danger error"></span>
    </div>

    <!-- Email Address -->
    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
        <input type="email" 
               class="form-control" 
               id="email" 
               name="email" 
               value="{{ old('email') }}"
               placeholder="Enter email address" 
               required>
        <span id="email-error" class="text-danger error"></span>
    </div>

    <!-- Address -->
    <div class="mb-3">
        <label for="address" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
        <textarea class="form-control" 
                  id="address" 
                  name="address" 
                  rows="3" 
                  placeholder="Enter address" 
                  required>{{ old('address') }}</textarea>
        <span id="address-error" class="text-danger error"></span>
    </div>

    <!-- Select Final Report Template -->
    <div class="mb-3">
        <label for="selectTemplate" class="form-label fw-bold">Select Final Report Template <span class="text-danger">*</span></label>
        <select class="form-control" 
                id="selectTemplate" 
                name="template" 
                required>
            <option value="" disabled selected>Please select</option>
            @for ($i = 1; $i <= 8; $i++)
                <option value="{{ $i }}" {{ old('template') == $i ? 'selected' : '' }}>Template {{ $i }}</option>
            @endfor
        </select>
        <span id="template-error" class="text-danger error"></span>
    </div>

    <div class="text-left">
        <button type="submit" class="btn btn-success">Add Company</button>
    </div>
</form>

        </div>
        </div>
        </div>
        </div>

<style>

.card-secondary:not(.card-outline)>.card-header a.active
{
color:#fff;
}

.nav-pills .nav-link {
    color: #000000;
    font-weight: 550;
}

</style>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>




<script>
    const categoryMap = {
        'garage': 'garage_data',
        'driver': 'driver_data',
        'spot': 'spot_data',
        'meeting': 'owner_data',
        'accident': 'accident_person_data',
    };

    document.addEventListener('DOMContentLoaded', () => {
        const tabs = document.querySelectorAll('a[data-bs-toggle="tab"]');

        tabs.forEach(tab => {
            tab.addEventListener('shown.bs.tab', async (event) => {
                const tabId = event.target.getAttribute('href').substring(1); // e.g. "garage"
                const dataCategory = categoryMap[tabId];
                const tabPane = document.getElementById(tabId);

                // If already loaded, skip
                if (tabPane.dataset.loaded) return;

                try {
                    const res = await fetch(`/questions/${dataCategory}`);
                    if (!res.ok) throw new Error('Network error');
                    const questions = await res.json();

                    let html = `<h5 class="mb-3 fw-bold text-primary text-uppercase">${dataCategory.replace(/_/g, ' ')}</h5>`;

                    questions.forEach(q => {
                        const colId = `check_${q.column_name}`;
                        const isFile = q.input_type === 'file';

                        let fileTypeInput = '';
                        if (isFile && q.file_type) {
                            fileTypeInput = `<input type="hidden" name="file_types[${tabId}][${q.column_name}]" value="${q.file_type}">`;
                        }

                        html += `
                            <div class="form-check mb-2">
                                <input class="form-check-input" style="border-color: #424141;" type="checkbox" name="selected_questions[${tabId}][]" value="${q.column_name}" id="${colId}">
                                <input type="hidden" name="question_types[${tabId}][${q.column_name}]" value="${q.input_type}">
                                ${fileTypeInput}
                                <label class="form-check-label" for="${colId}">${q.question}</label>
                            </div>`;
                    });

                    tabPane.innerHTML = html;
                    tabPane.dataset.loaded = true;

                } catch (error) {
                    tabPane.innerHTML = `<div class="alert alert-danger">Failed to load questions. Please try again later.</div>`;
                }
            });
        });

        // Form validation to ensure at least one checkbox checked across all tabs
        const companyForm = document.getElementById('companyForm');
        companyForm.addEventListener('submit', (e) => {
            const categories = Object.keys(categoryMap);
            let hasChecked = false;

            for (const cat of categories) {
                const checkboxes = companyForm.querySelectorAll(`input[name="selected_questions[${cat}][]"]`);
                if ([...checkboxes].some(chk => chk.checked)) {
                    hasChecked = true;
                    break;
                }
            }

            if (!hasChecked) {
                e.preventDefault();
                // Use Bootstrap 5 alert or modal for better UX; here simple alert for demo
                alert("Please select at least one checkbox in any category.");
            }
        });
    });
</script>


<script>
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#companyForm').on('submit', function (e) {
            e.preventDefault();

            $.ajax({
                url: '{{ route('companies.store') }}',
                type: 'POST',
                data: $(this).serialize(),
              success: function (response) {
    if (response.success) {
        $('#successMessage')
            .removeClass('d-none alert-danger')
            .addClass('alert alert-success')
            .fadeIn();
        $('#successText').text(response.success);
       $('html, body').animate({
        scrollTop: $("#successMessage").offset().top - 100
    }, 500);
        // Reset form
        $('#companyForm')[0].reset();
        $('.form-control').removeClass('is-invalid');
        $('.error').text('');

        setTimeout(function () {
            window.location.href = response.redirect_url;
        }, 2500);
    }
},

                error: function (xhr) {
                    if (xhr.status === 422) {
                        var errors = xhr.responseJSON.errors;

                        $('.error').text('');
                        $('.form-control').removeClass('is-invalid');

                        $.each(errors, function (key, value) {
                            $('#' + key).addClass('is-invalid');
                            $('#' + key + '-error').text(value[0]);
                        });
                    }
                }
            });
        });
    });
</script>


@endsection
