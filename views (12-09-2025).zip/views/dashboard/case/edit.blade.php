@extends('dashboard.layout.app')
@section('title', 'Edit Insurance Customer')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-edit me-2 text-primary"></i> Edit Case
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="">Case</a></li>
                    <li class="breadcrumb-item active">Edit Case</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
        <div class="col-lg-8 col-md-10">
        <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
        <i class="fa fa-user-edit me-2"></i>
        <h5 class="mb-0">Edit Case</h5>

        <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
        style="margin-left: 20px;align-items: center;">
        <i class="fa fa-check-circle me-2"></i>
        <span id="successText"></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
        </div>
        <!-- Action Buttons -->
        <div class="d-flex gap-2">
        <a href="{{ route('user.list') }}" class="btn btn-danger btn-sm">
        <i class="fa fa-arrow-left me-1"></i> Back
        </a>
        <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
        <i class="fa fa-sync me-1"></i> Reload
        </a>
        </div>
        </div>
        <div class="card-body">

              

               <form id="insuranceForm" action="{{ route('case.update', $customers->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <div class="card-body">
        <!-- Company -->
        <div class="mb-3">
            <label for="company" class="form-label fw-bold">Select Company <span class="text-danger">*</span></label>
            <select id="company" name="company" class="form-select" required>
                <option disabled>Select Company</option>
                @foreach ($companies as $company)
                    <option value="{{ $company->id }}" {{ $customers->company_id == $company->id ? 'selected' : '' }}>
                        {{ $company->name }}
                    </option>
                @endforeach
            </select>
            <span id="company-error" class="text-danger error"></span>
        </div>

        <!-- Name -->
        <div class="mb-3">
            <label for="name" class="form-label fw-bold">Name <span class="text-danger">*</span></label>
            <input type="text" id="name" name="name" class="form-control" placeholder="Enter full name" value="{{ $customers->name }}" required>
            <span id="name-error" class="text-danger error"></span>
        </div>

        <!-- Father's Name -->
        <div class="mb-3">
            <label for="father_name" class="form-label fw-bold">Father's Name <span class="text-danger">*</span></label>
            <input type="text" id="father_name" name="father_name" class="form-control" placeholder="Enter father's name" value="{{ $customers->father_name }}" required>
            <span id="father_name-error" class="text-danger error"></span>
        </div>

        <!-- Phone -->
        <div class="mb-3">
            <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
            <input type="text" id="phone" name="phone" class="form-control" placeholder="Enter phone number" value="{{ $customers->phone }}" required>
            <span id="phone-error" class="text-danger error"></span>
        </div>

        <div class="form-check mb-3">
            <input type="checkbox" id="same_as_phone" class="form-check-input">
            <label class="form-check-label text-primary" for="same_as_phone">
                Emergency contact number same as phone
            </label>
        </div>

        <!-- Emergency Contact -->
        <div class="mb-3">
            <label for="emergency_contact_number" class="form-label fw-bold">Emergency Contact Number <span class="text-danger">*</span></label>
            <input type="text" id="emergency_contact_number" name="emergency_contact_number" class="form-control" placeholder="Enter emergency contact number" value="{{ $customers->emergency_contact_number }}" required>
            <span id="emergency_contact_number-error" class="text-danger error"></span>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label fw-bold">Email</label>
            <input type="email" id="email" name="email" class="form-control" placeholder="Enter email address" value="{{ $customers->email }}">
            <span id="email-error" class="text-danger error"></span>
        </div>

        <!-- Present Address -->
        <div class="mb-3">
            <label for="present_address" class="form-label fw-bold">Present Address <span class="text-danger">*</span></label>
            <textarea id="present_address" name="present_address" class="form-control" rows="3" placeholder="Enter present address" required>{{ $customers->present_address }}</textarea>
            <span id="present_address-error" class="text-danger error"></span>
        </div>

        <div class="form-check mb-3">
            <input type="checkbox" id="same_as_present" class="form-check-input">
            <label class="form-check-label text-primary" for="same_as_present">
                Present address same as permanent address
            </label>
        </div>

        <!-- Permanent Address -->
        <div class="mb-3">
            <label for="permanent_address" class="form-label fw-bold">Permanent Address <span class="text-danger">*</span></label>
            <textarea id="permanent_address" name="permanent_address" class="form-control" rows="3" placeholder="Enter permanent address" required>{{ $customers->permanent_address }}</textarea>
            <span id="permanent_address-error" class="text-danger error"></span>
        </div>

        <!-- Insurance Type -->
        <div class="mb-3">
            <label for="insurance_type" class="form-label fw-bold">Insurance Type <span class="text-danger">*</span></label>
            <input type="text" id="insurance_type" name="insurance_type" class="form-control" placeholder="Enter insurance type" value="{{ $customers->ins_type }}" required>
            <span id="insurance_type-error" class="text-danger error"></span>
        </div>

        <!-- Case Details -->
        <div class="mb-3">
            <label for="case_details" class="form-label fw-bold">Case Details <span class="text-danger">*</span></label>
            <textarea id="case_details" name="case_details" class="form-control" rows="3" placeholder="Enter case details" required>{{ $customers->case_details }}</textarea>
            <span id="case_details-error" class="text-danger error"></span>
        </div>

        <!-- Crime Number -->
        <div class="mb-3">
            <label for="crime_no" class="form-label fw-bold">Crime Number <span class="text-danger">*</span></label>
            <input type="text" id="crime_no" name="crime_no" class="form-control" placeholder="Enter crime number" value="{{ $customers->crime_number }}" required>
            <span id="crime_no-error" class="text-danger error"></span>
        </div>

        <!-- Police Station -->
        <div class="mb-3">
            <label for="police_station" class="form-label fw-bold">Police Station <span class="text-danger">*</span></label>
            <input type="text" id="police_station" name="police_station" class="form-control" placeholder="Enter police station" value="{{ $customers->police_station }}" required>
            <span id="police_station-error" class="text-danger error"></span>
        </div>

        <!-- Policy No -->
        <div class="mb-3">
            <label for="policy_no" class="form-label fw-bold">Policy No <span class="text-danger">*</span></label>
            <input type="text" id="policy_no" name="policy_no" class="form-control" placeholder="Enter policy number" value="{{ $customers->policy_no }}" required>
            <span id="policy_no-error" class="text-danger error"></span>
        </div>

        <!-- Policy Dates -->
        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="policy_start" class="form-label fw-bold">Policy Start Date <span class="text-danger">*</span></label>
                <input type="date" id="policy_start" name="policy_start" class="form-control" value="{{ $customers->policy_start }}" required>
            </div>
            <div class="mb-3 col-md-6">
                <label for="policy_end" class="form-label fw-bold">Policy End Date</label>
                <input type="date" id="policy_end" name="policy_end" class="form-control" value="{{ $customers->policy_end }}">
            </div>
        </div>

        <!-- Intimation Report -->
        <div class="mb-3">
            <label for="intimation_report" class="form-label fw-bold">Intimation Report</label>
            <input type="file" name="intimation_report" class="form-control">
            @if (!empty($customers->intimation_report))
                <div class="mt-2">
                    <a href="{{ asset('storage/' . $customers->intimation_report) }}" target="_blank">View Existing Report</a>
                </div>
            @endif
        </div>

        <!-- Investigation Type -->
        <div class="mb-3">
            <label for="investigation_type" class="form-label fw-bold">Investigation Type <span class="text-danger">*</span></label>
            <select name="investigation_type" id="investigation_type" class="form-select" required>
                <option value="OD" {{ $customers->insurance_type == 'OD' ? 'selected' : '' }}>OD</option>
                <option value="MACT" {{ $customers->insurance_type == 'MACT' ? 'selected' : '' }}>MACT</option>
            </select>
        </div>

        <!-- Executives -->
        <div class="mb-3">
            <label for="executive_1" class="form-label fw-bold">Default Executive <span class="text-danger">*</span></label>
            <select name="Default_Executive" id="executive_1" class="form-select" required>
                <option disabled>Select the executive</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}" {{ $user->id == $customers->meeting_id ? 'selected' : '' }}>
                        {{ $user->name }} ({{ $user->place }})
                    </option>
                @endforeach
            </select>
        </div>

        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="executive_2" class="form-label fw-bold">Executive (Driver)</label>
                <select name="executive_driver" id="executive_2" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customers->driver_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3 col-md-6">
                <label for="executive_3" class="form-label fw-bold">Executive (Garage)</label>
                <select name="executive_garage" id="executive_3" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customers->garage_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="executive_4" class="form-label fw-bold">Executive (Spot)</label>
                <select name="executive_spot" id="executive_4" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customers->spot_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3 col-md-6">
                <label for="executive_5" class="form-label fw-bold">Executive (Meeting)</label>
                <select name="executive_meeting" id="executive_5" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customers->meeting_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        @if($customers->case_type=="MACT")
        <div class="mb-3">
            <label for="executive_6" class="form-label fw-bold">Executive (Accident Person)</label>
            <select name="executive_accident_person" id="executive_6" class="form-select">
                <option disabled>Select the executive</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}" {{ $user->id == $customers->accident_id ? 'selected' : '' }}>
                        {{ $user->name }} ({{ $user->place }})
                    </option>
                @endforeach
            </select>
        </div>
        @endif

        <!-- Investigation Date -->
        <div class="mb-3">
            <label for="date" class="form-label fw-bold">Investigation Date <span class="text-danger">*</span></label>
            <input type="date" name="date" id="date" class="form-control" value="{{ $customers->case_date }}" required>
        </div>

        <!-- Other Details -->
        <div class="mb-3">
            <label for="other" class="form-label fw-bold">Other Details</label>
            <textarea name="other" id="other" class="form-control" rows="4" placeholder="Enter other details">{{ $customers->case_other }}</textarea>
        </div>
    </div>

    <!-- Submit -->
    <div class="card-footer text-left">
        <button type="submit" class="btn btn-success">Update Customer</button>
    </div>
</form>

            </div>
        </div>
    </div>
</div>




    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->

@push('styles')
<!-- AdminLTE DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" />
@endpush


<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->


 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   
    <script>
       
            // Handle checkbox for emergency contact number
            $('#same_as_phone').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#emergency_contact_number').val($('#phone').val());
                } else {
                    $('#emergency_contact_number').val('');
                }
            });

            // Handle checkbox for addresses
            $('#same_as_present').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#permanent_address').val($('#present_address').val());
                } else {
                    $('#permanent_address').val('');
                }
            });

            // Handle form submission


      $('#insuranceForm').on('submit', function(e) {
    e.preventDefault();

    let form = $(this)[0];
    let formData = new FormData(form);

    $.ajax({
        url: form.action,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            if (response.success) {
                // $('#successMessage').text(response.success).show();

                $('#successMessage')
                .text(response.success)
                .fadeIn();

                // Scroll to the success message
                $('html, body').animate({
                scrollTop: $('#successMessage').offset().top - 100 // adjust offset as needed
                }, 500);

                $('#insuranceForm')[0].reset(); 
                $('.text-danger').text(''); 
                $('#same_as_phone').prop('checked', false); 
                $('#same_as_present').prop('checked', false); 

                if (response.redirect_url) {
                    setTimeout(function() {
                        window.location.href = response.redirect_url;
                    }, 2000);
                }
            }
        },
        error: function(xhr) {
            $('.text-danger').text(''); // Clear previous error messages

            if (xhr.responseJSON && xhr.responseJSON.errors) {
                $.each(xhr.responseJSON.errors, function(key, value) {
                    $('#' + key + '-error').text(value[0]);
                });
            } else if (xhr.responseJSON && xhr.responseJSON.message) {
                alert("Error: " + xhr.responseJSON.message);
            } else {
                alert("An unknown error occurred.");
                console.log(xhr.responseText);
            }
        }
    });
});


            

    //         $(document).ready(function() {
    //         $('#caseForm').on('submit', function(e) {
    //             e.preventDefault();

    //             $.ajax({
    //                 url: '{{ route('store.case') }}',
    //                 type: 'POST',
    //                 data: $(this).serialize(),
    //                 success: function(response) {
    //                     if (response.success) {
    //                         $('#successMessage').text(response.success).show();
    //                         $('#caseForm')[0].reset(); // Reset form fields
    //                         $('.text-danger').text(''); // Clear previous error messages
    //                     }
    //                 },
    //                 error: function(xhr) {
    //                     var errors = xhr.responseJSON.errors;
    //                     $('.text-danger').text(''); // Clear previous error messages
    //                     $.each(errors, function(key, value) {
    //                         $('#' + key + '-error').text(value);
    //                     });
    //                 }
    //             });
    //         });
    //     });
     
    //     var accident = $('#accident');
    //     var insPerson = <?php echo json_encode($insuranceCustomer); ?>;
    //         if (insPerson.insurance_type === 'MAC') 
    //         {
    //             accident.show();
    //         } else {
    //             accident.hide();
    //         }
    //         $('#sub-executive-group').hide();
    
    // function exe1(){
    //     var insPerson = <?php echo json_encode($insuranceCustomer); ?>;
    //     var exe1=$('#executive_1').val();
    //     var exe2=$('#executive_2');
    //     var exe3=$('#executive_3');
    //     var exe4=$('#executive_4');
    //     var exe5=$('#executive_5');
    //     var exe6=$('#executive_6');
    //     var accident=$('#accident');
    //     console.log(exe1);
    //     if(exe1!=''){
    //     $('#sub-executive-group').show();
    //     exe2.val(exe1);
    //     exe3.val(exe1);
    //     exe4.val(exe1);
    //     exe5.val(exe1);
    //     if (insPerson.insurance_type === 'MAC') 
    //         {
    //             accident.show();
    //             exe6.val(exe1);
    //         } else {
    //             accident.hide();
    //             exe6.val('');
    //         }

    //     }else{
    //         $('#sub-executive-group').hide(); 
    //     }
    // }
        
    </script>
@endsection
