@extends('dashboard.layout.app')
@section('title', 'List Templates')

@section('content')


<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-clipboard me-2 text-primary"></i> Templates List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Templates</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('templates.create_templates') }}" class="btn btn-primary">
                <i class="fas fa-clipboard me-1"></i> Add Template
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Templates List</h5>
            </div>

            <div class="card-body p-0">
                @if($templates->isEmpty())
                    <div class="p-4 text-center text-muted fst-italic">
                        No templates found.
                    </div>
                @else
                    <div class="table-responsive p-3 mb-3">
                        <table id="templatesTable" class="table table-bordered table-hover text-center align-middle mb-0" style="width:100%">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Template ID</th>
            <th>Questions</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($templates as $template)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $template->template_id }}</td>
                <td>
                    <ul class="text-start m-0 p-0" style="list-style: disc inside;">
                        @foreach($template->questions as $question)
                            <li>
                                {{ $question->question }}
                                <small class="text-muted">({{ $question->data_category }})</small>
                            </li>
                        @endforeach
                    </ul>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary preview-btn" data-id="{{ $template->id }}">
                        <i class="fas fa-eye"></i> Preview
                    </button>

                    <a href="{{ route('templates.edit_templates', $template->id) }}" class="btn btn-sm btn-info">
                        <i class="fas fa-edit"></i> Edit
                    </a>

                    <form action="{{ route('templates.destroy_templates', $template->id) }}" 
                          method="POST" 
                          style="display:inline;" 
                          onsubmit="return confirm('Are you sure?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash-alt"></i> Delete
                        </button>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>

                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title">Template Preview</h5>
                <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content loaded dynamically -->
            </div>
        </div>
    </div>
</div>




<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
 <script>
    $(document).ready(function () {
        const table = $('#questionsTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search templates..."
                },
                columnDefs: [
                    { orderable: false, targets: [3] } // Action column (4th column = index 3)
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }
    });
</script>



<script>
$(document).on("click", ".preview-btn", function () {
    let templateId = $(this).data("id");
    let url = "{{ route('templates.preview', ':id') }}".replace(":id", templateId);

    $("#previewContent").html('<div class="text-center text-muted">Loading...</div>');

    let modalEl = document.getElementById('previewModal');
    let modal = new bootstrap.Modal(modalEl);
    modal.show();

    $.get(url, function (data) {
        $("#previewContent").html(data);
    }).fail(function () {
        $("#previewContent").html('<div class="text-danger">Error loading preview</div>');
    });
});

$(document).ready(function() {
    $('#templatesTable').DataTable({
        paging: true,
        lengthChange: true,
        searching: true,
        ordering: true,
        info: true,
        autoWidth: false,
        responsive: true,
        pageLength: 10,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search questions..."
        },
        columnDefs: [
            { orderable: false, targets: 3 } // Disable ordering on Actions column
        ],
    });
});
</script>
@endsection