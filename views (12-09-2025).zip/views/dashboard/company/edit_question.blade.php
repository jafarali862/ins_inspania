@extends('dashboard.layout.app')
@section('title', 'Edit Company')

@section('content')
    <div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-question-circle me-2 text-primary"></i> Edit Questionnaire
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('questions.index_question') }}">Questionnaire</a></li>
                    <li class="breadcrumb-item active">Edit Questionnaire</li>
                </ol>
            </div>
        </div>

        <!-- Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-question-circle me-2"></i>
                            <h5 class="mb-0">Edit Questionnaire</h5>

                            <!-- Success Message -->
                            <div id="successMessage" 
                                 class="alert alert-success alert-dismissible fade show mb-3 d-none ms-3" 
                                 style="align-items: center;">
                                <i class="fa fa-check-circle me-2"></i>
                                <span id="successText"></span>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="{{ route('questions.index_question') }}" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('questions.update_question', $question->id) }}" method="POST" id="updateQuestionForm" novalidate>
                            @csrf
                            @method('PUT')

                            <!-- Question -->
                            <div class="mb-3">
                                <label for="question" class="form-label fw-bold">Question <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control" 
                                       id="question" 
                                       name="question" 
                                       value="{{ old('question', $question->question) }}" 
                                       placeholder="Enter question" 
                                       required>
                                <span class="text-danger error" id="question-error"></span>
                            </div>

                            <!-- Input Type -->
                       <div class="mb-3">
    <label for="input_type" class="form-label fw-bold">Input Type <span class="text-danger">*</span></label>

    <!-- Hidden input to actually submit the value -->
    <input type="hidden" name="input_type" value="{{ old('input_type', $question->input_type) }}">

    <!-- Disabled select just for display -->
    <select class="form-control" id="input_type_display" disabled>
        @foreach(['text', 'textarea', 'select', 'file', 'date'] as $type)
            <option value="{{ $type }}" {{ old('input_type', $question->input_type) === $type ? 'selected' : '' }}>
                {{ ucfirst($type) }}
            </option>
        @endforeach
    </select>

    @error('input_type')
        <span class="text-danger">{{ $message }}</span>
    @enderror
</div>


                            <!-- Data Category -->
                            <div class="mb-3">
                                <label for="data_category" class="form-label fw-bold">Data Category <span class="text-danger">*</span></label>
                                <select class="form-control" id="data_category" name="data_category" required>
                                    @foreach(['garage_data', 'spot_data', 'owner_data', 'driver_data', 'accident_person_data'] as $cat)
                                        <option value="{{ $cat }}" {{ old('data_category', $question->data_category) == $cat ? 'selected' : '' }}>
                                            {{ ucfirst(str_replace('_', ' ', $cat)) }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="text-danger error" id="data_category-error"></span>
                            </div>

                            <!-- Buttons -->
                            <button type="submit" class="btn btn-success">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                            <a href="{{ route('questions.index_question') }}" class="btn btn-secondary">
                                <i class="fa fa-times me-1"></i> Cancel
                            </a>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

@push('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $('#updateQuestionForm').on('submit', function(e) {
        e.preventDefault();
        $('.text-danger').text('');
        $('#successMessage').hide().text('');

        const form = $(this);
        const actionUrl = form.attr('action');

        $.ajax({
            url: actionUrl,
            type: 'POST',
            data: form.serialize(),
            success: function(response) {
            if (response.success) {
            // Show the message
            $('#successMessage').text(response.success).fadeIn();

            // Wait 3 seconds, then redirect
            setTimeout(function() {
            window.location.href = response.redirect_url;
            }, 3000);
            }
            },

            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(field, messages) {
                        $('#' + field + '-error').text(messages[0]);
                    });
                } else {
                    alert('An unexpected error occurred.');
                }
            }
        });
    });
});
</script>
@endpush
@endsection
