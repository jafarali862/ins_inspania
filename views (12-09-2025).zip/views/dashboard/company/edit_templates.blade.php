@extends('dashboard.layout.app')
@section('title', 'Edit Templates')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-edit me-2 text-primary"></i> Edit Template
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('templates.list_templates') }}">Templates</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>

        <!-- Template Edit Form -->
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Update Template</h5>
                    </div>

                    <div class="card-body">
                       <form method="POST" action="{{ route('templates.update_templates', $template->id) }}">
    @csrf
    {{-- @method('PUT') --}}


    <!-- Nav Tabs -->
    <ul class="nav nav-tabs" id="questionTabs" role="tablist">
        @foreach($questions as $category => $group)
            <li class="nav-item" role="presentation">
                <button class="nav-link {{ $loop->first ? 'active' : '' }}"
                        id="{{ $category }}-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#{{ $category }}"
                        type="button"
                        role="tab"
                        aria-controls="{{ $category }}"
                        aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                    {{ ucfirst(str_replace('_', ' ', $category)) }}
                </button>
            </li>
        @endforeach
    </ul>

    <!-- Tab Content -->
    <div class="tab-content mt-3" id="questionTabsContent">
        @foreach($questions as $category => $group)
            <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}"
                 id="{{ $category }}"
                 role="tabpanel"
                 aria-labelledby="{{ $category }}-tab">

                <div class="row">
                    @foreach($group as $question)
                        <div class="col-md-6 mb-2">
                            <div class="form-check">
                                <input class="form-check-input"
                                       type="checkbox"
                                       style="border-color: #424141;"
                                       name="questions[]"
                                       value="{{ $question->id }}"
                                       id="q{{ $question->id }}"
                                       {{ in_array($question->id, $template->questions->pluck('id')->toArray()) ? 'checked' : '' }}>
                                <label class="form-check-label" for="q{{ $question->id }}">
                                    {{ $question->question }}
                                </label>
                            </div>
                        </div>
                    @endforeach
                </div>

            </div>
        @endforeach
    </div>

    <div class="mt-4">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-save me-1"></i> Update Template
        </button>
        <a href="{{ route('templates.list_templates') }}" class="btn btn-secondary">
            <i class="fa fa-times me-1"></i> Cancel
        </a>
    </div>
</form>

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div>
        </div>
    </div>
</div>



 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>

    $(document).ready(function() {
    $('#updateCompany').on('submit', function(e) {
    e.preventDefault();

    const form = $(this);
    const actionUrl = form.attr('action'); // Uses route with ID included

    $.ajax({
    url: actionUrl,
    type: 'POST', // or 'PUT' if you're not spoofing it via hidden method
    data: form.serialize(),
    success: function(response) {
    if (response.success) {
    $('#successMessage').text(response.success).show();
    $('.text-danger').text('');
    }
    }
    });
    });
    });

    </script>
  @endsection
