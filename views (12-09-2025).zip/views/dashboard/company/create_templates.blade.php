@extends('dashboard.layout.app')
@section('title', 'Create Template')

@section('content')
    <div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-plus me-2 text-primary"></i> Add Templates
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('templates.list_templates') }}">Templates</a></li>
                    <li class="breadcrumb-item active">Add Templates</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-plus me-2"></i>
                            <h5 class="mb-0">Add Templates</h5>
                            

                              <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none">
    <i class="fa fa-check-circle me-2"></i>
    <span id="successText"></span>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
                        </div>



                        
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                           
                        </div>
                    </div>

                <div class="card">
    <div class="card-header">
        <h5 class="mb-0">Create New Template</h5>
    </div>

    <div class="card-body">
        <!-- Template creation form -->
        <form method="POST" action="{{ route('templates.store_templates') }}">
            @csrf

            <!-- Nav Tabs -->
            <ul class="nav nav-tabs" id="questionTabs" role="tablist">
                @foreach($questions as $category => $group)
                    <li class="nav-item" role="presentation">
                        <button class="nav-link {{ $loop->first ? 'active' : '' }}"
                                id="{{ $category }}-tab"
                                data-bs-toggle="tab"
                                data-bs-target="#{{ $category }}"
                                type="button"
                                role="tab"
                                aria-controls="{{ $category }}"
                                aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                            {{ ucfirst(str_replace('_', ' ', $category)) }}
                        </button>
                    </li>
                @endforeach
            </ul>

            <!-- Tab Content -->
            <div class="tab-content mt-3" id="questionTabsContent">
                @foreach($questions as $category => $group)
                    <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}"
                         id="{{ $category }}"
                         role="tabpanel"
                         aria-labelledby="{{ $category }}-tab">

                        <div class="row">
                            @foreach($group as $question)
                                <div class="col-md-6 mb-2">
                                    <div class="form-check">
                                        <input class="form-check-input"
                                               type="checkbox" style="border-color: #424141;"
                                               name="questions[]"
                                               value="{{ $question->id }}"
                                               id="q{{ $question->id }}">
                                        <label class="form-check-label" for="q{{ $question->id }}">
                                            {{ $question->question }}
                                        </label>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                    </div>
                @endforeach
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">Create Template</button>
            </div>
        </form>
    </div>
</div>



    </div>
    </div>
    </div>
    </div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

@endsection
