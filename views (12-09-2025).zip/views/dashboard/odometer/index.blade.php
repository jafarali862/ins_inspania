@extends('dashboard.layout.app')

@section('title', 'Odometer List')

@section('content')


<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-road me-2 text-primary"></i> Odometer List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Odometer List</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('odometer.list') }}" class="btn btn-primary">
                <i class="fa-solid fa-list me-1"></i> Odometer List
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Odometer</h5>
            </div>

            <div class="card-body">

                <!-- Filter Form -->
                <!-- <form method="GET" class="row g-3 justify-content-end mb-4" id="filterForm">
                    <div class="col-auto">
                        <label for="from_date" class="form-label mb-0">From Date</label>
                        <input type="date" id="from_date" name="from_date" class="form-control"
                            value="{{ request()->from_date }}">
                    </div>
                    <div class="col-auto">
                        <label for="to_date" class="form-label mb-0">To Date</label>
                        <input type="date" id="to_date" name="to_date" class="form-control"
                            value="{{ request()->to_date }}">
                    </div>
                    <div class="col-auto d-flex align-items-end gap-2">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="{{ route('odometer.list') }}" class="btn btn-secondary">Reset</a>
                    </div>
                </form> -->

                <!-- Table -->
                <div class="table-responsive">
                    <table id="odometerTable" class="table table-bordered table-striped table-hover align-middle">
                        <thead class="thead-dark text-center">
                            <tr>
                                <th>S.No</th>
                                <th>Name</th>
                                <th>Check In Time</th>
                                <th>Check Out Time</th>
                                <th>Date</th>
                                <th>View</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($odometerRecords as $record)
                                <tr class="text-center">
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $record->user_name }}</td>
                                    <td>{{ $record->check_in_time }}</td>
                                    <td>
                                        @if($record->check_out_time)
                                            {{ $record->check_out_time }}
                                        @else
                                            <span class="text-danger fw-bold">Not Closed</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($record->check_out_date)
                                            {{ $record->check_out_date }}
                                        @else
                                            <span class="text-danger fw-bold">Not Closed</span>
                                        @endif
                                    </td>
                                    <td>
                                        <a href="{{ route('odometer.view', $record->id) }}" class="btn btn-info btn-sm">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr class="text-center">
                                    <td colspan="6" class="text-muted">No odometer records found.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<script>
    $(document).ready(function () {
        const table = $('#odometerTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search odometer..."
                },
                // Update the target index based on your actual column count
                columnDefs: [
                    { orderable: false, targets: [5] } // "View" column is the 6th column, index = 5
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }

        // Auto-submit filter form on date change
        $('#from_date, #to_date').on('change', function () {
            $('#filterForm').submit();
        });
    });
</script>



@endsection
