@extends('dashboard.layout.app')
@section('title', 'Company Logs')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-building me-2 text-primary"></i> Company Info List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item">
                        <a href="{{ route('dashboard') }}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Company Info List</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-rotate me-1"></i> Reload
            </button>
           
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Company Info List</h5>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                 <table id="companyInfoTable" class="table table-bordered table-striped text-center">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Company Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Place</th>
                            <th>Logo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($logos as $logo)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $logo->name }}</td>
                            <td>{{ $logo->email }}</td>
                            <td>{{ $logo->phone }}</td>
                            <td>{{ $logo->place }}</td>
                            <td>
                                <img src="{{ asset('storage/' . $logo->logo) }}" alt="Company Logo"
                                    class="img-fluid" style="max-width: 100px;">
                            </td>
                            <td>
                                <a href="{{ route('logo.edit', $logo->id) }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>

                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">



    <script>
         $(document).ready(function () {
        $('#companyInfoTable').DataTable({
            pageLength: 10,
            responsive: true,
            autoWidth: false,
            language: {
                emptyTable: "No pending reset requests available.",
                search: "_INPUT_",
                searchPlaceholder: "Search requests..."
            },
            dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
        });
    });
    </script>

@endsection























