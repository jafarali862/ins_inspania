@extends('dashboard.layout.app')

@section('title', 'Dashboard')

@section('content')
  
@php
    $user = Auth::user();
@endphp





      <div class="content-page">
            <div class="container-fluid">
                
                <div class="page-title-head d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h4 class="fs-sm text-uppercase fw-bold m-0">Dashboard</h4>
                    </div>

                    <!-- <div class="text-end">
                        <ol class="breadcrumb m-0 py-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Inspinia</a></li>
                            
                            <li class="breadcrumb-item active">Dashboard 2</li>
                        </ol>
                    </div> -->
                </div>
                

                <div class="row row-cols-xxl-4 row-cols-md-2 row-cols-1">
                    <!-- Total Sales Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Insurance Companies</h5>
                                <!-- <span class="badge badge-soft-success"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <h3 class="mb-2 fw-normal">{{ $totalCompany }}</h3>
                                         <a href="{{ route('company.list') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Total Orders Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Total Employees</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal"> {{ $totalEmployee }}</h3>
                                                 <a href="{{ route('user.list') }}}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- New Customers Widget -->
                     <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Total Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal">{{$totalcaseCount}}</h3>
                                        <a href="{{ route('case.index') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Monthly Revenue Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Complete Investigations</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal">{{ $completeCase }}</h3>
                                        <!-- <a href="{{ route('case.index') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->


                </div><!-- end row -->




        <div class="row row-cols-xxl-4 row-cols-md-2 row-cols-1">
                    <!-- Total Sales Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Assigned Cases</h5>
                                <!-- <span class="badge badge-soft-success"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <h3 class="mb-2 fw-normal">{{ $assignedCase }}</h3>
                                         <a href="{{ route('assigned.case') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Total Orders Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Submitted Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal"> {{ $totalSubmittedCase }}</h3>
                                                 <a href="{{ route('assigned.case') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- New Customers Widget -->
                     <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Fake Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal">{{ $fakeCase }}</h3>
                                        <a href="{{ route('fake.cases') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Monthly Revenue Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Daily Submitted Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="donut-chart" data-chart="donut" style="min-height: 60px; width: 60px;"></div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal">{{ $todaySubmittedCase }}</h3>
                                        <a href="{{ route('case.today') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->


                </div><!-- end row -->


    <div class="row">

    <div class="col-md-8">
    <div class="ibox">
    <div class="ibox-title">
    <h5><i class="fa fa-area-chart"></i> Total Cases for {{ $currentYear }}</h5>
    </div>
    <div class="ibox-content">
    <div id="basic-area" class="apex-charts" style="min-height: 395px; width: 100%;"></div>
    </div>
    </div>

    </div>

    <div class="col-md-4">
    <div class="card card-success card-outline">
    <div class="card-header">
    <h3 class="card-title">
    <i class="fas fa-chart-pie"></i> Total Case Status
    </h3>
    </div>
    <div class="card-body">
    <!-- Apex Pie Chart Container -->
    <div id="simple-pie" style="min-height: 320px;"></div>

    <!-- Custom Legend Badges -->
    <div class="text-center mt-3">
    <span class="badge bg-success me-2" style="font-size: 14px;">
    <i class="fas fa-circle me-1"></i> Complete: <strong>{{ $completeCase }}</strong>
    </span>
    <span class="badge bg-danger" style="font-size: 14px;">
    <i class="fas fa-circle me-1"></i> Pending: <strong>{{ $pendingCase }}</strong>
    </span>
    </div>
    </div>
    </div>
    </div>



    </div>

    </div>
    <!-- container -->
    <!-- Footer Start -->
    <footer class="footer">
    <div class="container-fluid">
    <div class="row">
    <div class="col-md-6 text-center text-md-start">
    ©  <script>document.write(new Date().getFullYear())</script> Copyright  <span class="fw-semibold">Niveosys Technologies Pvt Ltd</span> 
    </div>
    <div class="col-md-6">
    <!-- <div class="text-md-end d-none d-md-block">         

    10GB of <span class="fw-bold">250GB</span> Free.
    </div> -->
    </div>
    </div>
    </div>
    </footer>
    <!-- end Footer -->

    </div>



<script>
document.addEventListener('DOMContentLoaded', function () {
  var options = {
    chart: {
      type: 'area',
      height: 380,
      width: '100%',
      toolbar: { show: false },
      zoom: { enabled: false },
    },
    colors: ['#1ab394'], // Inspinia green
    dataLabels: { enabled: false },
 
      stroke: {
  curve: 'straight',
  width: 2,
  lineCap: 'round',
  dashArray: 0
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.4, // slight lighter fill opacity (was 0.5)
        opacityTo: 0,
        stops: [0, 90, 100]
      }
    },
    series: [{
      name: 'Total Cases',
      data: @json($casesCount)
    }],
    xaxis: {
      categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      labels: {
        style: {
          colors: '#676a6c',
          fontSize: '13px',
          fontFamily: 'Open Sans, Helvetica, Arial, sans-serif',
        }
      },
      axisBorder: { color: '#e7eaec' },
      axisTicks: { color: '#e7eaec' }
    },
    yaxis: {
      labels: {
        style: {
          colors: '#676a6c',
          fontSize: '13px',
          fontFamily: 'Open Sans, Helvetica, Arial, sans-serif',
        }
      },
      min: 0,
      tickAmount: 5,
      axisBorder: { color: '#e7eaec' },
      axisTicks: { color: '#e7eaec' }
    },
    grid: {
      borderColor: '#e7eaec',
      strokeDashArray: 4,
      yaxis: { lines: { show: true } },
      xaxis: { lines: { show: false } }
    },
    tooltip: {
      theme: 'light',
      x: { format: 'MMM' },
      marker: { show: false }
    },
    // tweak smooth curve tension (0 to 1) - lower means smoother and less curvy
    markers: {
      size: 4,
      hover: {
        size: 6,
      }
    }
  };

  var chart = new ApexCharts(document.querySelector("#basic-area"), options);
  chart.render();
});
</script>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var options = {
        chart: {
            type: 'donut',
            height: 320,
            fontFamily: "'Open Sans', Helvetica, Arial, sans-serif",
            toolbar: { show: false }
        },
        series: [{{ $completeCase }}, {{ $pendingCase }}],
        labels: ['Complete', 'Pending'],
        colors: ['#1ab394', '#ed5565'], // Inspinia green & red
        stroke: {
            colors: ['#ffffff'],
            width: 2
        },
        dataLabels: {
            enabled: true,
            style: {
                fontSize: '14px',
                fontWeight: '600',
                colors: ['#ffffff']
            }
        },
        legend: {
            show: true,
            position: 'bottom',
            fontSize: '13px',
            fontWeight: 600,
            labels: {
                colors: '#676a6c'
            },
            markers: {
                width: 15,
                height: 15,
                radius: 12
            },
            itemMargin: {
                horizontal: 10,
                vertical: 5
            }
        },
        tooltip: {
            theme: 'light',
            y: {
                formatter: function (val) {
                    return val + " Cases";
                }
            }
        },
        plotOptions: {
            pie: {
                donut: {
                    size: '70%',
                    labels: {
                        show: false
                    }
                }
            }
        },
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    height: 260
                }
            }
        }]
    };

    var chart = new ApexCharts(document.querySelector("#simple-pie"), options);
    chart.render();
});
</script>



@endsection
