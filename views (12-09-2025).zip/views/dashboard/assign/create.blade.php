<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-md-8">

      <!-- Card -->
      <div class="card shadow-sm border-0">
        <div class="card-header bg-white border-bottom-0">
          <h4 class="fw-bold mb-2">Assign the Executive</h4>
          <p class="mb-1">Customer Name: <strong>{{ $insuranceCustomer->name }}</strong></p>
          <p class="mb-0">Insurance Company: <strong>{{ $insuranceCompany->name }}</strong></p>
        </div>

        <!-- Success Message -->
        <div id="successMessage" class="alert alert-success mt-3 d-none"></div>

        <div class="card-body">
          <form action="{{ route('store.case') }}" method="POST" id="caseForm">
            @csrf

            <!-- Hidden Inputs -->
            <input type="hidden" name="case_id" value="{{ $caseId->id }}">
            <input type="hidden" name="company_id" value="{{ $insuranceCompany->id }}">
            <input type="hidden" name="customer_id" value="{{ $insuranceCustomer->id }}">
            <input type="hidden" name="investigation_type" value="{{ $insuranceCustomer->insurance_type ?? $caseAssignment?->type }}">

            <!-- Default Executive -->
            <div class="mb-3">
              <label for="executive_1" class="form-label fw-semibold">Select Default Executive <span class="text-danger">*</span></label>
              <select name="Default_Executive" id="executive_1" class="form-select select2" required onchange="exe1()">
                <option disabled selected>Select the executive</option>
                @foreach ($users as $user)
                  <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                @endforeach
              </select>
              <span class="text-danger" id="Default_Executive-error"></span>
            </div>

            <!-- Sub Executives -->
            <div id="sub-executive-group">

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="executive_2" class="form-label">Select Executive (Driver)</label>
                  <select name="executive_driver" id="executive_2" class="form-select select2">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                      <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                  </select>
                  <span class="text-danger" id="executive_driver-error"></span>
                </div>

                <div class="col-md-6 mb-3">
                  <label for="executive_3" class="form-label">Select Executive (Garage)</label>
                  <select name="executive_garage" id="executive_3" class="form-select select2">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                      <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                  </select>
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="executive_4" class="form-label">Select Executive (Spot)</label>
                  <select name="executive_spot" id="executive_4" class="form-select select2">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                      <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                  </select>
                </div>

                <div class="col-md-6 mb-3">
                  <label for="executive_5" class="form-label">Select Executive (Meeting)</label>
                  <select name="executive_meeting" id="executive_5" class="form-select select2">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                      <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                  </select>
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-3">
                  <label for="executive_6" class="form-label">Select Executive (Accident Person)</label>
                  <select name="executive_accident_person" id="executive_6" class="form-select select2">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                      <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                  </select>
                </div>

                <div class="col-md-6 mb-3">
                  <label for="date" class="form-label">Select Investigation Date <span class="text-danger">*</span></label>
                  <input type="date" name="date" id="date" class="form-control" required>
                  @error('date')
                    <span class="text-danger">{{ $message }}</span>
                  @enderror
                </div>
              </div>
            </div>

            <!-- Other Details -->
            <div class="mb-3">
              <label for="other" class="form-label">Other Details</label>
              <textarea name="other" id="other" class="form-control" rows="5"></textarea>
              @error('other')
                <span class="text-danger">{{ $message }}</span>
              @enderror
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-user-check me-1"></i> Assign
            </button>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>



<script>
$(document).ready(function () {
    // Hide sub-executive group initially
    $('#sub-executive-group').hide();

    // Handle form submission with AJAX
    $('#caseForm').on('submit', function (e) {
        e.preventDefault();

        $.ajax({
            url: '{{ route('store.case') }}',
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                if (response.success) {
                    // Show success message
                    $('#successMessage').text(response.success).fadeIn();

                    // Reset form fields
                    $('#caseForm')[0].reset();
                    $('.text-danger').text('');

                    // Hide after 8 seconds and reload page
                    setTimeout(function () {
                        $('#successMessage').fadeOut();
                        location.reload(); // Reload the entire page
                    }, 8000);
                }
            },
            error: function (xhr) {
                const errors = xhr.responseJSON.errors;
                $('.text-danger').text('');
                $.each(errors, function (key, value) {
                    $('#' + key + '-error').text(value);
                });
            }
        });
    });

    // Access PHP variable in JS
    const insuranceCustomer = @json($insuranceCustomer);

    // Conditionally show/hide accident person field if insurance_type is 'MAC'
    toggleAccidentPersonField(insuranceCustomer.insurance_type);

    // Executive 1 change triggers others
    $('#executive_1').on('change', function () {
        exe1(insuranceCustomer.insurance_type);
    });

    // Utility: show/hide accident executive field
    function toggleAccidentPersonField(insuranceType) {
        if (insuranceType === 'MAC') {
            $('#accident').show();
        } else {
            $('#accident').hide();
            $('#executive_6').val('');
        }
    }

    // Function to sync executive selection
    function exe1(insuranceType) {
        const selectedExecutive = $('#executive_1').val();

        if (selectedExecutive) {
            $('#sub-executive-group').show();

            // Auto-fill other selects
            $('#executive_2').val(selectedExecutive).trigger('change');
            $('#executive_3').val(selectedExecutive).trigger('change');
            $('#executive_4').val(selectedExecutive).trigger('change');
            $('#executive_5').val(selectedExecutive).trigger('change');

            if (insuranceType === 'MAC') {
                $('#accident').show();
                $('#executive_6').val(selectedExecutive).trigger('change');
            } else {
                $('#accident').hide();
                $('#executive_6').val('').trigger('change');
            }
        } else {
            $('#sub-executive-group').hide();
        }
    }
});
</script>


