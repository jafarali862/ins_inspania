<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New india tvm report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>

<body>
  <div id="container" style="margin: 0 auto; width: 600px; text-align: center;">

    <!-- Left Section -->
    <div style="display: inline-block; width: 300px; vertical-align: top; text-align: center;">
        <!-- <img src="image.png" alt="" width="100%"> -->
        
        <hr style="border: 0; height: 10px; background-color: red; margin: 10px 0;">

        <p style="text-align: center;">
            <span style="font-size: 20px;">{{ $template->template_id }}</span><br>
            <span style="font-size: 40px;">INVESTIGATION <br>REPORT</span>
        </p>

        <hr style="border: 0; height: 10px; background-color: red; margin: 10px 0;">
        <br>

        <table style="width: 100%; font-size: 13px;">
            <!-- <tr>
                <th style="width: 30%; text-align: left;">REF NO.</th>
                <th style="width: 70%; text-align: left;"></th>
            </tr> -->
        </table>

        

        <table style="border-collapse: collapse; width: 100%; font-size: 13px;">

        
            <tr>
                <td style="border: none; text-align: left;">Name of Customer</td>
                <td style="border: none; text-align: left;">Babu</td>
            </tr>
            <tr>
                <td style="border: none; text-align: left;">Contact of Customer</td>
                <td style="border: none; text-align: left;">996124255
                   
                       
                    </td>
            </tr>

              <tr>
                <td style="border: none; text-align: left;">Policy Start Date</td>
                <td style="border: none; text-align: left;"> 2025-08-05 </td>
            </tr>

              <tr>
                <td style="border: none; text-align: left;">Policy End Date</td>
                <td style="border: none; text-align: left;">2025-08-08</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Policy No</td>
                <td style="border: none; text-align: left;">456123</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Crime Number</td>
                <td style="border: none; text-align: left;">15/2025</td>
            </tr>

            <tr>
                <td style="border: none; text-align: left;">Police Station</td>
                <td style="border: none; text-align: left;">Thrissur</td>
            </tr>

          
            


        </table>



        
    </div>

    <!-- Vertical Divider -->
    <div style="display: inline-block; width: 5px; vertical-align: top; border-right: 2px solid black; height: 500px; margin: 0 5px;"></div>

    <!-- Right Section -->
    <div style="display: inline-block; width: 250px; vertical-align: top; text-align: center;">

       
       <br/><br/>  <br/><br/>
 <br/><br/>  <br/><br/><br><br/><br>
      

        <!-- <p style="text-decoration: underline;">REMARK</p>
        <br>
        <p style="text-align: left;">Genuine/Fraud: GENUINE</p>
        <p style="text-align: left;">Fit/Unfit:</p> -->


          <table style="border-collapse: collapse; width: 100%; font-size: 13px;">

        
            <tr>
                <td style="border: none; text-align: left;">Email of Customer</td>
                <td style="border: none; text-align: left;">babu123@gmail.com</td>
            </tr>
            <tr>
                <td style="border: none; text-align: left;">Address of Customer</td>
                <td style="border: none; text-align: left;">Adrees1 
                   
                       
                    </td>
            </tr>

         

              <tr>
                <td style="border: none; text-align: left;">Case Details</td>
                <td style="border: none; text-align: left;">Case Description Here.....</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Father Name</td>
                <td style="border: none; text-align: left;">Ahammed</td>
            </tr>

               <tr>
                <td style="border: none; text-align: left;">Case Type</td>
                <td style="border: none; text-align: left;">OD</td>
            </tr>

          <tr>
                <td style="border: none; text-align: left;">Investigation Date</td>
                <td style="border: none; text-align: left;">2024-10-05</td>
            </tr>



        </table>

    </div>
</div>

   <hr>
<br/><br/>

  <div id="container" style="margin-top: 25px; text-align: center; margin: 0 auto;">
    <div style="width: 600px; margin: 0 auto;">

        {{-- Group questions by data_category --}}
        @php
            $groupedQuestions = $questions->groupBy('data_category');
            $counter = 1;
        @endphp

        @foreach($groupedQuestions as $category => $categoryQuestions)
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <tr>
                    <th colspan="3" style="text-align: center; background-color: yellow; padding: 10px;">
                        {{ strtoupper(str_replace('_', ' ', $category)) }}
                    </th>
                </tr>

                @foreach($categoryQuestions as $question)
                    @if($question->file_type !== 'image')
                        <tr>
                            <td style="width: 30px; border: 1px solid #000;">{{ $counter++ }}.</td>
                            <td style="width: 300px; border: 1px solid #000;"><strong>{{ $question->question }}</strong></td>
                            <td style="border: 1px solid #000;">
                                @php
                                    $value = $finalReport->{$question->column_name} ?? null;
                                @endphp

                                @if($question->input_type === 'text')
                                    {{ $value ?? 'Sample text answer' }}
                                @elseif($question->input_type === 'select')
                                    {{ $value == 1 ? 'Yes' : 'No' }}
                                @elseif($question->input_type === 'date')
                                    {{ $value ? \Carbon\Carbon::parse($value)->format('d-m-Y') : '05-08-2025' }}
                                @elseif($question->input_type === 'textarea')
                                    {{ $value ?? 'Sample Text Description' }}
                                @else
                                    N/A
                                @endif
                            </td>
                        </tr>
                    @endif
                @endforeach
            </table>
        @endforeach

        {{-- Footer --}}
        <div style="display: flex; justify-content: space-between; margin-top: 30px;">
            <div style="text-align: left;">
            
            <p>Executive Name: Executive4</p>
            <p>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}</p>
          
                
            </div>
        </div>

        {{-- Image Questions --}}
        @php $imageCounter = 1; @endphp
           @foreach($questions as $question1)
            @if($question1->file_type === 'image')
                <div style="margin-top: 30px; text-align: center;">
                    <p><strong>{{ $imageCounter++ }}. {{ $question1s->question }}</strong></p>
                    <img src="{{ public_path('storage/uploads/0sGvZo9McMzP978qZBOdmH0mXM13aS2SYSHrUY3y.jpg') }}"
                         alt="Image">
                </div>
            @endif
        @endforeach

    </div>
</div>

</body>

</html>