<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report - OD Case</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 30px;
            font-size: 14px;
        }

        h3 {
            margin-top: 25px;
            margin-bottom: 10px;
            text-decoration: underline;
        }

        h4 {
            margin-top: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 15px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #f2f2f2;
        }

        ul {
            line-height: 1.6;
            text-align: justify;
            margin: 0;
            padding-left: 20px;
        }

        li {
            margin-bottom: 8px;
        }

        .header {
            display: flex;
            justify-content: flex-end;
        }

        .header img {
            max-height: 60px;
        }

        .title {
            text-align: center;
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
        }

        .signature {
            margin-top: 50px;
            text-align: right;
            font-weight: bold;
        }

        .no-border td {
            border: none !important;
        }
    </style>
</head>

<body>
    <div class="header">
        <h3 style="text-align: center;"> {{$finalReport->insurance_com_name}}</h3>
        <!-- <img src="image.png" alt="Company Logo"> -->

        @if($finalReport->template_logo)
                <img src="{{ public_path('storage/' . $finalReport->template_logo) }}" 
                     alt="Company Logo" 
                     style="max-width: 200px; height: auto; margin-top: 10px;">
            @endif

    </div>
    <hr>
    <div class="title">
        <h3 style="   width: 100%;
    background-color: #943634;
    text-align: center;
    font-weight: 600;
    color: #fff;
    padding: 4px;text-decoration: none;">INVESTIGATION REPORT: OD CASE</h3>
    </div>

    <!-- INTRODUCTION -->
    <h3>I. INTRODUCTION</h3>
    <table>
        <tr>
            <td>1.</td>
            <td>Name of Customer</td>
            <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
        </tr>
        <tr>
            <td>2.</td>
            <td>Contact Details of Customer</td>
            <td>{{ $finalReport->customer_phone ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>3.</td>
            <td>Permanent Adress</td>
            <td>{{ $finalReport->customer_present_address ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>4.</td>
            <td>Policy No</td>
            <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
        </tr>

        
          <tr>
            <td>5.</td>
            <td>Policy No</td>
            <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>6.</td>
            <td>Police police_station</td>
            <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>7.</td>
            <td>Case Type</td>
            <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}<</td>
        </tr>

          <tr>
            <td>8.</td>
            <td>Investigation Date</td>
            <td>{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
        </tr>

    </table>

    <!-- CASE DETAILS -->
    <h3>II. CASE/CLAIM DETAILS</h3>
    <table>


       @php
        $groupedQuestions = $validQuestions12->groupBy('data_category');

        $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
            return $questions->contains(function ($question) use ($finalReport) {
                return !empty($finalReport->{$question->column_name});
            });
        });

        $counter = 1;
    @endphp

    @foreach($filteredGroups as $category => $questions)
        @foreach($questions->where('input_type', '!=', 'file') as $question)
            @php
                $answer = $finalReport->{$question->column_name} ?? null;
            @endphp

            @if(!empty($answer))
                <tr>
                    <td>{{ $counter++ }}.</td>
                    <td>{{ $question->question }}</td>
                    <td>

                    @if($answer === '0' || $answer === 0)
                    No
                    @elseif($answer === '1' || $answer === 1)
                    Yes
                    @else
                    {{ $answer }}
                    @endif


                    </td>
                </tr>
            @endif
        @endforeach
    @endforeach

       
    </table>

    <!-- ACCIDENT DETAILS -->
    

    <!-- <hr> -->

{{-- IMAGE SECTION --}}
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];

    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    @php $images = []; @endphp

    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;

            // Decode JSON file path
            if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                $decoded = json_decode($filePath, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $filePath = $decoded[0];
                }
            }

            $isImage = false;
            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }

            if ($isImage && !empty($filePath)) {
                $images[] = [
                    'path' => $filePath,
                    'label' => $question->question
                ];
            }
        @endphp
    @endforeach

    {{-- Show images in rows of 2 --}}
    @foreach(array_chunk($images, 2) as $row)
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            @foreach($row as $img)
                <div style="text-align: center; width: 48%;">
                    <h4>{{ $img['label'] }}</h4>
                    <img src="{{ storage_path('app/public/' . $img['path']) }}" width="200" height="300" alt="Image">
                </div>
            @endforeach
        </div>
    @endforeach
@endforeach


    <!-- FACTS AND FINDINGS -->
    

    <div class="footer">
        <!-- <div>08.10.2024<br>Trivandrum</div>
        <div><strong>ERG ASSOCIATES</strong></div> -->

        <div>Executive Name:{{ collect([
        $finalReport->driver_executive,
        $finalReport->garage_executive,
        $finalReport->spot_executive,
        $finalReport->owner_executive,
        $finalReport->accident_executive
        ])->filter()->unique()->implode(', ') ?: 'N/A' }}</div>
        <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}

        </div>
        
    </div>
</body>

</html>
