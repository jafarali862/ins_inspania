<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;

        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
           <div id="container" style="display: flex; justify-content: center; margin-top: 20px;">
    <div style="border: 1px solid; border-radius: 10px; width: 200px; height: auto; padding: 10px; text-align: center;">
        
        @if($finalReport->template_logo)
            <img src="{{ public_path('storage/' . $finalReport->template_logo) }}" 
                 alt="Company Logo" 
                 style="max-width: 150px; height: auto; display: block; margin: 0 auto 10px auto;">
        @endif

        <p style="font-size: 18px; margin: 0; font-weight: bold;">
            {{ $finalReport->insurance_com_name }}
        </p>
    </div>
</div>


            <hr>
            <h2 style="text-align: center;"> INVESTIGATION REPORT:</h2>
            <h3>1. INTRODUCTION</h3>


            <table>

                <tr>
                    <td>1</td>
                    <td>Name of Customer</td>
                    <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
                </tr>
                 <tr>
            <td>2.</td>
            <td>Contact Details of Customer</td>
            <td>{{ $finalReport->customer_phone ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>3.</td>
            <td>Permanent Adress</td>
            <td>{{ $finalReport->customer_present_address ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>4.</td>
            <td>Policy No</td>
            <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
        </tr>

        
          <tr>
            <td>5.</td>
            <td>Policy No</td>
            <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>6.</td>
            <td>Police police_station</td>
            <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
        </tr>

          <tr>
            <td>7.</td>
            <td>Case Type</td>
            <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}<</td>
        </tr>

          <tr>
            <td>8.</td>
            <td>Investigation Date</td>
            <td>{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
        </tr>

            </table>

            <h3>II. CASE/CLAIM DETAILS:</h3>

            <table>

                 @php
        $groupedQuestions = $validQuestions12->groupBy('data_category');

        $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
            return $questions->contains(function ($question) use ($finalReport) {
                return !empty($finalReport->{$question->column_name});
            });
        });

        $counter = 1;
    @endphp

    @foreach($filteredGroups as $category => $questions)
        @foreach($questions->where('input_type', '!=', 'file') as $question)
            @php
                $answer = $finalReport->{$question->column_name} ?? null;
            @endphp

            @if(!empty($answer))
                <tr>
                    <td>{{ $counter++ }}.</td>
                    <td>{{ $question->question }}</td>
                    <td>
                        
                    @if($answer === '0' || $answer === 0)
                    No
                    @elseif($answer === '1' || $answer === 1)
                    Yes
                    @else
                    {{ $answer }}
                    @endif
                
                </td>
                </tr>
            @endif
        @endforeach
    @endforeach
            </table>
            <!-- <hr> -->
            <br>
           


       

            <div style="display: flex; justify-content: space-between;">
                 <div>Executive Name:{{ collect([
        $finalReport->driver_executive,
        $finalReport->garage_executive,
        $finalReport->spot_executive,
        $finalReport->owner_executive,
        $finalReport->accident_executive
        ])->filter()->unique()->implode(', ') ?: 'N/A' }}</div>
        <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}

        </div>
            </div>



                 {{-- IMAGE SECTION --}}
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];

    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    @php $images = []; @endphp

    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;

            // Decode JSON file path
            if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                $decoded = json_decode($filePath, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $filePath = $decoded[0];
                }
            }

            $isImage = false;
            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }

            if ($isImage && !empty($filePath)) {
                $images[] = [
                    'path' => $filePath,
                    'label' => $question->question
                ];
            }
        @endphp
    @endforeach

    {{-- Show images in rows of 2 --}}
    @foreach(array_chunk($images, 2) as $row)


        @foreach($row as $img)

        <h3>{{ $img['label'] }}</h3>
        <img src="{{ storage_path('app/public/' . $img['path']) }}" alt="" style="max-width:100%;">
        <br>
        @endforeach
        @endforeach
        @endforeach

        </div>
        </div>

</body>

</html>