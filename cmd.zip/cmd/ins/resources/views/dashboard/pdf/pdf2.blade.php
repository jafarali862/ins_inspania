<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>od report new india</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            width: 50%;
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center;">

        <div>

            <div style="text-align: end;">

               @if($finalReport->template_logo)
                <img src="{{ public_path('storage/' . $finalReport->template_logo) }}" 
                     alt="Company Logo" 
                     style="max-width: 200px; height: auto; margin-top: 10px;">
                @endif
                
            </div>

            <hr>
            <h3 style="text-align: center;"><u>INVESTIGATION REPORT: {{$finalReport->insurance_com_name}}</u></h3>
            <h3>I. INTRODUCTION:</h3>
            <table>
                <tr>
                    <th>1</th>
                    <th>Name of Customer</th>
                    <th>{{ $finalReport->customer_name ?? 'N/A' }}</th>
                </tr>
                <tr>
                    <th>2</th>
                    <th>Contact Details of Customer</th>
                    <th>{{ $finalReport->customer_present_address ?? 'N/A' }}<br/>
                     <br>Phone no:{{ $finalReport->customer_phone ?? 'N/A' }}<br/>
                     Email:{{ $finalReport->customer_email ?? 'N/A' }}    
                </th>
                </tr>

                <tr>
                    <th>3</th>
                    <th>Policy No</th>
                    <th>{{ $finalReport->customer_policy_no ?? 'N/A' }}</th>
                </tr>

                 <tr>
                    <th>4</th>
                    <th>Crime Number</th>
                    <th>{{ $finalReport->crime_number ?? 'N/A' }}</th>
                </tr>

                    <tr>
                    <th>5</th>
                    <th>Police Station</th>
                    <th>{{ $finalReport->police_station ?? 'N/A' }}</th>
                </tr>

                  <tr>
                    <th>6</th>
                    <th>Case Type</th>
                    <th>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</th>
                </tr>

                  <tr>
                    <th>7</th>
                    <th>Investigation Date</th>
                    <th>{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</th>
                </tr>



            </table>

            <h3>II. CASE/CLAIM DETAILS:</h3>

         <table border="1">
    @php
        $groupedQuestions = $validQuestions12->groupBy('data_category');

        $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
            return $questions->contains(function ($question) use ($finalReport) {
                return !empty($finalReport->{$question->column_name});
            });
        });

        $counter = 1;
    @endphp

    @foreach($filteredGroups as $category => $questions)
        @foreach($questions->where('input_type', '!=', 'file') as $question)
            @php
                $answer = $finalReport->{$question->column_name} ?? null;
            @endphp

            @if(!empty($answer))
                <tr>
                    <td>{{ $counter++ }}.</td>
                    <td>{{ $question->question }}</td>
                    <td>

                    @if($answer === '0' || $answer === 0)
                    No
                    @elseif($answer === '1' || $answer === 1)
                    Yes
                    @else
                    {{ $answer }}
                    @endif
                    
                    </td>
                </tr>
            @endif
        @endforeach
    @endforeach
</table>

<!-- <hr> -->

{{-- IMAGE SECTION --}}
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];

    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    @php $images = []; @endphp

    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;

            // Decode JSON file path
            if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                $decoded = json_decode($filePath, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $filePath = $decoded[0];
                }
            }

            $isImage = false;
            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }

            if ($isImage && !empty($filePath)) {
                $images[] = [
                    'path' => $filePath,
                    'label' => $question->question
                ];
            }
        @endphp
    @endforeach

    {{-- Show images in rows of 2 --}}
    @foreach(array_chunk($images, 2) as $row)
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            @foreach($row as $img)
                <div style="text-align: center; width: 48%;">
                    <h4>{{ $img['label'] }}</h4>
                    <img src="{{ storage_path('app/public/' . $img['path']) }}" width="200" height="300" alt="Image">
                </div>
            @endforeach
        </div>
    @endforeach
@endforeach


<br>
            <br>
            <br>


        <div style="display: flex; justify-content: space-between;">
        <div>Executive Name:{{ collect([
        $finalReport->driver_executive,
        $finalReport->garage_executive,
        $finalReport->spot_executive,
        $finalReport->owner_executive,
        $finalReport->accident_executive
        ])->filter()->unique()->implode(', ') ?: 'N/A' }}</div>
        <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}

        </div>
        <!-- <div>ANOOP N G <br> <img src="sign.png"> </div> -->
        </div> 


        </div>
    </div>
</body>

</html>