<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New india tvm report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>

<body>
  <div id="container" style="margin: 0 auto; width: 600px; text-align: center;">

    <!-- Left Section -->
    <div style="display: inline-block; width: 320px; vertical-align: top; text-align: center;">
        <!-- <img src="image.png" alt="" width="100%"> -->

         @if($finalReport->template_logo)
                <img src="{{ public_path('storage/' . $finalReport->template_logo) }}" 
                     alt="Company Logo" 
                     style="max-width: 200px; height: auto; margin-top: 10px;">
            @endif
        
        <hr style="border: 0; height: 10px; background-color: red; margin: 10px 0;">

        <p style="text-align: center;">
            <span style="font-size: 20px;">{{$finalReport->insurance_com_name}}</span><br>
            <span style="font-size: 40px;">INVESTIGATION <br>REPORT</span>
        </p>

        <hr style="border: 0; height: 10px; background-color: red; margin: 10px 0;">
        <br>

        <table style="width: 100%; font-size: 13px;">
            <!-- <tr>
                <th style="width: 30%; text-align: left;">REF NO.</th>
                <th style="width: 70%; text-align: left;"></th>
            </tr> -->
        </table>

        

        <table style="border-collapse: collapse; width: 100%; font-size: 13px;">

        
            <tr>
                <td style="border: none; text-align: left;">Name of Customer</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_name ?? 'N/A' }}</td>
            </tr>
            <tr>
                <td style="border: none; text-align: left;">Contact of Customer</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_phone ?? 'N/A' }}
                   
                       
                    </td>
            </tr>

              <tr>
                <td style="border: none; text-align: left;">Policy Start Date</td>
                <td style="border: none; text-align: left;">  {{ $finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A' }}</td>
            </tr>

              <tr>
                <td style="border: none; text-align: left;">Policy End Date</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A' }}</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Policy No</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Crime Number</td>
                <td style="border: none; text-align: left;">{{ $finalReport->crime_number ?? 'N/A' }}</td>
            </tr>

            <tr>
                <td style="border: none; text-align: left;">Police Station</td>
                <td style="border: none; text-align: left;">{{ $finalReport->police_station ?? 'N/A' }}</td>
            </tr>

            


        </table>



        
    </div>

    <!-- Vertical Divider -->
    <div style="display: inline-block; width: 5px; vertical-align: top; border-right: 2px solid black; height: 500px; margin: 0 5px;"></div>

    <!-- Right Section -->
    <div style="display: inline-block; width: 250px; vertical-align: top; text-align: center;">

       
       <br/><br/>  <br/><br/>
 <br/><br/>  <br/><br/><br><br/><br>
      

        <!-- <p style="text-decoration: underline;">REMARK</p>
        <br>
        <p style="text-align: left;">Genuine/Fraud: GENUINE</p>
        <p style="text-align: left;">Fit/Unfit:</p> -->


          <table style="border-collapse: collapse; width: 100%; font-size: 13px;">

        
            <tr>
                <td style="border: none; text-align: left;">Email of Customer</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_email ?? 'N/A' }}</td>
            </tr>
            <tr>
                <td style="border: none; text-align: left;">Address of Customer</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_present_address ?? 'N/A' }}
                   
                       
                    </td>
            </tr>

         

              <tr>
                <td style="border: none; text-align: left;">Case Details</td>
                <td style="border: none; text-align: left;">{{ $finalReport->case_details ?? 'N/A' }}</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Father Name</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_father_name ?? 'N/A' }}</td>
            </tr>

              <tr>
                <td style="border: none; text-align: left;">Case Type</td>
                <td style="border: none; text-align: left;">{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td>
            </tr>

             <tr>
                <td style="border: none; text-align: left;">Investigation Date</td>
                <td style="border: none; text-align: left;">{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
            </tr>



        </table>

    </div>
</div>

   <hr>
<br/><br/>

    <div id="container" style="margin-top: 25px;text-align: center; margin: 0 auto;">
        <div style="width: 600px;margin: 0 auto;">
            <!-- <table style="width: 550px;">
                <tr>
                    <th colspan="3" style="text-align: center; background-color: yellow;">LIST OF ENCLOSURES</th>
                </tr>
            </table> -->
         

            <!-- <h2>1. INTRODUCTION</h2> -->
          @php
    $groupedQuestions = $validQuestions12->groupBy('data_category');

    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <table style="width: 550px; border-collapse: collapse; margin-bottom: 20px;">
        <tr>
            <th colspan="3" style="text-align: center; background-color: yellow;">
                {{ strtoupper(str_replace('_', ' ', $category)) }}
            </th>
        </tr>

        @php $rowNumber = 1; @endphp

        @foreach($questions->where('input_type', '!=', 'file') as $question)
            @php
                $answer = $finalReport->{$question->column_name} ?? null;
            @endphp

            @if(!empty($answer))
                <tr>
                    <td style="width: 30px;">{{ $rowNumber++ }}.</td>
                    <td style="width: 300px;"><strong>{{ $question->question }}</strong></td>
                    <td>
                    @if($answer === '0' || $answer === 0)
                    No
                    @elseif($answer === '1' || $answer === 1)
                    Yes
                    @else
                    {{ $answer }}
                    @endif
                    </td>

                </tr>
            @endif
        @endforeach
    </table>
@endforeach

        <div style="display: flex; justify-content: space-between;text-align:left;">
        <div>
        <p>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}<br>
        </p>
        </div>
        <div>

        Executive Name:{{ collect([
        $finalReport->driver_executive,
        $finalReport->garage_executive,
        $finalReport->spot_executive,
        $finalReport->owner_executive,
        $finalReport->accident_executive
        ])->filter()->unique()->implode(', ') ?: 'N/A' }}
        </div>
        </div>
        <br>
        <br>


{{-- IMAGE SECTION --}}
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];

    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    @php $images = []; @endphp

    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;

            // Decode JSON file path
            if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                $decoded = json_decode($filePath, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $filePath = $decoded[0];
                }
            }

            $isImage = false;
            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }

            if ($isImage && !empty($filePath)) {
                $images[] = [
                    'path' => $filePath,
                    'label' => $question->question
                ];
            }
        @endphp
    @endforeach

    {{-- Show images in rows of 2 --}}
    @foreach(array_chunk($images, 1) as $row)

    <div  style="display: flex; justify-content: space-evenly;">
             @foreach($row as $img)
                <div style="text-align: center; margin: 10px;">
                    <p>{{ $img['label'] }}</p>
                    <img src="{{ storage_path('app/public/' . $img['path']) }}" 
                        width="300px" 
                        height="300px" 
                        alt="{{ $img['label'] }}">
                </div>
          @endforeach
    </div>
   @endforeach
@endforeach

   </div>
    </div>

</body>

</html>