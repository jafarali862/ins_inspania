<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New india tvm report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            width: 50%;
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center;">
        <div>
            <div style="text-align: end;">
                <!-- <img src="image.png"> -->


            @if($finalReport->template_logo)
            <img src="{{ public_path('storage/' . $finalReport->template_logo) }}" 
            alt="Company Logo" 
            style="max-width: 200px; height: auto; margin-top: 10px;">
            @endif


            </div>


            <table>
                <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                        <p style="font-size: 25;">Investigation Report -{{$finalReport->insurance_com_name}}</p>
                    </th>
                </tr>
                <tr>
                    <td>Name of Customer</td>
                    <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td>Contact Details of Customer</td>
                    <td><br>{{ $finalReport->customer_present_address ?? 'N/A' }}<br/>
                   
                        <br>Phone no:{{ $finalReport->customer_phone ?? 'N/A' }} <br>Email: {{ $finalReport->customer_email ?? 'N/A' }}
                    </td>
                </tr>

                 <tr>
                    <td>Policy Date</td>
                    <td>       
                    {{ $finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A' }} - 

                    {{ $finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A' }}
                    </td>
                </tr>


                 <tr>
                    <td>Policy No</td>
                    <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>Crime Number</td>
                    <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>Police Station</td>
                    <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>Case Type</td>
                    <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>Investigation Date</td>
                    <td>  {{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
                </tr>




            </table>
            <br>


            <table border="1">

                <!-- <tr>
                    <td>Claim No</td>
                    <td>MOT15119272</td>
                </tr>
                <tr>
                    <td>Interaction No.</td>
                    <td>NA</td>
                </tr> -->
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');


    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <!-- <tr> -->
        <!-- <th colspan="2" style="background-color: #d3d3d3; text-transform: uppercase;">
            {{ str_replace('_', ' ', $category) }}
        </th> -->
    <!-- </tr> -->

    @foreach($questions->where('input_type', '!=', 'file') as $question)
        @php
            $answer = $finalReport->{$question->column_name} ?? null;
        @endphp

        @if(!empty($answer))
            <tr>
                <td>{{ $question->question }}</td>
                <td> @if($answer === '0' || $answer === 0)
                    No
                    @elseif($answer === '1' || $answer === 1)
                    Yes
                    @else
                    {{ $answer }}
                    @endif</td>
            </tr>
        @endif
    @endforeach
@endforeach



                
               
              
            </table>


            <br>
           <table>
               

    @php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Filter groups where at least one file question has data in finalReport
    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <!-- <tr>
        <th colspan="2" style="background-color: #d3d3d3; text-transform: uppercase;">
            {{ str_replace('_', ' ', $category) }}
        </th>
    </tr> -->



    {{-- Loop through file-type questions --}}
    @php $images = []; @endphp
    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;

            // Decode if JSON like ["uploads/xyz.png"]
            if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                $decoded = json_decode($filePath, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $filePath = $decoded[0]; // take first file
                }
            }

            $isImage = false;
            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }

            if ($isImage && !empty($filePath)) {
                $images[] = [
                    'path' => $filePath,
                    'label' => $question->question
                ];
            }
        @endphp
    @endforeach

    {{-- Show images in rows of 2 --}}
    @foreach(array_chunk($images, 2) as $row)

        <tr>
                    @foreach($row as $img)
            <td style="text-align: justify;">
                <h4>{{ $img['label'] }}</h4></td><br>
<td>
               <img src="{{ storage_path('app/public/' . $img['path']) }}" 
     alt="{{ $img['label'] }}" 
     style="max-width:100%;">
        </td>
            @endforeach
            @if(count($row) < 2)
                
            @endif
        </tr>
    @endforeach
@endforeach



            </table>
           
           
            <br>
            <br>

            <div style="display: flex; justify-content: space-between;">
                <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}
<!-- <br>THIRUVANATHAPURAM -->
</div>
                <div> Executive Name:{{ collect([
        $finalReport->driver_executive,
        $finalReport->garage_executive,
        $finalReport->spot_executive,
        $finalReport->owner_executive,
        $finalReport->accident_executive
        ])->filter()->unique()->implode(', ') ?: 'N/A' }}</div>
            </div>

        </div>
    </div>
</body>

</html>