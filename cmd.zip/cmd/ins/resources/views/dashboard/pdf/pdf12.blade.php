<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;

        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center;">
        <div>
            <div style="display: flex; justify-content: end;">
                <div style="border: 1px solid; border-radius: 10px; width: 150px; height: 70px;">
                    <!-- <p style="font-size: 20px; margin-top: 10px;">ANOOP NG<BR>
                        INVESTIGATOR</P> -->

                <p style="font-size: 20px; margin-top: 10px;text-align:center;display:flex;">
                {{ $template->template_id }}
                </p>

                @if($template->template_logo)
                <img src="{{ public_path('storage/' . $template->template_logo) }}" 
                alt="Template Logo" 
                style="max-width: 200px; height: auto; margin-top: 10px;">
                @endif
                
                </div>
            </div>

            <hr>
            <h2 style="text-align: center;"> INVESTIGATION REPORT:</h2>
            <h3>1. INTRODUCTION</h3>


            <table>

              <tr>
            <td>1</td>
            <td>Name of Customer</td>
            <td>Jafar</td>
            </tr>
            <tr>
            <td>2.</td>
            <td>Contact Details of Customer</td>
            <td>996124255</td>
            </tr>

            <tr>
            <td>3.</td>
            <td>Permanent Adress</td>
            <td>Address45</td>
            </tr>

            <tr>
            <td>4.</td>
            <td>Policy No</td>
            <td>12344321</td>
            </tr>


            <tr>
            <td>5.</td>
            <td>Crime Number</td>
            <td>CR/12</td>
            </tr>

            <tr>
            <td>6.</td>
            <td>Police Station</td>
            <td>Trivandrum</td>
            </tr>

            <tr>
            <td>7.</td>
            <td>Case Type</td>
            <td>OD</td>
            </tr>

            <tr>
            <td>8.</td>
            <td>Investigation Date</td>
            <td>2024-10-05</td>
            </tr>

            </table>

            <h3>II. CASE/CLAIM DETAILS:</h3>

            <table>

                    @php $counter = 1; @endphp

@foreach($questions as $question1)
    @if($question1->file_type !== 'image')
        <tr>
            <td>{{ $counter++ }}.</td>
            <td>{{ $question1->question }}

         
            </td>
            <!-- <td></td> -->

             <td>
                        @if($question1->input_type === 'text')
                            Sample text answer
                        @elseif($question1->input_type === 'select')
                         Yes
                        @elseif($question1->input_type === 'date')
                            05-08-2025

                         @elseif($question1->input_type === 'textarea')
                            Sample Text Description

                        @else
                            <!-- No answer -->
                        @endif
                    </td>


        </tr>
    @endif
@endforeach
            </table>
            <!-- <hr> -->
            <br>
             

        <div style="display: flex; justify-content: space-between;">
                 <div>Executive Name:Executive2</div>
        <div>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}

        </div>
        </div>


    @foreach($questions as $question1)
    @if($question1->file_type == 'image')

        <h3>{{ $question1['question'] }}</h3>
        <img src="{{ public_path('storage/uploads/0sGvZo9McMzP978qZBOdmH0mXM13aS2SYSHrUY3y.jpg') }}" alt="" style="max-width:100%;">
        <br>

        @endif
        @endforeach

        </div>
    </div>

</body>

</html>