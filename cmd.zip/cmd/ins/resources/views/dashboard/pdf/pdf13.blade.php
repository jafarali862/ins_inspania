<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OD Report - Reliance</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        h4 {
            margin: 10px 0;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
    </style>
</head>

<body>

    {{-- Optional logo --}}
    <div style="text-align: right;">
        {{-- <img src="image.png" alt="Logo"> --}}
    </div>

    <div style="text-align: center;">
        <p> {{ $template->template_id }}</p>
        <h4>OD INVESTIGATION REPORT</h4>
    </div>

    {{-- Customer & Case Info --}}
  
    <table>
    <tr>
        <td>Name of Customer</td>
        <td>Babu</td>
    </tr>
    <tr>
        <td>Contact Details of Customer</td>
        <td>
            Address1<br>
            Phone No: 996124255<br>
            Email: Babu123@gmail.com
        </td>
    </tr>
    <tr>
        <td>Policy Date</td>
        <td>2025-08-05 - 2025-08-08</td>
    </tr>
    <tr>
        <td>Policy No</td>
        <td>456123</td>
    </tr>
    <tr>
        <td>Crime Number</td>
        <td>12/2025</td>
    </tr>
    <tr>
        <td>Police Station</td>
        <td>Thrissur</td>
    </tr>
    <tr>
        <td>Case Type</td>
        <td>OD</td>
    </tr>
    <tr>
        <td>Investigation Date</td>
        <td>2024-10-05</td>
    </tr>


     
    </table>
    <table>
        <br/>
    {{-- Loop through text-based questions --}}
    @php $counter = 1; @endphp
    @foreach($questions as $question1)
        @if($question1->file_type !== 'image')
            <tr>
                <td>{{ $counter++ }}.</td>
                <td>{{ $question1->question }}</td>
                <td>
                    @php
                        $value = $finalReport->{$question1->column_name} ?? null;
                    @endphp

                    @if($question1->input_type === 'text')
                        {{ $value ?? 'Sample text answer' }}
                    @elseif($question1->input_type === 'select')
                        {{ $value == 1 ? 'Yes' : 'No' }}
                    @elseif($question1->input_type === 'date')
                        {{ \Carbon\Carbon::parse($value)->format('d-m-Y') ?? '05-08-2025' }}
                    @elseif($question1->input_type === 'textarea')
                        {{ $value ?? 'Sample Text Description' }}
                    @else
                        N/A
                    @endif
                </td>
            </tr>
        @endif
    @endforeach
</table>

   <br/>

    {{-- Loop through image-based questions --}}
    <table>
        @foreach($questions as $question1)
            @if($question1->file_type === 'image')
                <tr>
                    <td style="text-align: justify;">
                        <h4>{{ $question1->question }}</h4><br>
                        <img src="{{ public_path('storage/uploads/0sGvZo9McMzP978qZBOdmH0mXM13aS2SYSHrUY3y.jpg') }}" alt="Image">
                    </td>
                </tr>
            @endif
        @endforeach
    </table>

    {{-- Footer --}}
    <div class="footer">
        <div>Executive Name: Executive3</div>
        <div>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}</div>
    </div>

</body>

</html>
