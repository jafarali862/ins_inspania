@extends('dashboard.layout.app')
@section('title', 'Add New Insurance Customer')

@section('content')
        <div class="content-page">
        <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
        <div class="flex-grow-1">
        <h4 class="fs-sm text-uppercase fw-bold m-0">
        <i class="fa fa-user-plus me-2 text-primary"></i> Add User
        </h4>
        </div>
        <div class="text-end">
        <ol class="breadcrumb m-0 py-0">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="{{ route('case.index') }}">Add Inurance Customer</a></li>
        <li class="breadcrumb-item active">Add Inurance Customer</li>
        </ol>
        </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
        <div class="col-lg-8 col-md-10">
        <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
        <i class="fa fa-user-plus me-2"></i>
        <h5 class="mb-0">Add Inurance Customer</h5>

        <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" >
        <i class="fa fa-check-circle me-2"></i>
        <span id="successText"></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        </div>


        <!-- Action Buttons -->
        <div class="d-flex gap-2">
        <a href="javascript:history.back()" class="btn btn-danger btn-sm">
        <i class="fa fa-arrow-left me-1"></i> Back
        </a>
        <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
        <i class="fa fa-sync me-1"></i> Reload
        </a>

        </div>
        </div>
                    <div class="card-body">

                  <form id="insuranceForm" action="" method="POST" enctype="multipart/form-data" novalidate>
    @csrf

    {{-- Company --}}
  <div class="mb-3">
    <label for="company" class="form-label fw-bold">Select Company <span class="text-danger">*</span></label>
    <select id="company" name="company" class="select2" required data-placeholder="Select Company">
        <option></option> <!-- empty for placeholder -->
        @foreach ($companies as $company)
            <option value="{{ $company->id }}">{{ $company->name }}</option>
        @endforeach
    </select>
    <span id="company-error" class="text-danger error"></span>
</div>


    {{-- Name --}}
    <div class="mb-3">
        <label for="name" class="form-label fw-bold">Name <span class="text-danger">*</span></label>
        <input type="text" id="name" name="name" class="form-control" placeholder="Enter name" required>
        <span id="name-error" class="text-danger error"></span>
    </div>

    {{-- Father's Name --}}
    <div class="mb-3">
        <label for="father_name" class="form-label fw-bold">Father's Name <span class="text-danger">*</span></label>
        <input type="text" id="father_name" name="father_name" class="form-control" placeholder="Enter father's name" required>
        <span id="father_name-error" class="text-danger error"></span>
    </div>

    {{-- Phone --}}
<div class="mb-3">
    <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
    <div class="d-flex align-items-center gap-2">
        <!-- Country Code -->
        <select id="country_code" name="country_code" class="select2 form-select form-select-sm" data-placeholder="Code">
            <option></option>
            <option value="+91" selected>+91 (India)</option>
            <option value="+1">+1 (USA)</option>
            <option value="+44">+44 (UK)</option>
            <option value="+61">+61 (Australia)</option>
            <option value="+971">+971 (UAE)</option>
            <option value="+81">+81 (Japan)</option>
            <option value="+49">+49 (Germany)</option>
        </select>

        <!-- Phone Number -->
        <input type="text" id="phone" name="phone" class="form-control" 
               placeholder="Enter phone number"
               required maxlength="15" inputmode="numeric"
               oninput="validatePhoneInput(this)">
    </div>
    <div id="phoneError" class="text-danger mt-1" style="display:none;">
        Please enter digits only (0-9).
    </div>
</div>




    {{-- Checkbox: Emergency contact same as phone --}}
    <div class="form-check mb-3">
        <input type="checkbox" id="same_as_phone" class="form-check-input">
        <label for="same_as_phone" class="form-check-label text-primary">Emergency contact number same as phone</label>
    </div>

    {{-- Emergency Contact Number --}}
    <div class="mb-3">
        <label for="emergency_contact_number" class="form-label fw-bold">Emergency Contact Number <span class="text-danger">*</span></label>
        <input type="text" id="emergency_contact_number" name="emergency_contact_number" class="form-control" placeholder="Enter emergency contact number" required  pattern="\d*" 
       inputmode="numeric"
       maxlength="15"
       oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        <span id="emergency_contact_number-error" class="text-danger error"></span>
    </div>

    {{-- Email --}}
    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Email<span class="text-danger">*</span></label>
        <input type="email" id="email" name="email" class="form-control" placeholder="Enter email">
        <span id="email-error" class="text-danger error"></span>
    </div>

    {{-- Present Address --}}
    <div class="mb-3">
        <label for="present_address" class="form-label fw-bold">Present Address <span class="text-danger">*</span></label>
        <textarea id="present_address" name="present_address" rows="3" class="form-control" placeholder="Enter present address" required></textarea>
        <span id="present_address-error" class="text-danger error"></span>
    </div>

    {{-- Checkbox: Present address same as permanent --}}
    <div class="form-check mb-3">
        <input type="checkbox" id="same_as_present" class="form-check-input">
        <label for="same_as_present" class="form-check-label text-primary">Present address same as permanent address</label>
    </div>

    {{-- Permanent Address --}}
    <div class="mb-3">
        <label for="permanent_address" class="form-label fw-bold">Permanent Address <span class="text-danger">*</span></label>
        <textarea id="permanent_address" name="permanent_address" rows="3" class="form-control" placeholder="Enter permanent address" required></textarea>
        <span id="permanent_address-error" class="text-danger error"></span>
    </div>

    {{-- Insurance Type --}}
    <div class="mb-3">
        <label for="insurance_type" class="form-label fw-bold">Insurance Type <span class="text-danger">*</span></label>
        <input type="text" id="insurance_type" name="insurance_type" class="form-control" placeholder="Enter insurance type" required>
        <span id="insurance_type-error" class="text-danger error"></span>
    </div>

    {{-- Case Details --}}
    <div class="mb-3">
        <label for="case_details" class="form-label fw-bold">Case Details <span class="text-danger">*</span></label>
        <textarea id="case_details" name="case_details" rows="3" class="form-control" placeholder="Enter case details" required></textarea>
        <span id="case_details-error" class="text-danger error"></span>
    </div>

    {{-- Crime Number --}}
    <div class="mb-3">
        <label for="crime_no" class="form-label fw-bold">Crime Number <span class="text-danger">*</span></label>
        <input type="text" id="crime_no" name="crime_no" class="form-control"  value="{{ old('crime_no', $crime_no ?? '') }}"  placeholder="Enter Crime Number" required>
        <span id="crime_no-error" class="text-danger error"></span>
    </div>

    {{-- Police Station --}}
    <div class="mb-3">
        <label for="police_station" class="form-label fw-bold">Police Station <span class="text-danger">*</span></label>
        <input type="text" id="police_station" name="police_station" class="form-control" placeholder="Enter Police Station" required>
        <span id="police_station-error" class="text-danger error"></span>
    </div>

    {{-- Policy No --}}
    <div class="mb-3">
        <label for="policy_no" class="form-label fw-bold">Policy No <span class="text-danger">*</span></label>
        <input type="text" id="policy_no" name="policy_no" class="form-control" placeholder="Policy No" required>
        <span id="policy_no-error" class="text-danger error"></span>
    </div>

    {{-- Policy Start and End Dates --}}
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="policy_start" class="form-label fw-bold">Policy Start Date <span class="text-danger">*</span></label>
            <input type="text" id="policy_start" name="policy_start" class="form-control" required>
            <span id="policy_start-error" class="text-danger error"></span>
        </div>
        <div class="col-md-6">
            <label for="policy_end" class="form-label">Policy End Date</label>
            <input type="text" id="policy_end" name="policy_end" class="form-control" required>
            <span id="policy_end-error" class="text-danger error"></span>
        </div>
    </div>

    {{-- Intimation Report --}}
    <div class="mb-3">
        <label for="intimation_report" class="form-label">Intimation Report</label>
        <input type="file" id="intimation_report" name="intimation_report" class="form-control">
        <span id="intimation_report-error" class="text-danger error"></span>
    </div>

    {{-- Investigation Type --}}
    <div class="mb-3">
        <label for="investigation_type" class="form-label fw-bold">Investigation Type <span class="text-danger">*</span></label>
        <select id="investigation_type" name="investigation_type" class="form-select" required>
            <option disabled selected>Select the investigation type</option>
            <option value="OD">OD</option>
            <option value="MACT">MACT</option>
        </select>
        <span id="investigation_type-error" class="text-danger error"></span>
    </div>

    {{-- Default Executive --}}
    <div class="mb-3">
        <label for="executive_1" class="form-label fw-bold">Select Default Executive <span class="text-danger">*</span></label>
        <select id="executive_1" name="Default_Executive" class="form-select select2" required onchange="exe1()">
    <option disabled selected>Select the executive</option>
    @foreach ($users as $user)
        <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
    @endforeach
</select>

        <span id="Default_Executive-error" class="text-danger error"></span>
    </div>

    {{-- Sub Executives Group --}}
    <div id="sub-executive-group" class="container mb-3">
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="executive_2" class="form-label">Select Executive (Driver)</label>
                <select id="executive_2" name="executive_driver" class="form-select">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                </select>
                <span id="executive_driver-error" class="text-danger error"></span>
            </div>
            <div class="col-md-6">
                <label for="executive_3" class="form-label">Select Executive (Garage)</label>
                <select id="executive_3" name="executive_garage" class="form-select">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="executive_4" class="form-label">Select Executive (Spot)</label>
                <select id="executive_4" name="executive_spot" class="form-select">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-6">
                <label for="executive_5" class="form-label">Select Executive (Meeting)</label>
                <select id="executive_5" name="executive_meeting" class="form-select">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6" id="accident">
                <label for="executive_6" class="form-label">Select Executive (Accident Person)</label>
                <select id="executive_6" name="executive_accident_person" class="form-select">
                    <option disabled selected>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->place }})</option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-6">
                <label for="date" class="form-label fw-bold">Select Investigation Date <span class="text-danger">*</span></label>
                <input type="text" id="date" name="date" class="form-control" required>
                <span id="date-error" class="text-danger error"></span>
            </div>
        </div>
    </div>

    {{-- Other Details --}}
    <div class="mb-3">
        <label for="other_details" class="form-label">Other Details</label>
        <textarea id="other_details" name="other_details" rows="3" class="form-control" placeholder="Enter any other details"></textarea>
    </div>

    {{-- Submit --}}
    <div class="mb-3 d-flex justify-content-start">
        <button type="submit" id="submitBtn" class="btn btn-primary btn-lg px-5" style="font-size: 1.2rem;">
            Submit
        </button>
    </div>
</form>

                </div>
            </div> <!-- card -->
        </div> <!-- col-md-8 -->
    </div> <!-- row -->
</div> <!-- container-fluid -->

<!-- Select2 CSS -->
<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Bootstrap 5 theme for Select2 -->
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />

<!-- jQuery (only once!) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<!-- Optional: daterangepicker -->
<link rel="stylesheet" href="{{ asset('assets/plugins/daterangepicker/daterangepicker.css')}}" type="text/css">


<style>
    /* .select2-container
    {
width:281.547px !important;
    } */
    </style>


    @php
    $insPerson = $insuranceCustomer ?? null;
@endphp


<script>
$('#company').select2({
    theme: 'bootstrap-5',
    width: '100%',
    placeholder: $('#company').data('placeholder'),
    allowClear: true,
    tags: true // allows typing new text
});
$('.select2').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: "Select the executive",
        allowClear: true
    });

    $('#country_code').select2({
        theme: 'bootstrap-5',
        width: 'resolve',           // fit the select box container
        placeholder: $('#country_code').data('placeholder'),
        allowClear: true,
        minimumResultsForSearch: 0 // always show search box
    });



</script>


<script>
$(document).ready(function() {
    const insPerson = @json($insPerson);

    // 1️⃣ Checkbox logic: copy phone/address values
    $('#same_as_phone').on('change', function() {
        $('#emergency_contact_number').val($(this).is(':checked') ? $('#phone').val() : '');
    });
    $('#same_as_present').on('change', function() {
        $('#permanent_address').val($(this).is(':checked') ? $('#present_address').val() : '');
    });

    
    // $('#sub-executive-group').hide();
    // if (insPerson && insPerson.insurance_type === 'MAC') {
    //     $('#accident').show();
    // } else {
    //     $('#accident').hide();
    // }

    // 3️⃣ On executive_1 change
 window.exe1 = function() {
    const execVal = $('#executive_1').val();
    const execFields = ['#executive_2','#executive_3','#executive_4','#executive_5'];

    if (execVal) {
        $('#sub-executive-group').show();

        // Fill driver, garage, spot, meeting
        execFields.forEach(sel => {
            $(sel).val(execVal).trigger('change'); // important for select2
        });

        // Accident logic (if you want it conditional later)
        $('#executive_6').val(execVal).trigger('change');
        $('#accident').show();

    } else {
        $('#sub-executive-group').hide();
        execFields.forEach(sel => $(sel).val('').trigger('change'));
        $('#executive_6').val('').trigger('change');
    }
};






    

    // 4️⃣ AJAX form submit with file support
    $(document).ready(function () {
    $('#insuranceForm').on('submit', function(e) {
        e.preventDefault();
        let formData = new FormData(this);

        $.ajax({
            url: "{{ route('insurance.store') }}",
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,

            success: function(response) {
                if (response.success) {
                    $('#successText').text(response.success);
                    $('#successMessage')
                        .removeClass('d-none')
                        .fadeIn();

                    $('html, body').animate({
                        scrollTop: $('#successMessage').offset().top - 100
                    }, 500);

                    $('#insuranceForm')[0].reset();
                    $('.text-danger').text('');
                    $('.form-control, .form-select').removeClass('is-invalid');
                    $('#same_as_phone, #same_as_present').prop('checked', false);

                    setTimeout(function() {
                        window.location.href = response.redirect_url;
                    }, 3000);
                }
            },

  error: function(xhr) {
    const errors = xhr.responseJSON?.errors || {};
    $('.text-danger').text('');
    $('.form-control, .form-select').removeClass('is-invalid');

    let errorFields = [];

    $.each(errors, (key, val) => {
        const field = $('#' + key);
        const errorSpan = $('#' + key + '-error');

        if (field.length) {
            field.addClass('is-invalid');
            errorSpan.text(val[0] || val);

            // Collect all fields with errors
            errorFields.push(field);
        }
    });

    // Scroll to the FIRST visible error field
    if (errorFields.length > 0) {
        const firstVisibleError = errorFields.find(f => f.is(':visible'));

        if (firstVisibleError) {
            $('html, body').animate({
                scrollTop: firstVisibleError.offset().top - 100
            }, 500);
            firstVisibleError.focus();
        }
    }
}

        });
    });
});
});
</script>


    <script>
        $(document).ready(function() {
            // Handle checkbox for emergency contact number
            $('#same_as_phone').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#emergency_contact_number').val($('#phone').val());
                } else {
                    $('#emergency_contact_number').val('');
                }
            });

            // Handle checkbox for addresses
            $('#same_as_present').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#permanent_address').val($('#present_address').val());
                } else {
                    $('#permanent_address').val('');
                }
            });




            // Handle form submission


            // $('#insuranceForm').on('submit', function(e) 
            // {
            // e.preventDefault();

            // let formData = new FormData(this);

            // $.ajax({
            // url: "{{ route('insurance.store') }}",
            // type: 'POST',
            // data: formData,
            // success: function(response) {
            // if (response.success) {
            // $('#successMessage').text(response.success).show();
            // $('#insuranceForm')[0].reset(); // Reset form fields
            // $('.text-danger').text(''); // Clear previous error messages
            // $('#same_as_phone').prop('checked', false); // Uncheck the checkbox
            // $('#same_as_present').prop('checked', false); // Uncheck the checkbox
            // }
            // },
            // error: function(xhr) {
            // var errors = xhr.responseJSON.errors;
            // $('.text-danger').text(''); // Clear previous error messages
            // $.each(errors, function(key, value) {
            // $('#' + key + '-error').text(value);
            // });
            // }
            // });
            // });
            });


            // $(document).ready(function () {
            // $('#insuranceForm').on('submit', function (e) {
            // e.preventDefault();

            // // Create FormData object for file + form support
            // let formData = new FormData(this);

            // $.ajax({
            // url: "{{ route('insurance.store') }}",
            // type: 'POST',
            // data: formData,
            // processData: false,  // Don't process into query string
            // contentType: false,  // Let browser set correct multipart/form-data headers
            // success: function (response) {
            //     if (response.success) {
            //         $('#successMessage').text(response.success).show();
            //         $('#insuranceForm')[0].reset(); // Reset form fields
            //         $('.text-danger').text(''); // Clear previous error messages

            //         // Delay to override reset effect
            //         setTimeout(() => {
            //             $('#same_as_phone').prop('checked', false);
            //             $('#same_as_present').prop('checked', false);
            //         }, 10);
            //     }
            // },
            // error: function (xhr) {
            //     var errors = xhr.responseJSON.errors;
            //     $('.text-danger').text(''); // Clear previous error messages
            //     $.each(errors, function (key, value) {
            //         $('#' + key + '-error').text(value[0]);
            //     });
            // }
            // });
            // });
            // });

            

        // $(document).ready(function () {
        // $('#caseForm').on('submit', function (e) {
        // e.preventDefault();

        // let formData = new FormData(this); // 🔁 Use FormData

        // $.ajax({
        // url: '{{ route('store.case') }}',
        // type: 'POST',
        // data: formData,
        // processData: false,  // Required for file upload
        // contentType: false,  // Required for file upload
        // success: function (response) {
        // if (response.success) {
        // $('#successMessage').text(response.success).fadeIn();

        // $('#caseForm')[0].reset();  // Reset form
        // $('.text-danger').text('');

        // setTimeout(function () {
        //     $('#successMessage').fadeOut();
        //     location.reload(); // Reload the page
        // }, 8000);
        // }
        // },
        // error: function (xhr) {
        // let errors = xhr.responseJSON.errors;
        // $('.text-danger').text('');
        // $.each(errors, function (key, value) {
        // $('#' + key + '-error').text(value[0]);
        // });
        // }
        // });
        // });
        // });





            // $('#insuranceForm').on('submit', function(e) 
            // {
            // e.preventDefault();

            // let formData = new FormData(this); // ⚠️ this captures files as well

            // $.ajax({
            // url: "{{ route('insurance.store') }}",
            // type: 'POST',
            // data: formData,
            // processData: false,   // ⛔ Don't process data
            // contentType: false,   // ⛔ Don't set content type
            // success: function(response) {
            // if (response.success) {
            // $('#successMessage').text(response.success).show();
            // $('#insuranceForm')[0].reset(); 
            // $('.text-danger').text('');
            // $('#same_as_phone').prop('checked', false);
            // $('#same_as_present').prop('checked', false);
            // }
            // },
            // error: function(xhr) {
            // var errors = xhr.responseJSON.errors;
            // $('.text-danger').text('');
            // $.each(errors, function(key, value) {
            // $('#' + key + '-error').text(value);
            // });
            // }
            // });
            // });


        // $(document).ready(function() {
        //     $('#caseForm').on('submit', function(e) {
        //         e.preventDefault();

        //         $.ajax({
        //             url: '{{ route('store.case') }}',
        //             type: 'POST',
        //             data: $(this).serialize(),
        //             success: function(response) {
        //                 if (response.success) {
        //                     $('#successMessage').text(response.success).show();
        //                     $('#caseForm')[0].reset(); // Reset form fields
        //                     $('.text-danger').text(''); // Clear previous error messages
        //                 }
        //             },
        //             error: function(xhr) {
        //                 var errors = xhr.responseJSON.errors;
        //                 $('.text-danger').text(''); // Clear previous error messages
        //                 $.each(errors, function(key, value) {
        //                     $('#' + key + '-error').text(value);
        //                 });
        //             }
        //         });
        //     });
        // });
     
//         var accident = $('#accident');
//         var insPerson = <?php echo json_encode($insuranceCustomer); ?>;
//             if (insPerson.insurance_type === 'MAC') 
//             {
//                 accident.show();
//             } else {
//                 accident.hide();
//             }
//             $('#sub-executive-group').hide();
    
//     function exe1(){
//         var insPerson = <?php echo json_encode($insuranceCustomer); ?>;
//         var exe1=$('#executive_1').val();
//         var exe2=$('#executive_2');
//         var exe3=$('#executive_3');
//         var exe4=$('#executive_4');
//         var exe5=$('#executive_5');
//         var exe6=$('#executive_6');
//         var accident=$('#accident');
//         console.log(exe1);
//         if(exe1!=''){
//         $('#sub-executive-group').show();
//         exe2.val(exe1);
//         exe3.val(exe1);
//         exe4.val(exe1);
//         exe5.val(exe1);
//         if (insPerson.insurance_type === 'MAC') 
//             {
//                 accident.show();
//                 exe6.val(exe1);
//             } else {
//                 accident.hide();
//                 exe6.val('');
//             }

//         }else{
//             $('#sub-executive-group').hide(); 
//         }
//   }




  document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#policy_start", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("policy_start").value // use DB value
    });
});


document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#policy_end", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("policy_end").value // use DB value
    });
});

document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("date").value // use DB value
    });
});


function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }
    </script>
@endsection
