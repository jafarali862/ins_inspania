@extends('dashboard.layout.app')
@section('title', 'Report Request')

@section('content')

<div class="content-page">
  <div class="container-fluid">

    <!-- Page Header -->
    <div class="page-title-head d-flex align-items-center mb-3">
      <div class="flex-grow-1">
        <h4 class="fs-sm text-uppercase fw-bold m-0">
          <i class="fa-solid fa-clipboard-list me-2 text-primary"></i> Report Request List
        </h4>
      </div>
      <div class="text-end">
        <ol class="breadcrumb m-0 py-0">
          <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
          <li class="breadcrumb-item active">Report Request List</li>
        </ol>
      </div>
    </div>

    <!-- Header Buttons -->
    <div class="d-flex justify-content-end mb-3 gap-2 flex-wrap">
      <button class="btn btn-danger" onclick="window.history.back()">
        <i class="fa-solid fa-arrow-left me-1"></i> Back
      </button>
      <button class="btn btn-warning" onclick="window.location.reload()">
        <i class="fa-solid fa-sync-alt me-1"></i> Reload
      </button>
    
    </div>

    <!-- Filter Form -->
   <form id="filterForm" class="row g-3 align-items-center mb-3" method="GET">
  <div class="col-auto">
    <label for="from_date" class="form-label mb-0">From Date</label>
    <input type="text" id="from_date" name="from_date" value="{{ request()->from_date }}" class="form-control">
  </div>
  <div class="col-auto">
    <label for="to_date" class="form-label mb-0">To Date</label>
    <input type="text" id="to_date" name="to_date" value="{{ request()->to_date }}" class="form-control">
  </div>
  
</form>

    <!-- Card -->
   
      <div class="card shadow-sm border-0">
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Report Request List</h5>
      </div>
 </div>

      <div class="card-body p-0">
        <div class="table-responsive">
          <table id="casesTable" class="table table-striped table-bordered mb-0">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Customer Name</th>
                        <th>Company Name</th>
                        <th>Investigation Date</th>
                        <th>Type</th>
                         <th>Crime Number</th>
                        <th>Police Station</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($reports as $i => $report)
                        <tr>
                            <td>{{ $i + 1 }}</td>
                            <td>{{ $report->customer_name }}</td>
                            <td>{{ $report->company_name }}</td>
                            <td>{{ \Carbon\Carbon::parse($report->date)->format('d-m-Y') }}</td>
                            <td>{{ $report->type }}</td>
                            <td>{{ $report->crime_number }}</td>
                            <td>{{ $report->police_station }}</td>
                            <td>
                                <a href="{{ route('request.report.view', $report->report_id) }}" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>


<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<script>
    $(document).ready(function () {
        $('#casesTable').DataTable({
        order: [[0, "asc"]],
        paging: true,
        lengthChange: true,
        searching: true,
        info: true,
        autoWidth: false,
        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        responsive: true,
    });
    });

     document.getElementById('from_date').addEventListener('change', function () {
        document.getElementById('filterForm').submit();
    });

    document.getElementById('to_date').addEventListener('change', function () {
        document.getElementById('filterForm').submit();
    });

    document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#from_date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("from_date").value // use DB value
    });
});



document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#to_date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("to_date").value // use DB value
    });
});
    
</script>
@endsection
