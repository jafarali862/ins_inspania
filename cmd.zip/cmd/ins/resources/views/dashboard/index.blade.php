@extends('dashboard.layout.app')

@section('title', 'Dashboard')

@section('content')
  
@php
    $user = Auth::user();
@endphp





      <div class="content-page">
            <div class="container-fluid">
                
                <div class="page-title-head d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h4 class="fs-sm text-uppercase fw-bold m-0">Dashboard</h4>
                    </div>

                    <!-- <div class="text-end">
                        <ol class="breadcrumb m-0 py-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Inspinia</a></li>
                            
                            <li class="breadcrumb-item active">Dashboard 2</li>
                        </ol>
                    </div> -->
                </div>


             <!-- <div class="mb-3">
    <label for="filterRange" class="form-label fw-bold">Filter By:</label>
    <select id="filterRange" class="form-select" style="width: 200px;">
        <option value="all" selected>All</option>
        <option value="daily">Today</option>
        <option value="weekly">This Week</option>
        <option value="monthly">This Month</option>
    </select>
</div> -->

<div class="row mb-4">
    <div class="col-md-3">
        <label for="filterRange" class="form-label fw-bold">Filter By:</label>
        <select id="filterRange" class="form-select">
            <option value="all" selected>All</option>
            <option value="daily">Today</option>
            <option value="weekly">This Week</option>
            <option value="monthly">This Month</option>
        </select>
    </div>

    <div class="col-md-3">
        <label for="fromDate" class="form-label fw-bold">From Date:</label>
        <input type="text" id="fromDate" class="form-control">
    </div>

    <div class="col-md-3">
        <label for="toDate" class="form-label fw-bold">To Date:</label>
        <input type="text" id="toDate" class="form-control">
    </div>
</div>





<div class="row row-cols-xxl-4 row-cols-md-3 row-cols-1 align-items-center">
                    <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{route('company.list')}}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Insurance Companies</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                            <i class="ti ti-building-bank"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 total-company"><span data-target="124">{{ $totalCompany }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                     <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{route('user.list')}}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Total Employees</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                            <i class="ti ti-users"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 total-emp"><span data-target="124">{{ $totalEmployee }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{route('case.index')}}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Total Cases</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                            <i class="ti ti-files"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 total-case"><span data-target="124">{{$totalCase}}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{route('final.report.create')}}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Report Generate</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                            <i class="ti ti-file-check"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 complete-report"><span data-target="124">{{ $completeReport }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
          
                </div>



        
                <div class="row row-cols-xxl-4 row-cols-md-3 row-cols-1 align-items-center">
                    <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{ route('case.index', ['status' => 'Assigned']) }}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Assigned Cases</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                               <i class="ti ti-briefcase"></i>

                                        </span>
                                    </div>
                                    <h3 class="mb-0 assigned-case"><span data-target="124">{{ $assignedCase }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                     <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{ route('case.index', ['status' => 'Pending']) }}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Pending Cases</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                              <i class="ti ti-clock"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 pending-case"><span data-target="124">{{ $pendingCase }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{ route('case.index', ['status' => 'Complete']) }}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Complete Cases</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                            <i class="ti ti-circle-check"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 complete-case"><span data-target="124">{{ $completeCase }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <div class="col">
                        <div class="card card-hover" style="border-color: #646262;">
                            <div class="card-body">
                                <a href="{{route('fake.cases')}}" class="text-muted float-end mt-n1 fs-xl"><i class="ti ti-external-link"></i></a>
                                <h5 title="Number of Tasks">Fake Cases</h5>
                                <div class="d-flex align-items-center gap-2 my-3">
                                    <div class="avatar-md flex-shrink-0">
                                        <span class="avatar-title text-bg-light rounded-circle fs-22">
                                            <i class="ti ti-shield-x"></i>
                                        </span>
                                    </div>
                                    <h3 class="mb-0 fake-case"><span data-target="124">{{ $fakeCase }}</span></h3>
                                    <!-- <span class="badge badge-soft-primary fw-medium ms-2 fs-xs ms-auto">+3 New</span> -->
                                </div>
                              
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
          
                </div>






                <div class="row row-cols-xxl-4 row-cols-md-2 row-cols-1" style="display: none;">
                    <!-- Total Sales Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Insurance Companies</h5>
                                <!-- <span class="badge badge-soft-success"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div style="min-height: 60px; width: 60px;">
        <canvas id="donutCompanyChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <h3 class="mb-2 fw-normal total-company">{{ $totalCompany }}</h3>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Total Orders Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Total Employees </h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                       <div style="min-height: 60px; width: 60px;">
        <canvas id="donutEmployeeChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                
                                        <h3 class="mb-2 fw-normal total-emp"> {{ $totalEmployee }}</h3>
                                                 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- New Customers Widget -->
                     <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Total Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                  <div style="min-height: 60px; width: 60px;">
        <canvas id="donutCaseChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal total-case">{{$totalCase}}</h3>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Monthly Revenue Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Report Generate</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                     <div style="min-height: 60px; width: 60px;">
        <canvas id="donutReportChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal complete-report">{{ $completeReport }}</h3>
                                        <!-- <a href="{{ route('case.index') }}" ><p class="mb-0 text-muted"><span>More info</span></p></a> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->


                </div><!-- end row -->




        <div class="row row-cols-xxl-4 row-cols-md-2 row-cols-1" style="display: none;">
                    <!-- Total Sales Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Assigned Cases</h5>
                                <!-- <span class="badge badge-soft-success"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                     <div style="min-height: 60px; width: 60px;">
        <canvas id="donutAssignChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <h3 class="mb-2 fw-normal assigned-case">{{ $assignedCase }}</h3>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Total Orders Widget -->
                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                               <h5 class="card-title">Pending Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                <div style="min-height: 60px; width: 60px;">
        <canvas id="donutPendingChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                       <h3 class="mb-2 fw-normal pending-case"> {{ $pendingCase }}</h3>
                                                 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->



                    <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Complete Case</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                            <div style="min-height: 60px; width: 60px;">
        <canvas id="donutCompleteChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                       <h3 class="mb-2 fw-normal complete-case">{{ $completeCase }}</h3>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->


                    <!-- New Customers Widget -->
                     <div class="col">
                        <div class="card" style="border-color: #c7c7c7;">
                            <div class="card-header d-flex border-dashed justify-content-between align-items-center">
                                <h5 class="card-title">Fake Cases</h5>
                                <!-- <span class="badge badge-soft-primary"> Monthly</span> -->
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                       <div style="min-height: 60px; width: 60px;">
        <canvas id="donutFakeChart" width="60" height="60"></canvas>
    </div>
                                    <div class="text-end">
                                        <!-- <h3 class="mb-2 fw-normal"><span data-target="280">0</span></h3> -->
                                        <h3 class="mb-2 fw-normal fake-case">{{ $fakeCase }}</h3>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <!-- Monthly Revenue Widget -->
                    


                </div><!-- end row -->


    <div class="row">

    <div class="col-md-8">
    <div class="ibox">
    <div class="ibox-title">
    <h5><i class="fa fa-area-chart"></i> Total Cases for {{ $currentYear }}</h5>
    </div>
    <div class="ibox-content">
    <div id="basic-area" class="apex-charts" style="min-height: 395px; width: 100%;"></div>
    </div>
    </div>

    </div>

    <div class="col-md-4">
    <div class="card card-success card-outline">
    <div class="card-header">
    <h3 class="card-title">
    <i class="fas fa-chart-pie"></i> Total Case Status
    </h3>
    </div>
    <div class="card-body">
    <!-- Apex Pie Chart Container -->
    <div id="simple-pie" style="min-height: 320px;"></div>

    <!-- Custom Legend Badges -->

    <!-- <div class="text-center mt-3">
    <span class="badge bg-success me-2" style="font-size: 14px;">
    <i class="fas fa-circle me-1"></i> Complete: <strong>{{ $completeCase }}</strong>
    </span>
    <span class="badge bg-danger" style="font-size: 14px;">
    <i class="fas fa-circle me-1"></i> Pending: <strong>{{ $pendingCase }}</strong>
    </span>


     <span class="badge bg-primary" style="font-size: 14px; margin-left: 10px; background-color: rgb(15, 107, 245) !important;">
    <i class="fas fa-circle me-1"></i> Assigned: <strong>{{ $assignedCase }}</strong>
    </span>

    </div> -->


    <div class="container mt-3">
  <div class="row justify-content-center text-center">
    <div class="col-12 col-sm-auto mb-2">
      <span class="badge bg-success" style="font-size: 14px;">
        <i class="fas fa-circle me-1"></i> Complete: <strong>{{ $completeCase }}</strong>
      </span>
    </div>
    <div class="col-12 col-sm-auto mb-2">
      <span class="badge bg-danger" style="font-size: 14px;">
        <i class="fas fa-circle me-1"></i> Pending: <strong>{{ $pendingCase }}</strong>
      </span>
    </div>
    <div class="col-12 col-sm-auto mb-2">
      <span class="badge" style="font-size: 14px; background-color: rgb(15, 107, 245) !important;">
        <i class="fas fa-circle me-1"></i> Assigned: <strong>{{ $assignedCase }}</strong>
      </span>
    </div>
  </div>
</div>


    </div>
    </div>
    </div>



    </div>

    </div>
    <!-- container -->
    <!-- Footer Start -->
    <footer class="footer">
    <div class="container-fluid">
    <div class="row">
    <div class="col-md-6 text-center text-md-start">
    ©  <script>document.write(new Date().getFullYear())</script> Copyright  <span class="fw-semibold">Niveosys Technologies Pvt Ltd</span> 
    </div>
    <div class="col-md-6">
    <!-- <div class="text-md-end d-none d-md-block">         

    10GB of <span class="fw-bold">250GB</span> Free.
    </div> -->
    </div>
    </div>
    </div>
    </footer>
    <!-- end Footer -->

    </div>





<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<style>
    .card-hover:hover {
        background-color: transparent; /* Light gray background on hover */
        box-shadow: 0 6px 20px rgba(46, 46, 46, 0.06); /* Smooth shadow effect */
        transform: translateY(-4px); /* Lift the card slightly */
        transition: all 0.3s ease-in-out;
        /* cursor: pointer; */
        border-color: #4a90e2; /* Optional: change border color */
    }
</style>




<script>
let areaChart, pieChart, donutCompanyChart, donutEmployeeChart,donutCaseChart,donutReportChart,donutAssignChart,
donutPendingChart,donutCompleteChart,donutFakeChart;

document.addEventListener('DOMContentLoaded', function () {
    // ---------- Donut Company Chart ----------
    const totalCompanyEl = document.querySelector('.total-company');
    const totalEmployeeEl = document.querySelector('.total-emp');
    const totalCaseEl = document.querySelector('.total-case');
    const totalReportEl = document.querySelector('.complete-report');
    const totalAssignEl = document.querySelector('.assigned-case');
    const totalPendingEl = document.querySelector('.pending-case');
const totalCompleteEl = document.querySelector('.complete-case');
const totalFakeEl = document.querySelector('.fake-case');

    let totalCompany = parseInt(totalCompanyEl ? totalCompanyEl.innerText : 0);
    let totalEmployee = parseInt(totalEmployeeEl ? totalEmployeeEl.innerText : 0);
   let totalCase = parseInt(totalCaseEl ? totalCaseEl.innerText : 0);
    let completeReport = parseInt(totalReportEl ? totalReportEl.innerText : 0);
  let assignedCase = parseInt(totalAssignEl ? totalAssignEl.innerText : 0);
  let pendingCase = parseInt(totalPendingEl ? totalPendingEl.innerText : 0);
   let completeCase = parseInt(totalCompleteEl ? totalCompleteEl.innerText : 0);
     let fakeCase = parseInt(totalFakeEl ? totalFakeEl.innerText : 0);

    const totalMaxCompany = 100; // max companies
    const totalMaxEmployee = 100; // max employees
        const totalMaxCase = 100; // max employees
    const totalMaxReport = 100; // max employees
   const totalMaxAssign = 100; // max employees
   const totalMaxPending = 100; // max employees
   const totalMaxComplete = 100; // max employees
   const totalMaxFake = 100; // max employees

    const remainingCompany = totalMaxCompany - totalCompany;
    const remainingEmployee = totalMaxEmployee - totalEmployee;
  const remainingCase = totalMaxCase - totalCase;
  const remainingReport = totalMaxReport - completeReport;
  const remainingAssign = totalMaxAssign - assignedCase;
  const remainingPending= totalMaxPending - pendingCase;
  const remainingComplete= totalCompleteEl - completeCase;
const remainingFake =totalFakeEl - fakeCase;

    // Company donut chart
    const ctxCompany = document.getElementById('donutCompanyChart').getContext('2d');
    donutCompanyChart = new Chart(ctxCompany, {
        type: 'doughnut',
        data: {
            labels: ['Companies', 'Remaining'],
            datasets: [{
                data: [totalCompany, remainingCompany],
                backgroundColor: ['#0F6BF5', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });

    // Employee donut chart
    const ctxEmployee = document.getElementById('donutEmployeeChart').getContext('2d');
    donutEmployeeChart = new Chart(ctxEmployee, {
        type: 'doughnut',
        data: {
            labels: ['Employees', 'Remaining'],
            datasets: [{
                data: [totalEmployee, remainingEmployee],
                backgroundColor: ['#1ab394', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });


      const ctxCase = document.getElementById('donutCaseChart').getContext('2d');
    donutCaseChart = new Chart(ctxCase, {
        type: 'doughnut',
        data: {
            labels: ['Cases', 'Remaining'],
            datasets: [{
                data: [totalCase, remainingCase],
                backgroundColor: ['#0F6BF5', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });



    const ctxReport = document.getElementById('donutReportChart').getContext('2d');
    donutReportChart = new Chart(ctxReport, {
        type: 'doughnut',
        data: {
            labels: ['Reports', 'Remaining'],
            datasets: [{
                data: [completeReport, remainingReport],
                backgroundColor: ['#1ab394', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });


       const ctxAssign = document.getElementById('donutAssignChart').getContext('2d');
    donutAssignChart = new Chart(ctxAssign, {
        type: 'doughnut',
        data: {
            labels: ['Assign', 'Remaining'],
            datasets: [{
                data: [assignedCase, remainingAssign],
                backgroundColor: ['#0F6BF5', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });

     const ctxPending = document.getElementById('donutPendingChart').getContext('2d');
    donutPendingChart = new Chart(ctxPending, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'Remaining'],
            datasets: [{
                data: [pendingCase, remainingPending],
                backgroundColor: ['#1ab394', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });


       const ctxComplete= document.getElementById('donutCompleteChart').getContext('2d');
    donutCompleteChart = new Chart(ctxComplete, {
        type: 'doughnut',
        data: {
            labels: ['Complete', 'Remaining'],
            datasets: [{
                data: [completeCase, remainingCase],
                backgroundColor: ['#0F6BF5', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });


     const ctxFake = document.getElementById('donutFakeChart').getContext('2d');
    donutFakeChart = new Chart(ctxFake, {
        type: 'doughnut',
        data: {
            labels: ['Fake', 'Remaining'],
            datasets: [{
                data: [fakeCase, remainingFake],
                backgroundColor: ['#1ab394', '#bebebeb2'],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });



    // ---------- Dashboard Dynamic Counts & Charts ----------
    const filterEl = document.getElementById('filterRange');
    const fromDateEl = document.getElementById('fromDate');
    const toDateEl = document.getElementById('toDate');

    const mapping = {
        totalEmployee: '.total-emp',
        totalCompany: '.total-company',
        totalCase: '.total-case',
        completeCase: '.complete-case',
        pendingCase: '.pending-case',
        assignedCase: '.assigned-case',
        fakeCase: '.fake-case',
        totalSubmittedCase: '.submitted-case',
        completeReport: '.complete-report',
    };

    function updateCounts(data) {
        Object.entries(mapping).forEach(([key, selector]) => {
            const el = document.querySelector(selector);
            if (el && data[key] !== undefined) el.innerText = data[key];
        });

        // Update Company chart
        if (donutCompanyChart && data.totalCompany !== undefined) {
            const updatedRemaining = totalMaxCompany - data.totalCompany;
            donutCompanyChart.data.datasets[0].data = [data.totalCompany, updatedRemaining];
            donutCompanyChart.update();
        }

        // Update Employee chart
        if (donutEmployeeChart && data.totalEmployee !== undefined) {
            const updatedRemaining = totalMaxEmployee - data.totalEmployee;
            donutEmployeeChart.data.datasets[0].data = [data.totalEmployee, updatedRemaining];
            donutEmployeeChart.update();
        }

        if (donutCaseChart && data.totalCase !== undefined) {
            const updatedRemaining = totalMaxCase - data.totalCase;
            donutCaseChart.data.datasets[0].data = [data.totalCase, updatedRemaining];
            donutCaseChart.update();
        }

           if (donutReportChart && data.completeReport !== undefined) {
            const updatedRemaining = totalMaxReport - data.completeReport;
            donutReportChart.data.datasets[0].data = [data.completeReport, updatedRemaining];
            donutReportChart.update();
        }

         if (donutAssignChart && data.assignedCase !== undefined) {
            const updatedRemaining = totalMaxAssign - data.assignedCase;
            donutAssignChart.data.datasets[0].data = [data.assignedCase, updatedRemaining];
            donutAssignChart.update();
        }

         if (donutPendingChart && data.pendingCase !== undefined) {
            const updatedRemaining = totalMaxPending - data.pendingCase;
            donutPendingChart.data.datasets[0].data = [data.pendingCase, updatedRemaining];
            donutPendingChart.update();
        }

         if (donutCompleteChart && data.completeCase !== undefined) {
            const updatedRemaining = totalMaxComplete- data.completeCase;
            donutCompleteChart.data.datasets[0].data = [data.completeCase, updatedRemaining];
            donutCompleteChart.update();
        }

          if (donutFakeChart && data.fakeCase !== undefined) {
            const updatedRemaining = totalMaxFake- data.fakeCase;
            donutFakeChart.data.datasets[0].data = [data.fakeCase, updatedRemaining];
            donutFakeChart.update();
        }

    }

    function updateCharts(data) {
        if (areaChart) {
            areaChart.updateSeries([{ name: 'Total Cases', data: data.casesCount }]);
        }
        if (pieChart) {
            pieChart.updateSeries([data.completeCase, data.pendingCase, data.assignedCase]);
        }
    }

    async function fetchCounts(filter, from = null, to = null) {
        try {
            const baseUrl = @json(route('dashboard.filter'));
            let url = `${baseUrl}?filter=${filter}`;
            if (from && to) url += `&from=${from}&to=${to}`;

            const res = await fetch(url);
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            const data = await res.json();

            // Init charts on first load
            if (!areaChart && !pieChart) {
                areaChart = new ApexCharts(document.querySelector("#basic-area"), {
                    chart: { type: 'area', height: 380, toolbar: { show: false } },
                    colors: ['#1ab394'],
                    dataLabels: { enabled: false },
                    stroke: { curve: 'straight', width: 2 },
                    fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.4, opacityTo: 0 } },
                    series: [{ name: 'Total Cases', data: data.casesCount }],
                    xaxis: { categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'] }
                });
                areaChart.render();

                pieChart = new ApexCharts(document.querySelector("#simple-pie"), {
                    chart: { type: 'donut', height: 320 },
                    series: [data.completeCase, data.pendingCase, data.assignedCase],
                    labels: ['Complete', 'Pending','Assigned'],
                    colors: ['#1ab394', '#ed5565','#0F6BF5'],
                    stroke: { colors: ['#ffffff'], width: 2 },
                    dataLabels: { enabled: true, style: { fontSize: '14px', fontWeight: '600', colors: ['#ffffff'] } },
                    plotOptions: { pie: { donut: { size: '70%', labels: { show: false } } } },
                    legend: { show: true, position: 'bottom', fontSize: '13px', fontWeight: 600 }
                });
                pieChart.render();
            } else {
                updateCharts(data);
            }

            updateCounts(data);
        } catch (e) {
            console.error('Error fetching filter data', e);
        }
    }

    // Trigger fetch when dropdown or dates change
    filterEl.addEventListener('change', () => fetchCounts(filterEl.value, fromDateEl.value, toDateEl.value));
    fromDateEl.addEventListener('change', () => { if (fromDateEl.value && toDateEl.value) fetchCounts(filterEl.value, fromDateEl.value, toDateEl.value); });
    toDateEl.addEventListener('change', () => { if (fromDateEl.value && toDateEl.value) fetchCounts(filterEl.value, fromDateEl.value, toDateEl.value); });

    // Default load
    updateCounts({ totalCompany, totalEmployee });
    fetchCounts(filterEl.value || 'all', fromDateEl.value || null, toDateEl.value || null);
});

</script>

<script>


  document.addEventListener('DOMContentLoaded', function () {
        const totalCompany = {{ $totalCompany }};
        const totalMax = 100; // You can change this to real max or dynamic total
        const remaining = totalMax - totalCompany;

        const ctx = document.getElementById('donutCompanyChart').getContext('2d');

        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Companies', 'Remaining'],
                datasets: [{
                    data: [totalCompany, remaining],
                                        backgroundColor: ['#0F6BF5', '#E0E0E0'],

                    borderWidth: 0
                }]
            },
            options: {
                cutout: '70%', // how thick the ring is
                responsive: true,
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: false }
                }
            }
        });
    });

    document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#fromDate", {
        allowInput: false,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("fromDate").value // use DB value
    });
});



document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#toDate", {
        allowInput: false,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("toDate").value // use DB value
    });
});

</script>


@endsection
