@extends('dashboard.layout.app')
@section('title', 'User List')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-users me-2 text-primary"></i> User List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Users</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('user.create') }}" class="btn btn-primary">
                <i class="fa-solid fa-user-plus me-1"></i> Add User
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fa-solid fa-users me-2"></i> Manage Users</h5>
              <form id="statusForm" method="GET" class="d-flex align-items-center gap-3 mb-0">
    <div class="form-check form-check-inline">
        <!-- <input class="form-check-input" 
               type="radio" 
               name="status" 
               id="statusActive" 
               value="1"
               {{ (string) request('status') === '1' ? 'checked' : '' }}
               onchange="document.getElementById('statusForm').submit();">
        <label class="form-check-label text-white" for="statusActive">Active</label> -->

        <input class="form-check-input" 
       type="radio" 
       name="status" 
       id="statusActive" 
       value="1"
       {{ request('status') === '1' || request('status') === null ? 'checked' : '' }}
       onchange="document.getElementById('statusForm').submit();">
<label class="form-check-label text-white" for="statusActive">Active</label>

    </div>

    <div class="form-check form-check-inline">
        <input class="form-check-input" 
               type="radio" 
               name="status" 
               id="statusInactive" 
               value="0"
               {{ (string) request('status') === '0' ? 'checked' : '' }}
               onchange="document.getElementById('statusForm').submit();">
        <label class="form-check-label text-white" for="statusInactive">Inactive</label>
    </div>
</form>


            </div>

            <div class="card-body">
                @if($users->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered align-middle" id="userTable">
                            <thead class="thead-dark text-center">
                                <tr>
                                    <th style="width:5px;">Sl No</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                             
                                 
                                    <th style="width: 100px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($users as $index => $user)
                                    <tr>
                                     <td style="width:5px; text-align:center;">{{ 'USR' . str_pad($user->id, 6, '0', STR_PAD_LEFT) }}</td>
                                        <td style="width:5px; text-align:center;">{{ $user->name }}</td>
                                        <td style="width:5px; text-align:center;">{{ $user->email }}</td>
                                        <td style="width:5px; text-align:center;">
                                            @if($user->role == 2)
                                                <span class="badge bg-info">Sub Admin</span>
                                            @elseif($user->role == 3)
                                                <span class="badge bg-secondary">Executive</span>
                                            @else
                                                <span class="badge bg-dark">N/A</span>
                                            @endif
                                        </td>
                                   
                                     


                                        <td class="text-center">
                                           
                                 
    <a href="{{ route('user.edit', $user->id) }}"
       class="btn btn-sm btn-outline-primary"
       title="Edit User">
        <i class="fa-solid fa-pen-to-square"></i>
    </a>

    @if ($user->status == 0)
        <!-- <span class="badge bg-danger" style="margin-left: 10px;">UnBlock</span> -->


        <button type="button" 
                class="btn btn-sm btn-outline-secondary" 
                data-bs-toggle="modal" 
                data-bs-target="#unblockUserModal" 
                data-user-id="{{ $user->id }}"
                title="Un Block User" 
                style="margin-left: 10px;">
            <i class="fa-solid fa-ban" style="margin-right: 5px;"></i> UnBlock
        </button>


    @else
        <button type="button" 
                class="btn btn-sm btn-outline-danger" 
                data-bs-toggle="modal" 
                data-bs-target="#blockUserModal" 
                data-user-id="{{ $user->id }}"
                title="Block User" 
                style="margin-left: 10px;">
            <i class="fa-solid fa-ban" style="margin-right: 5px;"></i> Block
        </button>
    @endif


                                            
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="alert alert-warning mb-0 text-center">
                        <i class="fa-solid fa-circle-exclamation me-1"></i> No users found.
                    </div>
                @endif
            </div>

            <!-- Pagination -->
           
        </div>
    </div>
</div>







<!-- Modal -->
<div class="modal fade" id="blockUserModal" tabindex="-1" aria-labelledby="blockUserModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="blockUserForm" method="POST" action="">
      @csrf
      @method('POST')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="blockUserModalLabel">Confirm Block</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <p>Are you sure you want to block this user?</p>

          <!-- Block reason textarea -->
          <div class="mb-3">
            <label for="block_reason" class="form-label fw-bold">Reason / Description <span class="text-danger">*</span></label>
            <textarea 
              name="block_reason" 
              id="block_reason" 
              class="form-control" 
              rows="3" 
              placeholder="Enter reason for blocking this user" 
              required></textarea>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>




<div class="modal fade" id="unblockUserModal" tabindex="-1" aria-labelledby="unblockUserModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="unblockUserForm" method="POST" action="">
      @csrf
      @method('POST')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="unblockUserModalLabel">Confirm UnBlock</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Are you sure you want to un-block this user?
        </div>
        <div class="modal-footer">
             <button type="submit" class="btn btn-danger">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
         
        </div>
      </div>
    </form>
  </div>
</div>




<!-- DataTables CSS (Bootstrap 5 theme) -->


<!-- jQuery (needed for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">


<style>
.form-check-input:checked {
    background-color: #513fff;
    /* border-color: #3f6bff; */
}

div.dt-container
{
    margin-top: 0.375rem;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var blockUserModal = document.getElementById('blockUserModal');
    blockUserModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // Button that triggered the modal
        var userId = button.getAttribute('data-user-id');

        var form = document.getElementById('blockUserForm');
        form.action = `/user/block/${userId}`; // Update this if using named route
    });
});

document.addEventListener('DOMContentLoaded', function () {
    var blockUserModal = document.getElementById('unblockUserModal');
    blockUserModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // Button that triggered the modal
        var userId = button.getAttribute('data-user-id');

        var form = document.getElementById('unblockUserForm');
        form.action = `/user/unblock/${userId}`; // Update this if using named route
    });
});

</script>



<script>
    $(document).ready(function () {
        const table = $('#userTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search users..."
                },
                columnDefs: [
                    { orderable: false, targets: [4] } // Disable sort on "Action" column
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }

        // Status filter submit
        $('#statusActive, #statusInactive').on('change', function () {
            $('#statusForm').submit();
        });
    });
</script>
@endsection
