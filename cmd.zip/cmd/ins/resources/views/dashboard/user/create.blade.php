@extends('dashboard.layout.app')
@section('title', 'Add User')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-plus me-2 text-primary"></i> Add User
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('user.list') }}">Users</a></li>
                    <li class="breadcrumb-item active">Add User</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-plus me-2"></i>
                            <h5 class="mb-0">Add User</h5>

            <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none"  style="margin-left: 20px;align-items: center;">
            <i class="fa fa-check-circle me-2"></i>
            <span id="successText"></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>


                        </div>
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                           
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Add User Form -->
                   
                        
<form id="addUser" action="{{ route('user.store') }}" method="POST" novalidate enctype="multipart/form-data">
    @csrf

    <!-- Name -->
   <!-- Name -->
<div class="mb-3">
    <label for="name" class="form-label fw-bold">Name <span class="text-danger">*</span></label>
    <input type="text" 
           class="form-control" 
           id="name" 
           name="name" 
           value="{{ old('name') }}"
           placeholder="Enter name" 
           required>
    <span id="name-error" class="text-danger error"></span>
</div>

<!-- Email -->
<div class="mb-3">
    <label for="email" class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
    <input type="email" 
           class="form-control" 
           id="email" 
           name="email" 
           value="{{ old('email') }}"
           placeholder="Enter email" 
           required>
    <span id="email-error" class="text-danger error"></span>
</div>

<!-- Phone -->





<div class="mb-3">
    <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
    <div class="d-flex align-items-center gap-2">
        <!-- Country Code -->
        <select id="country_code" name="country_code" class="select2 form-select form-select-sm" data-placeholder="Code">
            <option></option>
            <option value="+91" selected>+91 (India)</option>
            <option value="+1">+1 (USA)</option>
            <option value="+44">+44 (UK)</option>
            <option value="+61">+61 (Australia)</option>
            <option value="+971">+971 (UAE)</option>
            <option value="+81">+81 (Japan)</option>
            <option value="+49">+49 (Germany)</option>
        </select>

        <!-- Phone Number -->
        <input type="text"  class="form-control" 
       id="phone" 
       name="phone" 
       value="{{ old('phone') }}"
       placeholder="Enter contact number" 
       required 
       maxlength="15"
       inputmode="numeric"
       oninput="validatePhoneInput(this)">
    </div>
    <div id="phoneError" class="text-danger mt-1" style="display:none;">
        Please enter digits only (0-9).
    </div>
</div>



<!-- Place -->
<div class="mb-3">
    <label for="place" class="form-label fw-bold">Place <span class="text-danger">*</span></label>
    <input type="text" 
           class="form-control" 
           id="place" 
           name="place" 
           value="{{ old('place') }}"
           placeholder="Enter place" 
           required>
    <span id="place-error" class="text-danger error"></span>
</div>



<div class="mb-3">
    <label for="address" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
    <textarea 
        class="form-control" 
        id="address" 
        name="address" 
        rows="3" 
        placeholder="Enter full address" 
        required>{{ old('address') }}</textarea>
    <span id="address-error" class="text-danger error"></span>
</div>

<div class="mb-3">
    <label for="blood" class="form-label fw-bold">Blood Group <span class="text-danger">*</span></label>
    <input type="text" 
           class="form-control" 
           id="blood" 
           name="blood" 
           value="{{ old('blood') }}"
           placeholder="Enter Blood Group" 
           required>
    <span id="blood-error" class="text-danger error"></span>
</div>


<div class="mb-3">
    <label for="date_of_birth" class="form-label fw-bold">Date of Birth <span class="text-danger">*</span></label>
    <input type="text" 
           class="form-control" 
           id="date_of_birth" 
           name="date_of_birth" required>
    <span id="date_of_birth-error" class="text-danger error"></span>
</div>

<div class="mb-3">
    <label for="join_date" class="form-label fw-bold">Joining Date<span class="text-danger">*</span></label>
    <input type="text" 
           class="form-control" 
           id="join_date" 
           name="join_date" 
           
           required>
    <span id="join_date-error" class="text-danger error"></span>
</div>



<div class="mb-3">
    <label for="profile_picture" class="form-label fw-bold">Profile Picture <span class="text-danger">*</span></label>
    <input type="file" 
           class="form-control" 
           id="profile_picture" 
           name="profile_picture" 
           accept="image/*" 
           required>
    <span id="profile_picture-error" class="text-danger error"></span>
</div>



<!-- Role -->
<div class="mb-3">
    <label for="role" class="form-label fw-bold">Role <span class="text-danger">*</span></label>
    <select id="role" 
            name="role" 
            class="form-select" 
            required>
        <option value="">-- Select Role --</option>
        <option value="3" {{ old('role') == 3 ? 'selected' : '' }}>Executive</option>
        <option value="2" {{ old('role') == 2 ? 'selected' : '' }}>Sub Admin</option>
    </select>
    <span id="role-error" class="text-danger error"></span>
</div>

<!-- Password -->
<div class="mb-4">
    <label for="password" class="form-label fw-bold">Password <span class="text-danger">*</span></label>
    <input type="password" 
           class="form-control" 
           id="password" 
           name="password" 
           placeholder="Enter password"
           required>
    <span id="password-error" class="text-danger error"></span>
</div>


    <!-- Submit -->
    <div class="text-end">
        <button type="submit" class="btn btn-success">
            <i class="fa fa-save me-1"></i> Add User
        </button>
    </div>
</form>


                        <!-- End Form -->
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>



<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Bootstrap 5 theme for Select2 -->
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />

<!-- jQuery (only once!) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<link rel="stylesheet" href="{{ asset('assets/plugins/daterangepicker/daterangepicker.css')}}" type="text/css">



<style>
    .select2-container
    {
width:281.547px !important;
    }
    </style>



<script>


   $('#country_code').select2({
        theme: 'bootstrap-5',
        width: 'resolve',           // fit the select box container
        placeholder: $('#country_code').data('placeholder'),
        allowClear: true,
        minimumResultsForSearch: 0 // always show search box
    });


    
   $('#addUser').on('submit', function (e) {
    e.preventDefault();

    var form = $(this)[0]; // Get the form DOM element
    var formData = new FormData(form); // Create FormData object

    $.ajax({
        url: '{{ route('user.store') }}',
        type: 'POST',
        data: formData,
        processData: false, // Important for file upload
        contentType: false, // Important for file upload
        cache: false,
        success: function (response) {
            if (response.success) {
                $('#successMessage')
                    .removeClass('d-none alert-danger')
                    .addClass('alert alert-success')
                    .fadeIn();
                $('#successText').text(response.success);
                $('html, body').animate({
                    scrollTop: $("#successMessage").offset().top - 100
                }, 500);
                $('#addUser')[0].reset();
                $('.form-control').removeClass('is-invalid');
                $('.error').text('');

                setTimeout(function () {
                    window.location.href = response.redirect_url;
                }, 2500);
            }
        },
        error: function (xhr) {
            if (xhr.status === 422) {
                var errors = xhr.responseJSON.errors;
                $('.error').text('');
                $('.form-control').removeClass('is-invalid');

                $.each(errors, function (key, value) {
                    $('#' + key).addClass('is-invalid');
                    $('#' + key + '-error').text(value[0]);
                });
            }
        }
    });
});


  function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }


  document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#join_date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("join_date").value // use DB value
    });
});


document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#date_of_birth", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("date_of_birth").value // use DB value
    });
});

</script>



@endsection