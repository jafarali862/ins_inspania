@php
    use Illuminate\Support\Str;
    $grouped = $template->questions->groupBy('data_category');
@endphp

<h5 style="font-size: 16px;">Template ID: {{ $template->template_id }}</h5>
<hr>

@foreach($grouped as $category => $questions)
    <h6 class="mt-3">
        <b style="font-weight: 700;font-size: 13px;">{{ Str::title(str_replace('_', ' ', $category)) }}</b>
    </h6>
    <ul class="list-group mb-3">
        @foreach($questions as $question)
            <li class="list-group-item">
                {{ $question->question }}
            </li>
        @endforeach
    </ul>
@endforeach

@if($grouped->isEmpty())
    <div class="text-muted">No questions found</div>
@endif
