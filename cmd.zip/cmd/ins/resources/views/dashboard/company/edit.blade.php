@extends('dashboard.layout.app')
@section('title', 'Edit Company')

@section('content')


<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-edit me-2 text-primary"></i> Edit Company
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('company.list') }}">Company</a></li>
                    <li class="breadcrumb-item active">Edit Company</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
        <div class="col-lg-8 col-md-10">
        <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
        <i class="fa fa-user-edit me-2"></i>
        <h5 class="mb-0">Edit Company</h5>

        <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
        style="margin-left: 20px;align-items: center;">
        <i class="fa fa-check-circle me-2"></i>
        <span id="successText"></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
        </div>
        <!-- Action Buttons -->
        <div class="d-flex gap-2">
        <a href="{{ route('user.list') }}" class="btn btn-danger btn-sm">
        <i class="fa fa-arrow-left me-1"></i> Back
        </a>
        <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
        <i class="fa fa-sync me-1"></i> Reload
        </a>
        </div>
        </div>
        <div class="card-body">

        <form method="POST" action="{{ route('company.update') }}" id="updateCompany" novalidate>
        @csrf
        <input type="hidden" name="id" value="{{ $company->id }}" required>

        <!-- Company Name -->
        <div class="mb-3">
        <label for="name" class="form-label fw-bold">Company Name <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="name" name="name" 
        value="{{ old('name', $company->name) }}" placeholder="Enter company name" required>
        <span class="text-danger error" id="name-error"></span>
        </div>

    <!-- Tabs Card -->
    <div class="card mb-3">
        <div class="card-header p-2">
            <ul class="nav nav-pills" id="insuranceTabs" role="tablist">
                @foreach(['garage', 'driver', 'spot', 'meeting', 'accident'] as $tabId)
                <li class="nav-item" role="presentation">
                    <a class="nav-link {{ $loop->first ? 'active' : '' }}" 
                       id="{{ $tabId }}-tab" 
                       data-bs-toggle="tab" 
                       href="#{{ $tabId }}" 
                       role="tab" 
                       aria-controls="{{ $tabId }}" 
                       aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                       {{ ucfirst($tabId) }} Data
                    </a>
                </li>
                @endforeach
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content" id="insuranceTabsContent">
                @foreach(['garage', 'driver', 'spot', 'meeting', 'accident'] as $tabId)
                <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}" 
                     id="{{ $tabId }}" 
                     role="tabpanel" 
                     aria-labelledby="{{ $tabId }}-tab">
                    <!-- Add your tab content here -->
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <!-- Contact Person -->
    <div class="mb-3">
        <label for="contact_person" class="form-label fw-bold">Contact Person <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="contact_person" name="contact_person" 
               value="{{ old('contact_person', $company->contact_person) }}" 
               placeholder="Enter contact person" required>
        <span class="text-danger error" id="contact_person-error"></span>
    </div>

    <!-- Email -->
    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
        <input type="email" class="form-control" id="email" name="email" 
               value="{{ old('email', $company->email) }}" 
               placeholder="Enter email address" required>
        <span class="text-danger error" id="email-error"></span>
    </div>

    <!-- Phone -->






          <div class="mb-3">
          <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
          <div class="d-flex align-items-center gap-2">
          <!-- Country Code -->
          <select id="country_code" name="country_code" class="select2 form-select form-select-sm" data-placeholder="Code">
          <option></option>
          <option value="+91" selected>+91 (India)</option>
          <option value="+1">+1 (USA)</option>
          <option value="+44">+44 (UK)</option>
          <option value="+61">+61 (Australia)</option>
          <option value="+971">+971 (UAE)</option>
          <option value="+81">+81 (Japan)</option>
          <option value="+49">+49 (Germany)</option>
          </select>

          <!-- Phone Number -->
          <input type="text"   class="form-control" 
          id="phone" 
          name="phone" 
          value="{{ old('phone', $company->phone) }}" 
          placeholder="Enter contact number" 
          required 
          maxlength="15"
          inputmode="numeric"
          oninput="validatePhoneInput(this)">
          </div>
          <div id="phoneError" class="text-danger mt-1" style="display:none;">
          Please enter digits only (0-9).
          </div>
          </div>


    <!-- Address -->
    <div class="mb-3">
        <label for="address" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
        <textarea class="form-control" id="address" name="address" rows="3" 
                  placeholder="Enter address" required>{{ old('address', $company->address) }}</textarea>
        <span class="text-danger error" id="address-error"></span>
    </div>

    <!-- Status -->
    <div class="mb-3">
        <label for="status2" class="form-label fw-bold">Status <span class="text-danger">*</span></label>
        <select class="form-select" id="status2" name="status2" required>
            <option value="1" {{ old('status2', $company->status) == '1' ? 'selected' : '' }}>Active</option>
            <option value="0" {{ old('status2', $company->status) == '0' ? 'selected' : '' }}>Inactive</option>
        </select>
        <span class="text-danger error" id="status-error"></span>
    </div>

    <!-- Template Selection -->
            <div class="mb-3">
            <label for="selectTemplate" class="form-label fw-bold">Select Final Report Template <span class="text-danger">*</span></label>
            <select class="form-select" id="selectTemplate" name="template" required>
            <option value="" disabled {{ empty($company->template) ? 'selected' : '' }}>Please select</option>
            @foreach ($templates as $template)
            <option value="{{ $template->id }}" {{ $company->template == $template->id ? 'selected' : '' }}>
            {{ $template->template_id }}
            </option>
            @endforeach
            </select>
            <span class="text-danger error" id="template-error"></span>
            </div>

            <!-- Submit Buttons -->
            <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Update Company</button>
            <a href="{{ route('company.list') }}" class="btn btn-secondary">Cancel</a>
            </div>
</form>


        </div>
        </div>
        </div>
        </div>
        </div>

<style>
  .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active
 {
    color: #ffffff;
    background-color: #6c6c6c;
    border-color: #dee2e6 #dee2e6 #fff;
}

.select2-container
{
width:281.547px !important;
}

</style>

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Bootstrap 5 theme for Select2 -->
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />

<!-- jQuery (only once!) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>


  $('#country_code').select2({
  theme: 'bootstrap-5',
  width: 'resolve',           // fit the select box container
  placeholder: $('#country_code').data('placeholder'),
  allowClear: true,
  minimumResultsForSearch: 0 // always show search box
  });


window.existingSelections = @json($questionnaires ?? []);

const categoryMap = {
  garage: 'garage_data',
  driver: 'driver_data',
  spot: 'spot_data',
  meeting: 'owner_data',
  accident: 'accident_person_data',
};


document.addEventListener('DOMContentLoaded', () => {
  const selectTemplate = document.getElementById('selectTemplate');
  const tabs = document.querySelectorAll('#insuranceTabs .nav-link');

  let cachedQuestionsByCategory = null;

  function resetTabs() {
    Object.keys(categoryMap).forEach(tabId => {
      const pane = document.getElementById(tabId);
      if (pane) {
        pane.innerHTML = '';
        pane.dataset.loaded = '';
      }
    });
    cachedQuestionsByCategory = null;
  }

  function renderQuestionsForTab(tabId, questions) {
    const tabPane = document.getElementById(tabId);
    if (!tabPane) return;

    let html = `<h5 class="mb-3">${categoryMap[tabId].replace(/_/g, ' ').toUpperCase()}</h5>`;

    questions.forEach(q => {
     const existingForTab = window.existingSelections[tabId] || [];
const checked = Array.isArray(existingForTab) && existingForTab.includes(q.column_name) ? 'checked' : '';



      const colId = `check_${tabId}_${q.column_name}`;
      let fileTypeInput = '';
      if (q.input_type === 'file' && q.file_type) {
        fileTypeInput = `<input type="hidden" name="file_types[${tabId}][${q.column_name}]" value="${q.file_type}">`;
      }

      html += `
        <div class="form-check mb-2">
          <input class="form-check-input" type="checkbox" style="border-color: #424141;"
                 name="selected_questions[${tabId}][]"
                 value="${q.column_name}"
                 id="${colId}" ${checked}>

          <input type="hidden"
                 name="question_types[${tabId}][${q.column_name}]"
                 value="${q.input_type}">

          ${fileTypeInput}

          <label class="form-check-label" for="${colId}">
            ${q.question}
          </label>
        </div>`;
    });

    tabPane.innerHTML = html;
    tabPane.dataset.loaded = 'true';
  }

  function loadQuestions(templateId, tabId) {
    if (!templateId) return;

    if (cachedQuestionsByCategory) {
      const catName = categoryMap[tabId];
      const questions = cachedQuestionsByCategory[catName] || [];
      renderQuestionsForTab(tabId, questions);
      return;
    }

    fetch(`/template/${templateId}/questions`)
      .then(res => {
        if (!res.ok) throw new Error(`HTTP ${res.status} - ${res.statusText}`);
        return res.json();
      })
      .then(data => {
        cachedQuestionsByCategory = data.questions_by_category || {};
        const catName = categoryMap[tabId];
        const questions = cachedQuestionsByCategory[catName] || [];
        renderQuestionsForTab(tabId, questions);
      })
      .catch(err => {
        const pane = document.getElementById(tabId);
        if (pane) {
          pane.innerHTML = `<div class="alert alert-danger">Could not load questions. ${err.message}</div>`;
        }
        console.error(err);
      });
  }

  selectTemplate.addEventListener('change', () => {
    resetTabs();
    const activeTab = document.querySelector('#insuranceTabs .nav-link.active');
    if (!activeTab) return;
    const target = activeTab.getAttribute('data-bs-target') || activeTab.getAttribute('href');
    const tabId = target.startsWith('#') ? target.substring(1) : target;
    loadQuestions(selectTemplate.value, tabId);
  });

  tabs.forEach(tab => {
    tab.addEventListener('shown.bs.tab', () => {
      const templateId = selectTemplate.value;
      if (!templateId) return;
      const target = tab.getAttribute('data-bs-target') || tab.getAttribute('href');
      const tabId = target.startsWith('#') ? target.substring(1) : target;
      loadQuestions(templateId, tabId);
    });
  });

  // Initial load if template and tab active on page load
  if (selectTemplate.value) {
    const activeTab = document.querySelector('#insuranceTabs .nav-link.active');
    if (activeTab) {
      const target = activeTab.getAttribute('data-bs-target') || activeTab.getAttribute('href');
      const tabId = target.startsWith('#') ? target.substring(1) : target;
      loadQuestions(selectTemplate.value, tabId);
    }
  }
});

</script>






<script>
  $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#updateCompany').on('submit', function (e) {
            e.preventDefault();

            $.ajax({
                url: '{{ route('company.update') }}',
                type: 'POST',
                data: $(this).serialize(),
              success: function (response) {
    if (response.success) {
        $('#successMessage')
            .removeClass('d-none alert-danger')
            .addClass('alert alert-success')
            .fadeIn();
        $('#successText').text(response.success);
       $('html, body').animate({
        scrollTop: $("#successMessage").offset().top - 100
    }, 500);
        // Reset form
        $('#updateCompany')[0].reset();
        $('.form-control').removeClass('is-invalid');
        $('.error').text('');

        setTimeout(function () {
            window.location.href = response.redirect_url;
        }, 2500);
    }
},

                error: function (xhr) {
                    if (xhr.status === 422) {
                        var errors = xhr.responseJSON.errors;

                        $('.error').text('');
                        $('.form-control').removeClass('is-invalid');

                        $.each(errors, function (key, value) {
                            $('#' + key).addClass('is-invalid');
                            $('#' + key + '-error').text(value[0]);
                        });
                    }
                }
            });
        });
    });


    function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }

</script>

@endsection
