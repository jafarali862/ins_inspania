<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\InsuranceCompany;
use App\Models\User;
use App\Models\InsuranceCase;
use Illuminate\Http\Request;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Models\CaseAssignment;
use App\Models\AssignWorkData;

class AuthController extends Controller
{
    public function loginForm()
    {
        return view("Auth.login");
    }

    public function registerForm()
    {
        return view("Auth.register");
    }

    public function register(Request $request)
    {
        $request->validate([
            "name" => "required",
            "phone" => "required|max:10",
            "email" => "required|email|unique:users,email",
            "password" => [
                "required",
                "min:8",
                "regex:/[A-Z]/",
                "regex:/[a-z]/",
                "regex:/[0-9]/",
                "regex:/[@$!%*?&#^()_+=-]/",
            ],
            "password_confirmation" => "required|same:password",
        ]);

        User::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email, 
            'password' => Hash::make($request->password),
            'role' => 1,
            'status' => 1,
        ]);

        return redirect()->route('login.form');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required ',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->route('dashboard');
        }
        return redirect()->route('login.form')->with(['error' => 'Invalid username or password. Try again.']);
    }

    public function dashboard()
{
   $totalEmployee = User::where('role', '<>', 1)
                     ->where('status', '<>', 0)
                     ->count();
    $totalCompany     = InsuranceCompany::count();
    $totalCase        = InsuranceCase::count();
    $completeCase     = InsuranceCase::where('case_status', 0)->count();
    $pendingCase      = InsuranceCase::where('case_status', 1)->count(); 
    $assignedCase     = InsuranceCase::where('case_status', 2)->count();
    $fakeCase         = CaseAssignment::where('is_fake', 1)->count();
    $totalSubmittedCase = InsuranceCase::where('case_status', 0)->count();

    $currentYear = Carbon::now()->year;

    $totalcaseCount = DB::table('insurance_customers')
        ->leftJoin('insurance_cases', 'insurance_customers.id', '=', 'insurance_cases.customer_id')
        ->leftJoin('insurance_companies', 'insurance_companies.id', '=', 'insurance_customers.company_id')
        ->count();

    $completeReport=DB::table('final_reports')->count();

    $data = InsuranceCase::selectRaw('MONTH(created_at) as month, COUNT(*) as case_count')
        ->whereYear('created_at', $currentYear)
        ->groupBy('month')
        ->orderBy('month')
        ->get();

    $casesCount = array_fill(0, 12, 0);
    foreach ($data as $item) {
        $casesCount[$item->month - 1] = $item->case_count;
    }

    return view('dashboard.index')->with([
        'totalEmployee'      => $totalEmployee,
        'totalCompany'       => $totalCompany,
        'totalCase'          => $totalCase,
        'completeCase'       => $completeCase,
        'pendingCase'        => $pendingCase,
        'casesCount'         => $casesCount,
        'currentYear'        => $currentYear,
        'assignedCase'       => $assignedCase,
        'fakeCase'           => $fakeCase,
        'totalSubmittedCase' => $totalSubmittedCase,
        'completeReport'=>$completeReport
        // 'totalcaseCount'     => $totalcaseCount,
    ]);
}


public function dashboard_filter(Request $request)
{
    $filter = $request->get('filter', 'all');
    $from   = $request->get('from');
    $to     = $request->get('to');

    if ($from && $to) {
        $start = Carbon::parse($from)->startOfDay();
        $end   = Carbon::parse($to)->endOfDay();
    } elseif ($filter === 'daily') {
        $start = Carbon::today();
        $end   = Carbon::today()->endOfDay();
    } elseif ($filter === 'weekly') {
        $start = Carbon::now()->startOfWeek();
        $end   = Carbon::now()->endOfWeek();
    } elseif ($filter === 'monthly') {
        $start = Carbon::now()->startOfMonth();
        $end   = Carbon::now()->endOfMonth();
    } else {
        $start = $end = null;
    }

    $totalEmployee = User::where('role', '!=', 1)
                     ->where('status', '!=', 0)
                     ->when($start && $end, fn($q) => $q
                    ->whereBetween('created_at', [$start, $end]))
                     ->count();

    $totalCompany = InsuranceCompany::when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();
    $totalCase = InsuranceCase::when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();
    $completeCase = InsuranceCase::where('case_status', 0)
        ->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();
    $pendingCase = InsuranceCase::where('case_status', 1)
        ->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();
    $assignedCase = InsuranceCase::where('case_status', 2)
        ->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();
    $fakeCase = CaseAssignment::where('is_fake', 1)
        ->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();
    $totalSubmittedCase = InsuranceCase::where('case_status', 0)
        ->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();

    
    $completeReport=DB::table('final_reports')->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))->count();

    $currentYear = Carbon::now()->year;
    $caseData = InsuranceCase::selectRaw('MONTH(created_at) as month, COUNT(*) as case_count')
        ->when($start && $end, fn($q) => $q->whereBetween('created_at', [$start, $end]))
        ->whereYear('created_at', $currentYear)
        ->groupBy('month')
        ->orderBy('month')
        ->get();

    $casesCount = array_fill(0, 12, 0);
    foreach ($caseData as $item) $casesCount[$item->month - 1] = $item->case_count;

    return response()->json([
        'totalEmployee' => $totalEmployee,
        'totalCompany' => $totalCompany,
        'totalCase' => $totalCase,
        'completeCase' => $completeCase,
        'pendingCase' => $pendingCase,
        'assignedCase' => $assignedCase,
        'fakeCase' => $fakeCase,
        'totalSubmittedCase' => $totalSubmittedCase,
        'casesCount' => $casesCount,
         'completeReport'=>$completeReport
    ]);
}

    // public function logout(Request $request)
    // {
    //     Auth::logout();
    //     $request->session()->invalidate();
    //     return redirect()->route('login')->with(['success' => 'Successfully logged out!']);
    // }

    public function logout(Request $request)
{
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken(); // Also regenerate CSRF token for security

    return redirect()->route('login')->with(['success' => 'Successfully logged out!']);
}

}
