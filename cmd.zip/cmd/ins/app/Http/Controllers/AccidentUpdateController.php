<?php

namespace App\Http\Controllers;

use App\Models\AccidentPersonData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;


class AccidentUpdateController extends Controller
{
   

    public function updateAccidentDatanew(Request $request)
    {
        
        
   Log::info('Received updateAccidentDatanew request', $request->all());

    // Get selected field (expected format: field_name:garageId)
    $selected = $request->input('selected_field');

    if (!$selected || !str_contains($selected, ':')) {
        Log::error('Invalid selected_field format or missing.');
        return back()->withErrors(['error' => 'Please select an accident record to update.']);
    }

    // Split into field name and garage ID
    [$fieldName, $garageId] = explode(':', $selected);

    // Sanitize the field name to allow only valid characters
    $fieldName = preg_replace('/[^a-zA-Z0-9_]/', '', $fieldName);
    Log::info('Parsed selected_field', [
        'field' => $fieldName,
        'garageId' => $garageId
    ]);

    // Try to find the related record
    $garage = AccidentPersonData::find($garageId);

    if (!$garage) {
        Log::error("AccidentPersonData record not found for ID: $garageId");
        return back()->withErrors(['error' => 'Accident record not found.']);
    }

    // Prepare input field keys
    $inputKey = "field_value.$garageId.$fieldName";
    $otherKey = "other_value.$garageId.$fieldName";
    Log::info('Input keys', compact('inputKey', 'otherKey'));

    $finalValue = null;

    // Check if the field is a file upload
    if ($request->hasFile($inputKey)) {
        $file = $request->file($inputKey);
        $path = $file->store('spot_uploads', 'public');
        $finalValue = $path;

        Log::info('File uploaded successfully', [
            'path' => $path,
            'field' => $fieldName
        ]);
    }

    // Check if the field is a normal input
    elseif ($request->filled($inputKey)) {
        $value = $request->input($inputKey);

        Log::info('Form field value received', ['value' => $value]);

        if ($value === 'Other') {
            if ($request->filled($otherKey)) {
                $finalValue = $request->input($otherKey);
                Log::info('Other field value used', ['otherValue' => $finalValue]);
            } else {
                Log::error("Other value expected but not provided for key: $otherKey");
                return back()->withErrors(['error' => 'Other value selected but no input provided.']);
            }
        } else {
            $finalValue = $value;
        }
    }

    // No valid input found
    else {
        Log::error('No valid input or file provided to update', [
            'inputKey' => $inputKey,
            'requestData' => $request->all()
        ]);
        return back()->withErrors(['error' => 'No valid input found to update.']);
    }

    // Update the model field with final value
    $garage->$fieldName = $finalValue;
    $garage->save();

    Log::info('AccidentPersonData updated successfully', [
        'id' => $garageId,
        'field' => $fieldName,
        'new_value' => $finalValue
    ]);

    return back()->with('success', 'Accident Data Updated Successfully!');

    }

    public function accidentSpecialCase($id)
    {
        $accidentData = AccidentPersonData::findOrFail($id);
        $accidentData->sp_case = 1;
        $accidentData->save();
        return back()->with('success', 'Accident Person section data Reasigned successfully!');
    }
}
