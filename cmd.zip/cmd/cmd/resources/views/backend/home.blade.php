@extends('backend.layouts.app')

@section('content')

<!-- /.content-header -->

<!-- Main content -->
<div class="content-wrapper">
    <section class='content'>
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$userCount}}</h3>
                            <p>Total Users</p>
                        </div>
                        <div class="icon">
                          <i class="ion ion-person-add"></i>
                        </div>
                        <a href="{{route('users.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>{{$clinicCount}}</h3>
                            <p>Total Laboratory</p>
                        </div>
                        <div class="icon">
                              <i class="ion ion-erlenmeyer-flask"></i>
                        </div>
                        <a href="{{route('clinic')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{$pharmacyCount}}</h3>
                            <p>Total Pharmacies</p>
                        </div>
                        <div class="icon">
                           <i class="fas fa-clinic-medical"></i>
                        </div>
                        <a href="{{route('pharmacies.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                 
                <!-- <div class="col-lg-3 col-6">
                  
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>{{$medicineCount}}</h3>
                            <p>Total Medicine</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('medicines.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div> -->


                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$clinicPresCount}}</h3>
                            <p>New Laboratory Prescription</p>
                        </div>
                        <div class="icon">
                           <i class="ion ion-pie-graph"></i> <!-- Best for lab-related features -->

                        </div>
                        <a href="{{route('clinic-prescriptions.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{$pharmacyPresCount}}</h3>
                            <p>New Pharmacy Prescription</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('pharmacy-prescriptions.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                 <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning" style="padding-bottom: 30px;background-color: #4de9c3 !important;">
                        <div class="inner">
                            <h3>{{$smsBalance}}</h3>
                            <p>SMS Balance</p>
                        </div>
                        <div class="icon">
                             <i class="ion ion-chatbubbles"></i>
                        </div>
                        <!-- <a href="#" class="small-box-footer"><i class="fas fa-arrow-circle-right"></i></a> -->
                    </div>
                </div>


                <!-- ./col -->
            </div>

            <!-- Charts Row -->
           
    <!-- Charts Row -->
            <div class="row mt-5">
                <div class="col-md-6">
                    <!-- Pie Chart -->
                    <!-- <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h3 class="card-title">Category Distribution</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div> -->

                    <div class="card">
  <div class="card-header bg-primary text-white">
    <h3 class="card-title">Category Distribution</h3>
  </div>
  <div class="card-body">
    <!-- Chart label -->
    <!-- <h5 id="chartLabel" class="mb-3">Clinic Prescription</h5> -->

    <!-- Toggle button -->
    <!-- <button id="toggleChartBtn2" class="btn btn-primary mb-3">Show Pharmacy Prescriptions</button> -->

        <div class="mb-3">
       
        <input type="radio" name="chartType" value="clinic" id="clinicRadio" checked>
        <label for="clinicRadio">Clinic Prescriptions</label>

        <input type="radio" name="chartType" value="pharmacy" id="pharmacyRadio">
        <label for="pharmacyRadio">Pharmacy Prescriptions</label>
        </div>

<!-- <canvas id="myPieChart" width="400" height="400"></canvas> -->


    <!-- Pie chart -->
    <canvas id="pieChart"></canvas>
  </div>
</div>


                </div>

                <div class="col-md-6">
                    <!-- Bar Graph -->
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title">Comparitive Analysis</h3>
                        </div>
                        <div class="card-body">

        <div class="mb-3">
   <label for="clinicRadio" style="color:transparent">Test</label>
                       <!-- <button id="toggleChartBtn" class="btn btn-primary mb-3">Prescription Count</button> -->

                            <canvas id="barChart"></canvas>
                        </div>
                    </div>
                       </div>
                </div>
            </div>
        </div>
    </section>
</div>


<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>


<Style>
label:not(.form-check-label):not(.custom-file-label) {
    font-weight: 400;
}
</style>

<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
   document.addEventListener("DOMContentLoaded", function() {
  const ctx1 = document.getElementById('pieChart').getContext('2d');

  // Clinic prescription data
  const clinicLabels = ['New', 'Pending', 'Collected', 'Testing', 'Completed', 'Rejected'];
  const clinicData = [
    {{$clinicPresCount}}, 
    {{$clinicPresCount11}}, 
    {{$clinicPresCount12}}, 
    {{$clinicPresCount13}}, 
    {{$clinicPresCount14}}, 
    {{$clinicPresCount15}}
  ];
  const clinicColors = ['#007bff', '#28a745', '#ffc107', '#ff10ebff', '#6410ffff', '#ff7010ff'];

  // Pharmacy prescription data
  const pharmacyLabels = ['New', 'Processing', 'Confirmed', 'Assigned Delivery', 'Completed', 'Rejected'];
  const pharmacyData = [
    {{$pharmacyPresCount}}, 
    {{$pharmacyPresCount11}}, 
    {{$pharmacyPresCount12}}, 
    {{$pharmacyPresCount13}}, 
    {{$pharmacyPresCount14}}, 
    {{$pharmacyPresCount15}}
  ];
  const pharmacyColors = ['#6610f2', '#e83e8c', '#fd7e14', '#20c997', '#17a2b8', '#dc3545'];

  // Track which data is showing
  let showingClinic = true;

  // Initialize pie chart with clinic data
  const pieChart = new Chart(ctx1, {
    type: 'pie',
    data: {
      labels: clinicLabels,
      datasets: [{
        data: clinicData,
        backgroundColor: clinicColors
      }]
    }
  });



  
const ctx2 = document.getElementById('barChart').getContext('2d');

// Data sets
const totalData = {
  labels: ['Online Payment', 'Cash on Delivery'],
  data: [{{ $pharmacyPresCount2 }}, {{ $pharmacyPresCount3 }}],
  backgroundColor: ['#007bff', '#28a745', '#ffc107']
};



let showingTotal = true; // Track current dataset

const barChart = new Chart(ctx2, {
  type: 'bar',
  data: {
    labels: totalData.labels,
    datasets: [{
      label: 'Total Count',
      data: totalData.data,
      backgroundColor: totalData.backgroundColor,
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        ticks: { color: "#000" }
      },
      y: {
        beginAtZero: true,
        ticks: { stepSize: 1 }
      }
    },
      plugins: {
    legend: {
      display: false   // hides the legend entirely
    }
  }
  }
});


// Toggle function
function toggleChartData() {
  if(showingTotal) {
    barChart.data.labels = paymentMethodData.labels;
    barChart.data.datasets[0].data = paymentMethodData.data;
    barChart.data.datasets[0].backgroundColor = paymentMethodData.backgroundColor;
    barChart.data.datasets[0].label = 'Pharmacy Prescriptions by Payment Method';
    showingTotal = false;
  } else {
    barChart.data.labels = totalData.labels;
    barChart.data.datasets[0].data = totalData.data;
    barChart.data.datasets[0].backgroundColor = 'transparent';
    barChart.data.datasets[0].label = '';
    showingTotal = true;
  }
  barChart.update();

   
  }

function toggleChartData2() {
  if (showingClinic) {
      // Switch to pharmacy data
      pieChart.data.labels = pharmacyLabels;
      pieChart.data.datasets[0].data = pharmacyData;
      pieChart.data.datasets[0].backgroundColor = pharmacyColors;
      document.getElementById('toggleChartBtn2').textContent = "Show Clinic Prescriptions";
      showingClinic = false;
    } else {
      // Switch back to clinic data
      pieChart.data.labels = clinicLabels;
      pieChart.data.datasets[0].data = clinicData;
      pieChart.data.datasets[0].backgroundColor = clinicColors;
      document.getElementById('toggleChartBtn2').textContent = "Show Pharmacy Prescriptions";
      showingClinic = true;
    }
    pieChart.update();

}


function updateChartData(selected) {
    if (selected === 'pharmacy') {
      pieChart.data.labels = pharmacyLabels;
      pieChart.data.datasets[0].data = pharmacyData;
      pieChart.data.datasets[0].backgroundColor = pharmacyColors;
    } else {
      pieChart.data.labels = clinicLabels;
      pieChart.data.datasets[0].data = clinicData;
      pieChart.data.datasets[0].backgroundColor = clinicColors;
    }

    pieChart.update();
  }

  // Event listener for radio buttons
  document.querySelectorAll('input[name="chartType"]').forEach(radio => {
    radio.addEventListener('change', function () {
      updateChartData(this.value);
    });
  });

document.getElementById('toggleChartBtn2').addEventListener('click', toggleChartData2);

document.getElementById('toggleChartBtn').addEventListener('click', toggleChartData);


});
</script>

@endsection
