@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Edit Laboratory</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item"><a href="{{ route('clinic') }}">Laboratory</a></li>
            <li class="breadcrumb-item active">Edit Laboratory</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Laboratory Details</h3>
            </div>
            @if ($errors->any())
            <div class="alert alert-danger">
              <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
            @endif
            <div class="card-body">
              <form action="{{ route('clinics.update', $clinic->id) }}" method="POST" enctype="multipart/form-data" >
                @csrf
                @method('PUT')
                
                <div class="form-group">
                  <label for="clinic_name">Name</label>
                  <input type="text" class="form-control" id="clinic_name" name="clinic_name" value="{{ $clinic->clinic_name }}" required>
                </div>

               
                <div class="form-group">
                  <label for="clinic_address">Address</label>
                  <textarea class="form-control" id="clinic_address" name="clinic_address" rows="3" required>{{ $clinic->clinic_address }}</textarea>
                </div>

                <div class="form-group">
                  <label for="city">City</label>
                  <input type="text" class="form-control" id="city" name="city" value="{{ $clinic->city }}" required>
                </div>

                <div class="form-group">
                <label for="phone_number">Phone Number</label>
                <input type="text" class="form-control" id="phone_number" name="phone_number" value="{{ $clinic->phone_number }}"  required 
                maxlength="10"
                inputmode="numeric"
                oninput="validatePhoneInput(this)">

                <div id="phoneError" class="text-danger mt-1" style="display:none;">
                Please enter digits only (0-9).
                </div>
                </div>

                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" id="email" name="email" value="{{ $clinic->email }}" required>
                </div>

                  <div class="form-group" id="password">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" id="password" name="password">
                  <small class="form-text text-muted">Leave blank to keep current password.</small>
                </div>

                <!-- Display Current Clinic Photo -->
                @if ($clinic->clinic_photo)
                  <div class="form-group">
                    <label for="current_clinic_photo">Current Laboratory Photo</label><br>
                    <img src="{{ asset('storage/' . $clinic->clinic_photo) }}" alt="Current Laboratory Photo" width="100" height="100">
                  </div>
                @endif

                <!-- Option to Upload New Clinic Photo -->
                  <div class="form-group">
                  <label for="clinic_photo">New Laboratory Photo</label>
                  <input type="file" class="form-control" id="clinic_photo" name="clinic_photo" accept="image/*" onchange="previewImage(event)">
                </div>

                 <div class="mb-3 mt-2">
        <img id="preview" src="#" alt="Image Preview" style="display: none; max-height: 200px; border: 1px solid #ccc; padding: 5px;" />
        </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="{{ route('clinic') }}" class="btn btn-secondary">Cancel</a>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>


<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>


<script>
function previewImage(event) {
  const input = event.target;
  const preview = document.getElementById('preview');
  const file = input.files[0];
  
  if (file && file.type.startsWith('image/')) {
    const reader = new FileReader();
    reader.onload = function(e) {
      preview.src = e.target.result;
      preview.style.display = 'block';
    }
    reader.readAsDataURL(file);
  } else {
    preview.src = '#';
    preview.style.display = 'none';
    alert('Please upload a valid image file.');
    input.value = ''; // reset file input
  }
}

// Extra validation on change event
document.getElementById('clinic_photo').addEventListener('change', function(event) {
  const file = this.files[0];
  if (file && !file.type.startsWith('image/')) {
    alert('Please upload a valid image file (jpg, png, gif, etc.)');
    this.value = '';
    const preview = document.getElementById('preview');
    if (preview) {
      preview.style.display = 'none';
      preview.src = '';
    }
  }
});
</script>
<script>
  document.getElementById('clinic_photo').addEventListener('change', function(event) {
  const file = this.files[0];
  if (file && !file.type.startsWith('image/')) {
    alert('Please upload a valid image file (jpg, png, gif, etc.)');
    this.value = '';
    const preview = document.getElementById('preview');
    if (preview) {
      preview.style.display = 'none';
      preview.src = '';
    }
  }
});

</script>



<script>
  function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }
  </script>

@endsection
