@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Edit Test</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item"><a href="{{ route('tests2') }}">Test</a></li>
            <li class="breadcrumb-item active">Edit Test</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Test Details</h3>
            </div>
            @if ($errors->any())
            <div class="alert alert-danger">
              <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
            @endif
            <div class="card-body">
              <form action="{{ route('tests.update_test2', $test->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT') <!-- For edit/update -->

    <!-- Clinic Dropdown -->

  <!-- Clinic Checkbox Selection -->


    <!-- Test Name -->
    <div class="form-group">
        <label for="test_name">Test Name</label>
        <input type="text" class="form-control" id="test_name" name="test_name"
               value="{{ old('test_name', $test->test_name) }}" required>
    </div>

    <!-- Amount -->
    <div class="form-group">
        <label for="amount">Amount</label>
        <input type="text" class="form-control" id="amount" name="amount"   value="{{ old('amount', $test->amount) }}"  required oninput="validateAmountInput(this)">
        <small id="amountError" style="color: red; display: none;">Only digits is possible</small>

    </div>

    <!-- Description -->
    <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control" id="description" name="description" rows="3"
                  placeholder="Enter Description">{{ old('description', $test->description) }}</textarea>
    </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="{{ route('tests2') }}" class="btn btn-secondary">Cancel</a>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>


<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>







<script>
  function validateAmountInput(input) 
  {
    // Only allow digits and at most one decimal point
    const cleanedValue = input.value.replace(/[^0-9.]/g, '');

    // Count how many decimal points are in the cleaned value
    const decimalCount = (cleanedValue.match(/\./g) || []).length;

    if (cleanedValue !== input.value || decimalCount > 1) 
    {
      // Show error message
      document.getElementById('amountError').style.display = 'block';

      // Remove extra decimal points if any
      let parts = cleanedValue.split('.');

      if (parts.length > 2) 
      {
        // Reconstruct with only the first decimal point
        input.value = parts[0] + '.' + parts.slice(1).join('').replace(/\./g, '');
      } 
      else 
      {
        input.value = cleanedValue;
      }
    } 
    else 
    {
      // Hide error message
      document.getElementById('amountError').style.display = 'none';
    }
  }
</script>


<script>
document.addEventListener("DOMContentLoaded", function () {
    const checkboxes = document.querySelectorAll(".clinic-checkbox");

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener("change", function () {
            if (this.checked) {
                checkboxes.forEach(cb => {
                    if (cb !== this) cb.checked = false;
                });
            }
        });
    });
});
</script>

@endsection
