@extends('backend.layouts.app')


@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Pharmacy Prescriptions</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
                        <li class="breadcrumb-item active">Pharmacy Prescriptions</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

<div class="mb-3 text-end " style="margin-right: 22px;">
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#otherOrderModal">
        Other Orders
    </button>
</div>


    <!-- Main content -->


    <section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">

          <div class="card-header d-flex justify-content-between flex-wrap">
            <div class="mb-2">
              @php
                $statusFilter = session('status_filter', request('status_filter', '0'));
              @endphp

              <label><input type="radio" onclick="statusChecker()" name="status_filter" value="0" {{ $statusFilter == '0' ? 'checked' : '' }}> New</label>
              <label><input type="radio" onclick="statusChecker()" name="status_filter" value="1" {{ $statusFilter == '1' ? 'checked' : '' }}> Processing</label>
              <label><input type="radio" onclick="statusChecker()" name="status_filter" value="2" {{ $statusFilter == '2' ? 'checked' : '' }}> Confirmed</label>
              <label><input type="radio" onclick="statusChecker()" name="status_filter" value="3" {{ $statusFilter == '3' ? 'checked' : '' }}> Assigned Delivery</label>
              <label><input type="radio" onclick="statusChecker()" name="status_filter" value="4" {{ $statusFilter == '4' ? 'checked' : '' }}> Completed</label>
              <label><input type="radio" onclick="statusChecker()" name="status_filter" value="5" {{ $statusFilter == '5' ? 'checked' : '' }}> Rejected</label>
            </div>

            <div>
              <p class="text-danger" id="error_in_date"></p>
              <label for="start_date">Start Date:</label>
              <input type="date" id="start_date">
              <label for="end_date">End Date:</label>
              <input type="date" id="end_date" onchange="dateWiseSearch()">
            </div>
          </div>

        


   
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                
                                        <th>User</th>
                                        <th>Patient</th>
                                        <th>Pharmacy</th>
                                         <th>Phone</th>
                                        <th>Prescription Image</th>
                                        <th>Delivery Address</th>
                                        <th>Latitude & Longitude</th>

                                        <th class="payment-method-th">Payment Method</th>



                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                 
                                 <tbody id="pharPresTable">
        <!-- rows will be injected here dynamically -->
    </tbody>
</table>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true" backdrop="static" data-bs-backdrop="static" data-bs-keyboard="true">
        <div class="modal-dialog " style="max-width: 80%;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Pharmacy Prescription</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Content will be loaded dynamically with AJAX -->
                </div>
            </div>
        </div>
    </div> 
</div>




<!-- Modal -->
<div class="modal fade" id="otherOrderModal" tabindex="-1" aria-labelledby="otherOrderModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="{{ route('pharmacy-prescriptions2.store') }}" method="POST" enctype="multipart/form-data">

        @csrf
        <div class="modal-header">
          <h5 class="modal-title" id="otherOrderModalLabel">Other Order Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <!-- Left Column -->
            <div class="col-md-6">
              <div class="mb-3">
                <label for="name" class="form-label">Patient Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>

            <div class="mb-3">
        <label for="payment_method" class="form-label">Payment Method</label>
        <select class="form-select" id="payment_method" name="payment_method" required>
               <option value="" selected disabled>Select Payment Method</option>
        <option value="1">Online</option>
        <option value="2">Cash On Delivery</option>
         </select>
        </div>


            </div>
            
            <!-- Right Column -->
        <div class="col-md-6">
            <div class="mb-3">
        <label for="amount" class="form-label">Amount</label>
        <input type="text" class="form-control" id="amount" name="amount" required>

        </div>


         <div class="mb-3">
                <label for="prescription" class="form-label">Prescription Image</label>
                    <input type="file" class="form-control" id="prescription" name="prescription" required>
              </div>

        </div>


  <div class="col-md-6">


             <div class="mb-3">
              <label for="assigned_user">Assign Delivery Agent</label>
            <select class="form-control" id="assigned_user" name="assigned_user" required>
            <option selected disabled>Assign Delivery Agent</option>
            @foreach($deliveryAgents as $agent)
            <option value="{{ $agent->id }}">{{ $agent->name }}</option>
            @endforeach
            </select>
              </div>


           
</div>




  <div class="col-md-6">


        <div class="mb-3">
        <label for="delivery_date" class="form-label">Delivery Date</label>
        <input type="date" class="form-control" id="delivery_date" name="delivery_date" required>
        </div>


             <div class="mb-3">
    <label for="delivery_address" class="form-label">DeliveryAddress </label>
    <textarea class="form-control" id="delivery_address" name="delivery_address" rows="3" required></textarea>
</div>
</div>




          </div>
          <!-- Add more rows if needed -->
        </div>
        <div class="modal-footer">
             <button type="submit" class="btn btn-primary">Save Order</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         
        </div>
      </form>
    </div>
  </div>
</div>







<!-- Prescription Modal -->
<div class="modal fade" id="prescriptionModal" tabindex="-1" role="dialog" aria-labelledby="prescriptionModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Prescription Images</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body d-flex flex-wrap" id="prescriptionImages">
        <!-- Images will be injected here -->
      </div>
    </div>
  </div>
</div>




<!-- Include necessary scripts -->



<style>
div#example1_info
 {
    display: none;
}


div#example1_paginate 
{
    display: none;
}



.img-thumbnail
{
max-width: 100% !important;
max-height: unset !important;
}


</style>




<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
<link rel="stylesheet" href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">

<script>
   $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
       "order": [[0, "desc"]],
      "columnDefs": [
        { "orderable": false, "targets": -1 }
      ],

      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });


    // $('.btn-close').on('click', function() 
    // {
    //     location.reload();
    //     //$('#editModal').modal('hide');    
    // });
   
    // $('#editModal').on('hide.bs.modal', function () 
    // {
    // // Add any custom CSS or class on modal hide
    // $(this).addClass('custom-hidden-style');
    // });




$(document).ready(function () {
    statusChecker(1); // load default status=0
});


    $('#close').on('click', function() {
        console.log('Closing modal');
        $('#editModal').modal('hide');
    });

    $(document).on('click', '.open-edit-modal', function() {
        let prescriptionId = $(this).data('id');
        let url = `/pharmacy-prescriptions2/${prescriptionId}/edit`;

        $.ajax({
            url: url,
            method: 'GET',
            success: function(response) {
                $('#editModal .modal-body').html(response);
                $('#editModal').modal('show');
                 
            },
            error: function(xhr) {
                alert('Failed to load prescription details. Please try again.');
            }
        });
    });

//    function statusChecker(page = 1) {
//     const status = $('input[name="status_filter"]:checked').val();

//     if (status !== undefined) {
//         $.ajax({
//             url: '{{ route("pharmacy-prescription.status") }}',
//             method: 'GET',
//             data: {
//                 status: status,
//                 page: page
//             },
//             success: function(response) {
//                 $('#pharPresTable').html(response.output);
//                 $('#paginate').html(response.pagination); // this should be returned by controller
//             },
//             error: function() {
//                 alert('Failed to load data. Try again.');
//             }
//         });
//     }
// }



function statusChecker(page = 1) {
    const status = $('input[name="status_filter"]:checked').val();

    if (status !== undefined) {
        $.ajax({
            url: '{{ route("pharmacy-prescription2.status") }}',
            method: 'GET',
            data: {
                status: status,
                page: page
            },
            success: function(response) {
                // Destroy existing DataTable before replacing tbody content
                if ($.fn.DataTable.isDataTable('#example1')) {
                    $('#example1').DataTable().destroy();
                }

                $('#pharPresTable').html(response.output);

                // Reinitialize DataTable after updating rows
                    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
       "order": [[0, "desc"]],
      "columnDefs": [
        { "orderable": false, "targets": -1 }
      ],

      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

                $('#paginate').html(response.pagination);

                // Show/hide Payment Method column header and cells
                if (status === '1' || status === '2' || status === '3' || status === '4') {
                    $('.payment-method-th, .payment-method-td').show();
                } else {
                    $('.payment-method-th, .payment-method-td').hide();
                }
            },
            error: function() {
                alert('Failed to load data. Try again.');
            }
        });
    }
}



    // function statusChecker(page = 1) 
    // {
    // const status = $('input[name="status_filter"]:checked').val();

    // if (status !== undefined) {
    //     localStorage.setItem('selected_status', status);

    //     $.ajax({
    //         url: '{{ route("pharmacy-prescription.status") }}',
    //         method: 'GET',
    //         data: {
    //             status: status,
    //             page: page
    //         },
    //         success: function(response) {
    //             $('#pharPresTable').html(response.output);
    //             $('#paginate').html(response.pagination);

    //             if (status === '2') 
    //             {
    //                 $('.payment-method-th, .payment-method-td').show();
    //             }
    //             else {
    //                 $('.payment-method-th, .payment-method-td').hide();
    //             }
    //         },
    //         error: function() {
    //             alert('Failed to load data. Try again.');
    //         }
    //     });
    // }
    // }


    // $(document).ready(function () 
    // {
    // const savedStatus = localStorage.getItem('selected_status');
    // if (savedStatus) 
    // {
    //     $(`input[name="status_filter"][value="${savedStatus}"]`).prop('checked', true);
    //     statusChecker(); 
    // }
    // else 
    // {
    //     $('input[name="status_filter"][value="0"]').prop('checked', true);
    //     statusChecker();
    // }
    // });


$(document).on('click', '#paginate a', function (e) {
    e.preventDefault();
    const url = $(this).attr('href');
    const pageMatch = url.match(/page=(\d+)/);
    const page = pageMatch ? pageMatch[1] : 1;
    statusChecker(page);
});



    $(document).ready(function () {
        $('.show-prescriptions').on('click', function () {
            var images = $(this).data('images');
            var container = $('#prescriptionImages');
            container.empty();

            if (images && images.length > 0) {
                images.forEach(function (imgPath) {
                    var imgElement = `<img src="${imgPath}" class="img-thumbnail m-2" style="max-width: 200px; max-height: 200px;">`;
                    container.append(imgElement);
                });
                $('#prescriptionModal').modal('show');
            }
        });
    });







//  function statusChecker() {
//         var status = $('input[name="status_filter"]:checked').val();
//         if (status) {
//             $.ajax({
//                 url: '{{route("clinic-prescription.status")}}',
//                 method: 'GET',
//                 data: {
//                     status: status
//                 },
//                 success: function(response) {
//                     $('#pharPresTable').html(response.output);
//                     $('#paginate').html(response.pagination);
//                 },
//                 error: function(xhr) {
//                     alert('Failed to load prescription details. Please try again.');
//                 }
//             });
//         }
//     }


    $(document).ready(function () {
        // Set default start_date = yesterday, end_date = today
        let today = new Date();
        let yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);

        let formatDate = (date) => {
            return date.toISOString().split('T')[0]; // YYYY-MM-DD
        };

        $('#start_date').val(formatDate(yesterday));
        $('#end_date').val(formatDate(today));

        // Trigger default search
        dateWiseSearch();
    });


   function dateWiseSearch() {
    var startDate = $('#start_date').val();
    var endDate = $('#end_date').val();
    var status = $('input[name="status_filter"]:checked').val();  // get current status filter

    $('#error_in_date').text(''); // clear previous error message

    if (startDate && endDate) {
        $.ajax({
            url: '{{ route("pharmacy-prescription2.dateMatch") }}',
            method: 'GET',
            data: {
                status: status,
                start_date: startDate,
                end_date: endDate
            },
            success: function(response) {
                console.log(response);

                // Destroy existing DataTable before updating rows
                if ($.fn.DataTable.isDataTable('#example1')) {
                    $('#example1').DataTable().destroy();
                }

                // Update the table body with new rows
                $('#pharPresTable').html(response.output);

                // Reinitialize DataTable with responsive + control column
                    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
       "order": [[0, "desc"]],
      "columnDefs": [
        { "orderable": false, "targets": -1 }
      ],

      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
                // Update pagination if your backend returns it
                if (response.pagination) {
                    $('#paginate').html(response.pagination);
                }

                // Show/hide Payment Method column based on status
                if (status === '1' || status === '2' || status === '3' || status === '4') {
                    $('.payment-method-th, .payment-method-td').show();
                } else {
                    $('.payment-method-th, .payment-method-td').hide();
                }
            },
            error: function(xhr) {
                alert('Failed to load prescription details. Please try again.');
            }
        });
    } else {
        $('#error_in_date').text('Please enter start date and end date');
    }
}


 $(document).on('click', '.show-prescriptions', function () {
        const images = $(this).data('images');
        const container = $('#prescriptionImages');
        container.empty();

        if (images && images.length > 0) {
            images.forEach(function (imgUrl) {
                const imgElement = `
                    <div class="m-2 text-center">
                        <img src="${imgUrl}" class="img-thumbnail" style="max-width: 200px; max-height: 150px;">
                    </div>
                `;
                container.append(imgElement);
            });
            $('#prescriptionModal').modal('show');
        }
    });

    
 window.addEventListener("load", function() {
    statusChecker(1);
 });
   
</script>
@endsection
