@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Tests</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home2') }}">Home</a></li>
            <li class="breadcrumb-item active">Tests</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <!-- /.card -->

               
          <div class="card">
        
            <div class="card-header d-flex justify-content-end">
              <a class="btn btn-success" href="{{route('add-new-tests2')}}">
                <i class="fas fa-plus"></i> Add Tests
              </a>
            </div>

    


            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Laboratory Name</th>
                    <th>Tests</th>
                       <th>Amount</th>
              <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($tests as $test)
                  <tr>
                   <td>{{ $test->clinic->clinic_name ?? 'N/A' }}</td>

        
                    <td>{{ $test->test_name }}</td>
                    <td>{{ $test->amount }}</td>

                     <td>
                      <a href="{{ route('tests.edit_test2', $test->id) }}" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                      </a>


                      <form action="{{ route('tests.destroy_test2', $test->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this tests?');">
                          <i class="fas fa-trash"></i> Delete
                        </button>
                      </form>

                 

                    </td>
                  
                   
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->




<!-- Batch Merge Modal -->
<div class="modal fade" id="batchMergeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
   <!-- Merge Clinic Tests Modal -->
<form method="POST" action="{{ route('tests.merge_clinic_tests') }}">
  @csrf
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title">Merge Tests from One Clinic to Others</h5>
      <button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>

    <div class="modal-body">
      <!-- Source Clinic -->
      <div class="form-group">
        <label for="source_clinic">Select Source Clinic (From):</label>
        <select class="form-control" name="source_clinic_id" id="source_clinic" required>
          <option value="" disabled selected>Select Clinic</option>
          @foreach ($clinics as $clinic)
            <option value="{{ $clinic->id }}">{{ $clinic->clinic_name }}</option>
          @endforeach
        </select>
      </div>

      <!-- Target Clinics -->
      <div class="form-group">
        <label>Select Target Clinics (To):</label>
        @foreach ($clinics as $clinic)
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="target_clinic_ids[]" value="{{ $clinic->id }}" id="target_clinic_{{ $clinic->id }}">
            <label class="form-check-label" for="target_clinic_{{ $clinic->id }}">{{ $clinic->clinic_name }}</label>
          </div>
        @endforeach
      </div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary">Merge Tests</button>
      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    </div>
  </div>
</form>

  </div>
</div>





<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>



<style>
.dataTables_wrapper .dataTables_paginate .paginate_button:hover
{
background-color: unset !important;
box-shadow: unset !important;
box-shadow: unset !important;
border: unset !important;
background: unset !important;
}
</style>


<!-- jQuery -->
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Page specific script -->
  <script>
  $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "order": [[0, "desc"]],
      "columnDefs": [
        { "orderable": false, "targets": -1 }
      ],
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });
</script>


<script>
  // $('#mergeModal').on('show.bs.modal', function (event) {
  //   const button = $(event.relatedTarget);
  //   const testId = button.data('test-id');
  //   $('#mergeTestId').val(testId);
  // });

  document.addEventListener('DOMContentLoaded', function () {
    const mergeModal = document.getElementById('mergeModal');

    $('#mergeModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget);
        const testId = button.data('test-id');
        $('#mergeTestId').val(testId);
    });
});

</script>


@endsection
