
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Laboratory Prescription</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('clinic-prescriptions2.index') }}">Laboratory Prescriptions</a></li>
                    <li class="breadcrumb-item active">Edit Prescription</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 offset-md-1">
                <div class="card">
                    @if(session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                    @endif
                    <div class="card-header">
                        <h3 class="card-title">Update Prescription</h3>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('clinic-prescriptions2.update', $clinicPrescription->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="form-group">
                            <label for="user_id">User</label>
                            <input type="text" class="form-control" id="prescription" name="prescription" value="{{$clinicPrescription->user->name }}" readonly>
                            </div>

                            <div class="form-group">
                            <label for="user_id">Patient</label>
                            <input type="text" class="form-control" id="prescription" name="prescription" value="{{$clinicPrescription->name }}" readonly>
                            </div>


                            <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="{{ $clinicPrescription->user->phone_number }}" readonly>
                            </div>


                            <div class="form-group">
                            <label for="user_id">Age</label>
                            <input type="text" class="form-control" id="prescription" name="prescription" value="{{$clinicPrescription->age }}" readonly>
                            </div>

                            <div class="form-group">
                            <label for="user_id">Gender</label>
                            <input type="text" class="form-control" id="prescription" name="prescription" value="{{$clinicPrescription->gender }}" readonly>
                            </div>

                            @if($clinicPrescription->test)
                            @foreach(json_decode($clinicPrescription->test, true) as $test)
                            <div class="form-group">
                                <label for="user_id">Test</label>
                                <input type="text" class="form-control" id="prescription" name="prescription" value="{{$test}}" readonly>
                            </div>
                            @endforeach
                            @endif

                               <div class="form-group">
                            <label for="user_id">Total Amount of Selected Tests</label>
                            <input type="text" class="form-control" id="prescription" name="prescription" value="{{$clinicPrescription->test_total }}" readonly>
                            </div>

                            <div class="form-group">
                                <label for="pharmacy_id">Laboratory</label>
                                <input type="text" class="form-control" id="prescription" name="prescription" value="{{ $clinicPrescription->clinic->clinic_name }}" readonly>
                            </div>

                            <div class="form-group">
                                <label for="prescription">Prescription (Image)</label>

                                @if($clinicPrescription->prescription)
                                <div class="mt-2">
                                    @foreach(json_decode($clinicPrescription->prescription, true) as $image)
                                    <div class="d-inline-block text-center mr-2">
                                        <!-- <i class="fas fa-images" style="color: green; font-size: 20px;"></i> -->
                                        <img src="{{ asset('storage/'.$image) }}" alt="Prescription Image" width="100" height="70" class="mb-1">
                                        <br>
                                        <!-- <button type="button" class="btn btn-info btn-sm" onclick="showImage('{{ asset('storage/'.$image) }}')">View</button> -->

                                <button type="button" class="btn btn-info btn-sm"  onclick="showImage(`{{ asset('storage/' . $image) }}`)">View</button>
  
                                    </div>
                                    @endforeach
                                </div>
                                @endif
                            </div>

                            <div class="form-group">
                                <label for="delivery_address">Delivery Address</label>
                                <textarea class="form-control" id="address" name="address" rows="2" required>{{ old('address', $clinicPrescription->address) }}</textarea>
                            </div>
                            @php
                            $lat_long=$clinicPrescription->lat_long;
                            $cordinates=explode(',',$lat_long);

                            @endphp
                            <div class="form-group">
                                <label for="lat_long">Latitude & Longitude</label>
                                <input type="text" class="form-control" id="lat_long" name="lat_long" value="{{ old('lat_long', $clinicPrescription->lat_long) }}" readonly>

                                <a href="https://www.google.com/maps?q={{ $cordinates[0] }},{{ $cordinates[1] }}" target="_blank">
                                    View Location on Google Maps
                                </a>
                            </div>

                           



                             @if($clinicPrescription->status==0)
                                <a href="{{ url('/clinic-prescription/rejected/'.$clinicPrescription->id) }}" class="btn btn-danger">Rejected</a>
                                @endif


                   
                            @if($clinicPrescription->status==3)
                            <div class="form-group">
                               <label for="pres_upload">Prescription Upload</label>
                      <input type="file" 
        name="pres_upload" 
        id="pres_upload" 
        class="form-control" 
        required
        accept=".pdf, .doc, .docx, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/pdf">
                            </div>
                            @endif


                        @if($clinicPrescription->status == 4 && $clinicPrescription->pres_upload)
                        <div class="form-group">
                        <label for="prescription">Prescription Uploaded</label>
                        <div class="mt-2">
                        @php
                        $filePath = storage_path('app/public/' . $clinicPrescription->pres_upload);
                        $fileUrl = asset('storage/' . $clinicPrescription->pres_upload);
                        $extension = strtolower(pathinfo($clinicPrescription->pres_upload, PATHINFO_EXTENSION));
                        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                        @endphp

                        <div class="d-inline-block text-center mr-2">
                        @if(in_array($extension, $imageExtensions))
                        <img src="{{ $fileUrl }}" alt="Prescription Image" width="100" height="70" class="mb-1">
                        <br>
                        <button type="button" class="btn btn-info btn-sm" onclick="showImage(`{{ $fileUrl }}`)">View</button>
                        @else
                        <i class="fas fa-file-alt fa-2x text-primary mb-1"></i>
                        <br>
                        <a href="{{ $fileUrl }}" class="btn btn-success btn-sm" download>Download File</a>
                        @endif
                        </div>
                        </div>
                        </div>
                        @endif


                         @if ($clinicPrescription->status == 1 && ($clinicPrescription->otp === '0000' ||  is_null($clinicPrescription->otp) || $clinicPrescription->otp === ''))

                <div class="row mb-3">
                <div class="col-md-6">
                <button type="button" class="btn btn-success" id="showAuthFormBtn">
                Complete Manually
                </button>
                </div>
                </div>

                {{-- Authentication Form --}}
                <div class="row mt-3 d-none" id="authFormContainer" style="margin-left: 5px;">
                <div class="col-md-8">

                {{-- Show Authenticated Admin/User --}}
                <div class="mb-2">
                <strong>Authenticating as:</strong>
                <span class="text-primary">{{ Auth::user()->name }}</span>
                </div>

                {{-- Password Field --}}
                <div class="mb-3">
                <label for="auth_password" class="form-label">Enter Password to Authenticate</label>
                <input type="password" id="auth_password" class="form-control" required>
                <div id="auth_password_error" class="text-danger mt-1 d-none">Invalid Password</div>
                </div>

                {{-- Submit Button --}}
                <button type="button" class="btn btn-primary" id="submitAuthBtn">Save</button>
                </div>
                </div>

                @endif


                       


                        

                        <div class="row">
                        <div class="col-md-6">
                        @if ($clinicPrescription->scheduled_at)
                        <label for="exampleInput">Scheduled Date: {{ \Carbon\Carbon::parse($clinicPrescription->scheduled_at)->format('d-m-Y') }}</label>
                        @endif


                        @if ($clinicPrescription->delivery_id)
                        <label for="exampleInput">Delivery Agent: {{ $clinicPrescription->deliveryAgent->name ?? 'N/A' }}</label>
                        @endif

                        </div>

                        <div class="col-md-6">
                        @if ($clinicPrescription->scheduled_at && empty($clinicPrescription->from_time) && empty($clinicPrescription->to_time))
                        <label for="exampleInput">Time:Any time is available</label>
                        @else
                        @if (!empty($clinicPrescription->from_time))
                        <label for="exampleInput">From Time: {{ $clinicPrescription->from_time }}</label>
                        @endif

                        @if (!empty($clinicPrescription->to_time))
                        <label for="exampleInput">To Time: {{ $clinicPrescription->to_time }}</label>
                        @endif
                        @endif
                        </div>
                        </div>

                    
            
                            <div class="form-group">
                                <label for="status">Status</label>
                                <!-- <select class="form-control" id="status" name="status" required onchange="toggleAgentSelect()" required> -->

                                <select class="form-control" id="status" name="status"  required>
                                
                                    @if($clinicPrescription->status==5)
                                    <option value="5" {{ old('status', $clinicPrescription->status) == '4' ? 'selected' : '' }}>Rejected</option>
                                    @elseif($clinicPrescription->status==1)
                                    <option value="2" {{ old('status', $clinicPrescription->status) =='1' ? 'selected' : '' }}>Sample Collected</option>
                                      @elseif($clinicPrescription->status==2)
                                    <option value="3" {{ old('status', $clinicPrescription->status) =='2' ? '' : '' }}>Completed</option>

                                     @elseif($clinicPrescription->status==3)
                                    <option value="4" {{ old('status', $clinicPrescription->status) =='3' ? 'selected' : '' }}>Testing</option>

                                     @elseif($clinicPrescription->status==4)
                                    <option value="4" {{ old('status', $clinicPrescription->status) =='4' ? 'selected' : '' }}>Completed</option>

                                    @elseif($clinicPrescription->status==0)
                                    <option value="1" {{ old('status', $clinicPrescription->status) == '1' ? 'selected' : '' }}>Accepted</option>
                                    <!-- <option value="5" {{ old('status', $clinicPrescription->status) == '5' ? 'selected' : '' }}>Rejected</option> -->
                                   
                                    @endif
                                </select>
                            </div>

                                <!-- Delivery Agent select, initially hidden -->

                        @if($clinicPrescription->status == 0)
    <div class="form-group" id="agentSelectDiv">
        <label for="delivery_id">Assign Delivery Agent*</label>
        <select class="form-control @error('delivery_id') is-invalid @enderror" id="delivery_id" name="delivery_id" required>
            <option value="" disabled {{ old('delivery_id') ? '' : 'selected' }}>Assign Delivery Agent*</option>
            @foreach($deliveryAgents as $agent)
                <option value="{{ $agent->id }}" {{ old('delivery_id', $clinicPrescription->delivery_id) == $agent->id ? 'selected' : '' }}>
                    {{ $agent->name }}
                </option>
            @endforeach
        </select>

        @error('delivery_id')
            <span class="text-danger">{{ $message }}</span>
        @enderror
    </div>
@endif

     @if($clinicPrescription->status==0)

    <button type="submit" class="btn btn-primary">Collected</button>
    @endif

      @if($clinicPrescription->status==1)

    <button type="submit" class="btn btn-primary">Sample Collected</button>
    @endif

     @if($clinicPrescription->status==2)

    <button type="submit" class="btn btn-primary">Sample Completed</button>
    @endif

     @if($clinicPrescription->status==3)

    <button type="submit" class="btn btn-primary">Completed</button>
    @endif



    <a href="{{ route('clinic-prescriptions2.index') }}" class="btn btn-secondary">Cancel</a>
    </form>

    </div>
    </div>
    </div>
    <div class="col-md-5">
    <img id="large-prescription" src="" class="img-fluid d-none" alt="Prescription Image">
    </div>

    </div>
    </div>
    </section>





    
<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>


<script>
    document.getElementById('showAuthFormBtn').addEventListener('click', function () {
        document.getElementById('authFormContainer').classList.remove('d-none');
    });

    document.getElementById('submitAuthBtn').addEventListener('click', function () {
        const password = document.getElementById('auth_password').value;
        const id = {{ $clinicPrescription->id }};

        fetch("{{ route('clinic-prescription.complete-auth') }}", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                id2: id,
                auth_password: password
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Process completed successfully.');
                location.reload(); // or update UI
            } else {
                document.getElementById('auth_password_error').classList.remove('d-none');
                document.getElementById('auth_password_error').innerText = data.message || 'Authentication failed.';
            }
        })
        .catch(error => {
            document.getElementById('auth_password_error').classList.remove('d-none');
            document.getElementById('auth_password_error').innerText = 'Authentication failed';
        });
    });
</script>





<!-- <script>
    function toggleAgentSelect() {
        const status = document.getElementById('status').value;
        const agentDiv = document.getElementById('agentSelectDiv');

        if(status === '1') {  // Accepted
            agentDiv.style.display = 'block';
            document.getElementById('delivery_id').setAttribute('required', 'required');
        } else {
            agentDiv.style.display = 'none';
            document.getElementById('delivery_id').removeAttribute('required');
        }
    }

    window.onload = function() {
        toggleAgentSelect();
    };
</script> -->

<script>
document.getElementById('pres_upload').addEventListener('change', function() {
    const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (this.files.length > 0) {
        const fileType = this.files[0].type;
        if (!allowedTypes.includes(fileType)) {
            alert('Only PDF and Word document files are allowed!');
            this.value = '';  // Reset file input
        }
    }
});
</script>

<script>
    function showImage(imageUrl) {
        let imgElement = document.getElementById('large-prescription');
        imgElement.src = imageUrl;
        imgElement.classList.remove('d-none');
    }
</script>
