@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Laboratory Prescriptions</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
                        <li class="breadcrumb-item active">Laboratory Prescriptions</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">

                            <div>
                             

                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="0"
                                    {{ request('status_filter', '0') == '0' ? 'checked' : '' }}>
                                    New
                                    </label>

                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="1"
                                    {{ request('status_filter') == '1' ? 'checked' : '' }}>
                                    Pending
                                    </label>

                                       <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="2"
                                    {{ request('status_filter') == '2' ? 'checked' : '' }}>
                                    Collected
                                    </label>
                                    

                                     <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="3"
                                    {{ request('status_filter') == '3' ? 'checked' : '' }}>
                                    Testing
                                    </label>

                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="4"
                                    {{ request('status_filter') == '4' ? 'checked' : '' }}>
                                    Completed
                                    </label>


                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="5"
                                    {{ request('status_filter') == '5' ? 'checked' : '' }}>
                                    Rejected
                                    </label>


                            </div>

                            <div>
                                <p class="text-danger" id="error_in_date"></p>
                                <label for="start_date">Start Date:</label>
                                <input type="date" id="start_date">
                                <label for="end_date">End Date:</label>
                                <input type="date" id="end_date" onchange="dateWiseSearch()">
                            </div>

                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Patient</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Laboratory</th>
                                        <th>Phone</th>
                                        <th>Schedule Date</th>
                                        <th>Prescription Image</th>
                                        <th>Address</th>
                                        <th>Test</th>
                                        <th>Latitude & Longitude</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                       <tbody id="pharPresTable">
        <!-- rows will be injected here dynamically -->
    </tbody>
</table>
                      

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true" backdrop="static" data-bs-backdrop="static" data-bs-keyboard="true">
    <div class="modal-dialog " style="max-width: 70%;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Laboratory Prescription</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"></span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Content will be loaded dynamically with AJAX -->
            </div>
        </div>
    </div>
</div>


</div>


<div class="modal fade" id="prescriptionModal" tabindex="-1" role="dialog" aria-labelledby="prescriptionModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Prescription Images</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body d-flex flex-wrap" id="prescriptionImages">
        <!-- Images will be injected here -->
      </div>
    </div>
  </div>
</div>



<style>
div#example1_info
 {
    display: none;
}

div#example1_paginate {
    display: none;
}

.img-thumbnail
{
max-width: 100% !important;
max-height: unset !important;
}
</style>





<!-- Include necessary scripts -->
<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>

<link rel="stylesheet" href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">


<script>
   $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });


    $('#close').on('click', function() {
        console.log('Closing modal');
        $('#editModal').modal('hide');
    });



$(document).ready(function () {
    statusChecker(1); // load default status=0
});


    $(document).on('click', '.open-edit-modal', function() {
        let clinicPrescription = $(this).data('id');
        let url = `/clinic-prescriptions2/${clinicPrescription}/edit`;

        $.ajax({
            url: url,
            method: 'GET',
            success: function(response) {
                $('#editModal .modal-body').html(response);
                $('#editModal').modal('show');

            },
            error: function(xhr) {
                alert('Failed to load prescription details. Please try again.');
            }
        });
    });







    
    // function statusChecker() {
    //     var status = $('input[name="status_filter"]:checked').val();
    //     if (status) {
    //         $.ajax({
    //             url: '{{route("clinic-prescription.status")}}',
    //             method: 'GET',
    //             data: {
    //                 status: status
    //             },
    //             success: function(response) {
    //                 $('#pharPresTable').html(response.output);
    //                 $('#paginate').html(response.pagination);
    //             },
    //             error: function(xhr) {
    //                 alert('Failed to load prescription details. Please try again.');
    //             }
    //         });
    //     }
    // }


    $(document).on('click', '#paginate a', function (e) {
    e.preventDefault();
    const url = $(this).attr('href');
    const pageMatch = url.match(/page=(\d+)/);
    const page = pageMatch ? pageMatch[1] : 1;
    statusChecker(page);
});


    
function statusChecker(page = 1) {
    const status = $('input[name="status_filter"]:checked').val();

    if (status !== undefined) {
        $.ajax({
            url: '{{ route("clinic-prescription2.status") }}',
            method: 'GET',
            data: {
                status: status,
                page: page
            },
            success: function(response) {
                // Destroy the existing DataTable if it exists
                if ($.fn.DataTable.isDataTable('#example1')) {
                    $('#example1').DataTable().destroy();
                }

                // Update the table with the new content
                $('#pharPresTable').html(response.output);
                $('#paginate').html(response.pagination); // pagination will be returned from controller

                // Reinitialize the DataTable
                $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            },
            error: function() {
                alert('Failed to load data. Try again.');
            }
        });
    }
}


   function dateWiseSearch() {
    var startDate = $('#start_date').val();
    var endDate = $('#end_date').val();

    if (startDate && endDate) {
        $.ajax({
            url: '{{ route("clinic-prescription2.dateMatch") }}',
            method: 'GET',
            data: {
                status: status, // Make sure 'status' is defined somewhere before you send it.
                start_date: startDate,
                end_date: endDate
            },
            success: function(response) {
                console.log(response);

                // Destroy the existing DataTable if it exists
                if ($.fn.DataTable.isDataTable('#example1')) {
                    $('#example1').DataTable().destroy();
                }

                // Update the table with the new content
                $('#pharPresTable').html(response.output);
                $('#paginate').html(response.pagination);

                // Reinitialize the DataTable
                 $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            },
            error: function(xhr) {
                alert('Failed to load prescription details. Please try again.');
            }
        });
    } else {
        $('#error_in_date').text('Please enter start date and end date');
    }
}


 $(document).ready(function () {
        // Set default start_date = yesterday, end_date = today
        let today = new Date();
        let yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);

        let formatDate = (date) => {
            return date.toISOString().split('T')[0]; // YYYY-MM-DD
        };

        $('#start_date').val(formatDate(yesterday));
        $('#end_date').val(formatDate(today));

        // Trigger default search
        dateWiseSearch();
    });



 $(document).on('click', '.show-prescriptions', function () {
        const images = $(this).data('images');
        const container = $('#prescriptionImages');
        container.empty();

        if (images && images.length > 0) {
            images.forEach(function (imgUrl) {
                const imgElement = `
                    <div class="m-2 text-center">
                        <img src="${imgUrl}" class="img-thumbnail" style="max-width: 200px; max-height: 150px;">
                    </div>
                `;
                container.append(imgElement);
            });
            $('#prescriptionModal').modal('show');
        }
    });


 window.addEventListener("load", function() {
    statusChecker(1);
});
</script>
@endsection
