@extends('backend.layouts.app')

@section('content')

<!-- /.content-header -->

<!-- Main content -->
<div class="content-wrapper">
    <section class='content'>
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$userCount}}</h3>
                            <p>Total Users</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="{{route('users2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
               
                <!-- ./col -->
             
                <!-- ./col -->
         

                @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$clinicPresCount}}</h3>
                            <p>New Laboratory Prescription</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('clinic-prescriptions2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                @endif

        @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id2))

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{$pharmacyPresCount}}</h3>
                            <p>New Pharmacy Prescription</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('pharmacy-prescriptions2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                       @endif
                       
                <!-- ./col -->
            </div>

            <!-- Charts Row -->
            <div class="row mt-5">
                <div class="col-md-6">
                    <!-- Pie Chart -->
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h3 class="card-title">Category Distribution</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <!-- Bar Graph -->
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title">Comparison Chart</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="barChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>





<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
    // Pie Chart Data
    var ctx1 = document.getElementById('pieChart').getContext('2d');
    new Chart(ctx1, {
        type: 'pie',
        data: {
            labels: ['Users', 'Laboratory', 'Pharmacies'],
            datasets: [{
                data: [{{$userCount}}],
                backgroundColor: ['#007bff']
            }]
        }
    });

    // Bar Chart Data (Fixed)
    var ctx2 = document.getElementById('barChart').getContext('2d');
    new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: ['Users'], 
            datasets: [{
                label: 'Total Count', 
                data: [{{$userCount}}],
                backgroundColor: ['#007bff'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    ticks: {
                        color: "#000" 
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1 
                    }
                }
            }
        }
    });
});
</script>

@endsection
