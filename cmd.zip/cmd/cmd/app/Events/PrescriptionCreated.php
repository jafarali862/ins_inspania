<?php

namespace App\Events;

use App\Models\PharmacyPrescription;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class PrescriptionCreated implements ShouldBroadcast
{
    use Dispatchable, SerializesModels;

    public $prescription;

    public function __construct(PharmacyPrescription $prescription)
    {
        $this->prescription = $prescription;
    }

    public function broadcastOn()
    {
        // Send to pharmacy-specific channel
        return new PrivateChannel('pharmacy.' . $this->prescription->pharmacy_id);
    }

    public function broadcastAs()
{
    return 'PrescriptionCreated';
}

}
