<?php
namespace App\Exports;

use App\Models\PharmacyPrescription;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Carbon\Carbon;



class DaybookExport2 implements FromCollection, WithHeadings, WithStyles
{
    protected $filters;

    public function __construct($filters)
    {
        $this->filters = $filters;
    }

    public function collection()
    {
     $loginId = auth()->user()->login_id2;
    $query = PharmacyPrescription::with(['user', 'pharmacy', 'deliveryAgent'])
                ->where('status', '!=', 5)->where('pharmacy_id', $loginId);

        if (!empty($this->filters['payment_method'])) {
            $query->where('payment_method', $this->filters['payment_method']);
        }

         if (!empty($this->filters['pharmacy_id'])) {
        $query->where('pharmacy_id', $this->filters['pharmacy_id']);
    }



        if (!empty($this->filters['from_date']) && !empty($this->filters['to_date'])) {
            $query->whereBetween('created_at', [
                $this->filters['from_date'] . ' 00:00:00',
                $this->filters['to_date'] . ' 23:59:59',
            ]);
        }

        $data = $query->get();

        // Calculate total
        $totalAmount = $data->sum('total_amount');

        // Map data
        $mapped = $data->map(function ($item) {
            return [
                // 'ID' => $item->id,
                'Patient Name'     => $item->name ?? 'N/A',
                'Pharmacy'         => $item->pharmacy->pharmacy_name ?? 'N/A',
                'Payment Method'   => $item->payment_method == 1 ? 'Online Payment' : ($item->payment_method == 2 ? 'Cash on Delivery' : 'N/A'),
                'Amount Collected' => $item->total_amount,
                'Delivery Agent'   => $item->deliveryAgent->name ?? 'N/A',
                'Address'          => $item->delivery_address,
                'Date'             => Carbon::parse($item->created_at)->format('d-m-Y H:i'),
            ];
        });

        // Add grand total row
        $mapped->push([
            'Patient Name'     => '',
            'Pharmacy'         => '',
            'Payment Method'   => '',
            'Amount Collected' => 'Grand Total: ' . number_format($totalAmount, 2),
            'Delivery Agent'   => '',
            'Address'          => '',
            'Date'             => '',
        ]);

        return $mapped;
    }

    public function headings(): array
    {
        return [
            // 'ID',
            'Patient Name',
            'Pharmacy',
            'Payment Method',
            'Amount Collected',
            'Delivery Agent',
            'Address',
            'Date',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Make first row (headings) bold
            1 => ['font' => ['bold' => true]],
        ];
    }
}

