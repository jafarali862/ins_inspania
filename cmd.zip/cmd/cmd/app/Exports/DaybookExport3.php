<?php
namespace App\Exports;

use App\Models\ClinicPrescription;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Carbon\Carbon;



class DaybookExport3 implements FromCollection, WithHeadings, WithStyles
{
    protected $filters;

    public function __construct($filters)
    {
        $this->filters = $filters;
    }

    public function collection()
    {
     $loginId = auth()->user()->login_id;
    $query = ClinicPrescription::with(['deliveryAgent'])
                ->where('status', '!=', 5)->where('clinic_id', $loginId);

        if (!empty($this->filters['from_date']) && !empty($this->filters['to_date'])) {
            $query->whereBetween('created_at', [
                $this->filters['from_date'] . ' 00:00:00',
                $this->filters['to_date'] . ' 23:59:59',
            ]);
        }

        $data = $query->get();

        // Calculate total
        $totalAmount = $data->sum('test_total');

        // Map data
        $mapped = $data->map(function ($item) {
            return [
                // 'ID' => $item->id,
                'Patient Name'     => $item->name ?? 'N/A',
              'Test Name'        => is_array(json_decode($item->test, true)) 
                        ? implode(', ', json_decode($item->test, true)) 
                        : ($item->test ?? 'N/A'),
   
                'Amount Collected' => $item->test_total,
                'Delivery Agent'   => $item->deliveryAgent->name ?? 'N/A',
                'Address'          => $item->address,
                'Date'             => Carbon::parse($item->created_at)->format('d-m-Y H:i'),
            ];
        });

        // Add grand total row
        $mapped->push([
            'Patient Name'     => '',
            'Test Name'         => '',
          
            'Amount Collected' => 'Grand Total: ' . number_format($totalAmount, 2),
            'Delivery Agent'   => '',
            'Address'          => '',
            'Date'             => '',
        ]);

        return $mapped;
    }

    public function headings(): array
    {
        return [
            // 'ID',
            'Patient Name',
            'Test Name',
            'Amount Collected',
            'Delivery Agent',
            'Delivery Agent',
            'Address',
            'Date',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Make first row (headings) bold
            1 => ['font' => ['bold' => true]],
        ];
    }
}

