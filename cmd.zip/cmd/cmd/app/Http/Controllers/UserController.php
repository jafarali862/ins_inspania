<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Log;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function index()
    {
      $users = User::where('status_new', '!=', 1)
    ->whereNull('login_id')
    ->whereNull('login_id2')
    ->where('role', '!=', 'admin') // 👈 Exclude users with role "Admin"
    ->get();
        return view('backend.user.users', compact('users'));

    }

    public function index2()
    {
      $users = User::where('status_new', '!=', 1)
    ->whereNull('login_id')
    ->whereNull('login_id2')
    ->where('role', '!=', 'admin') // 👈 Exclude users with role "Admin"
    ->get();

        return view('backend.user2.users', compact('users'));
    }

    public function create()
    {
        return view('backend.user.user_create');
    }

    public function create2()
    {
        return view('backend.user2.user_create');
    }

    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email:rfc,dns|unique:users,email',
            'password' => 'required|min:6',
            'date_of_birth' => 'required|date',
            'gender' => 'required|string',
            'phone_number' => 'required|string|max:10',
            'address' => 'required|string',
            'user_type'=>'required',
            'type' => 'required_if:user_type,1|string|nullable', // ✅ Fix here
            'insurance_provider' => 'nullable|string',
            'insurance_policy_number' => 'nullable|string',
            'primary_physician' => 'nullable|string',
            'medical_history' => 'nullable|string',
            'medications' => 'nullable|string',
            'allergies' => 'nullable|string',
            'blood_type' => 'nullable|string|max:10',
          
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'user_type'=>$request->user_type,    
            'type'=>$request->type,    
            'insurance_provider' => $request->insurance_provider,
            'insurance_policy_number' => $request->insurance_policy_number,
            'primary_physician' => $request->primary_physician,
            'medical_history' => $request->medical_history,
            'medications' => $request->medications,
            'allergies' => $request->allergies,
            'blood_type' => $request->blood_type,
            'status_new' => 0,
            // 'login_id' => auth()->id(),

        ]);

        Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'New User Created',
            'message' =>  'New User: ' . $request->name . 'created by ' . Auth::user()->name,
        ]);

        return redirect()->route('users.index')->with('success', 'User added successfully.');
    }

     public function store2(Request $request)
    {

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'date_of_birth' => 'required|date',
            'gender' => 'required|string',
            'phone_number' => 'required|string|max:10',
            'address' => 'required|string',
            'user_type'=>'required',
             'type'=>'nullable|string',
            'emergency_contact_name' => 'nullable|string',
            'emergency_contact_phone' => 'required|string',
            'insurance_provider' => 'nullable|string',
            'insurance_policy_number' => 'nullable|string',
            'primary_physician' => 'nullable|string',
            'medical_history' => 'nullable|string',
            'medications' => 'nullable|string',
            'allergies' => 'nullable|string',
            'blood_type' => 'nullable|string|max:10',
            'status' => 'required|boolean',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'user_type'=>$request->user_type,    
            'type'=>$request->type,    
            'emergency_contact_name' => $request->emergency_contact_name,
            'emergency_contact_phone' => $request->emergency_contact_phone,
            'insurance_provider' => $request->insurance_provider,
            'insurance_policy_number' => $request->insurance_policy_number,
            'primary_physician' => $request->primary_physician,
            'medical_history' => $request->medical_history,
            'medications' => $request->medications,
            'allergies' => $request->allergies,
            'blood_type' => $request->blood_type,
            'status' => $request->status,
            'login_id' => auth()->id(),
        ]);

        Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'New User Created',
            'message' =>  'New User: ' . $request->name . 'created by ' . Auth::user()->name,
        ]);

        return redirect()->route('users2.index')->with('success', 'User added successfully.');
    }


    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('backend.user.user_edit', compact('user'));
    }

      public function edit2($id)
    {
        $user = User::findOrFail($id);
        return view('backend.user2.user_edit', compact('user'));
    }


    public function updatePassword(Request $request)
    {
        // Validate input fields
        $request->validate([
            // 'current_password' => ['required', 'current_password'], // Laravel built-in validation rule
            'new_password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);

        // Get currently authenticated user
        $user = Auth::user();

        // Update password
        $user->password = bcrypt($request->new_password);
        $user->save();

        // Redirect back with success message
        return redirect()->back()->with('success', 'Password updated successfully!');
    }


    public function updateProfile(Request $request)
{
    $user = auth()->user();

    $request->validate([
        'name' => 'nullable|string|max:255',
        'email' => [
            'nullable',
            'email:rfc,dns',
            'unique:users,email,' . $user->id,
        ],
        'phone_number' => [
            'nullable',
            'digits:10',                  // Exactly 10 digits
            'regex:/^[0-9]{10}$/',        // Only numeric
            'unique:users,phone_number,' . $user->id, // Optional: prevent duplicate phone
        ],
    ]);

    // Only update if not null
    if ($request->filled('name')) {
        $user->name = $request->name;
    }

    if ($request->filled('email')) {
        $user->email = $request->email;
    }

    if ($request->filled('phone_number')) {
        $user->phone_number = $request->phone_number;
    }

    $user->save();

    return back()->with('success', 'Profile updated successfully.');
}



 public function showPhoneRequestForm()
    {
        return view('auth.passwords.phone'); // create this blade file
    }

     public function showOtpForm()
    {
        return view('auth.passwords.verify-otp'); // create this blade file
    }


     public function verifyOtp(Request $request)
{
    $request->validate(['otp' => 'required']);

    $user = User::find(1);

    if ($user && $request->otp == $user->otp2) {
        // OTP is correct
        return redirect()->route('password.reset.form');
    } else {
        return back()->withErrors(['otp' => 'Invalid OTP']);
    }
}
    public function showResetForm()
    {
        return view('auth.passwords.reset'); // create this blade file
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'password' => 'required|min:6|confirmed',
        ]);

        // This assumes you're always resetting user with ID = 1
        $user = \App\Models\User::find(1); // or use phone number from session to identify user
        if (!$user) {
            return back()->withErrors(['user' => 'User not found']);
        }

        $user->password = Hash::make($request->password);
        $user->save();

        // Clear session
        Session::forget('otp');
        Session::forget('phone');

        return redirect('/login')->with('status', 'Password successfully reset!');
    }

    


   
public function sendPasswordResetOtp(Request $request)
{
    $request->validate([
        'phone' => 'required|digits:10'
    ]);

    $otp = rand(100000, 999999);
    $refId = rand(1000, 9999);

    // 💾 Save OTP to the first user (id = 1)
    $user = User::where('phone_number', $request->phone)->first();

    if (!$user) {
        return back()->withErrors(['phone' => 'User with this phone number not found.']);
    }


    // Step 3: Generate OTP and save it
    $otp = rand(100000, 999999);
    $user->otp2 = $otp;
    $user->save();

    // Send SMS
    $templateMessage = "Your Login OTP for CoMed is $otp. Please enter this code to continue. Do not share this OTP with anyone. Areacode SCB";

    $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
        'username'   => 'ascbcomed',
        'password'   => 'Comed@123',
        'mobile'     => $request->phone,
        'message'    => $templateMessage,
        'sendername' => 'ARDSCB',
        'routetype'  => 1,
        'tid'        => '1207175437936872721',
        'var1'       => 'CoMed',
        'var2'       => $otp,
    ]);

    // Optional: store OTP in session (if you want to verify via session later)
    // Session::put('otp', $otp);

    return redirect()->route('password.otp.verify')->with('message', 'OTP sent to your phone.');
}





    public function update(Request $request, $id)
    {
        
            $user = User::findOrFail($id);

            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email:rfc,dns|unique:users,email,' . $user->id,
                'password' => 'nullable|min:6',
                'date_of_birth' => 'required|date',
                'gender' => 'required|string',
                'phone_number' => 'required|string|max:10',
                'address' => 'required|string',
                'user_type'=>'required',
                // 'type'=>'required',     
                'insurance_provider' => 'nullable|string',
                'insurance_policy_number' => 'nullable|string',
                'primary_physician' => 'nullable|string',
                'medical_history' => 'nullable|string',
                'medications' => 'nullable|string',
                'allergies' => 'nullable|string',
                'blood_type' => 'nullable|string|max:10',
                'role' => 'nullable'
            ]);

            $user->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->filled('password') ? bcrypt($request->password) : $user->password,
                'date_of_birth' => $request->date_of_birth,
                'gender' => $request->gender,
                'phone_number' => $request->phone_number,
                'address' => $request->address,
                'user_type'=>$request->user_type,
                // 'type'=>$request->type,
                'insurance_provider' => $request->insurance_provider,
                'insurance_policy_number' => $request->insurance_policy_number,
                'primary_physician' => $request->primary_physician,
                'medical_history' => $request->medical_history,
                'medications' => $request->medications,
                'allergies' => $request->allergies,
                'blood_type' => $request->blood_type,
            ]);

            $user = User::findOrFail($id);
           

            Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'User updated',
                'message' =>  'User: ' . $request->name . ' , user Id: ' . $id . ' , User updated by ' . Auth::user()->name,
            ]);

            return redirect()->route('users.index')->with('success', 'User updated successfully.');
        
    }


     public function update2(Request $request, $id)
    {
        try {
            $user = User::findOrFail($id);

            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,' . $user->id,
                'password' => 'nullable|min:6',
                'date_of_birth' => 'required|date',
                'gender' => 'required|string',
                'phone_number' => 'required|string|max:10',
                'address' => 'required|string',
                'user_type'=>'required',
                // 'type'=>'required',     
                'emergency_contact_name' => 'nullable|string',
                'emergency_contact_phone' => 'nullable|string',
                'insurance_provider' => 'nullable|string',
                'insurance_policy_number' => 'nullable|string',
                'primary_physician' => 'nullable|string',
                'medical_history' => 'nullable|string',
                'medications' => 'nullable|string',
                'allergies' => 'nullable|string',
                'blood_type' => 'nullable|string|max:10',
                'status' => 'nullable|boolean',
                'role' => 'nullable'
            ]);

            $user->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->filled('password') ? bcrypt($request->password) : $user->password,
                'date_of_birth' => $request->date_of_birth,
                'gender' => $request->gender,
                'phone_number' => $request->phone_number,
                'address' => $request->address,
                'user_type'=>$request->user_type,
                // 'type'=>$request->type,
                'emergency_contact_name' => $request->emergency_contact_name,
                'emergency_contact_phone' => $request->emergency_contact_phone,
                'insurance_provider' => $request->insurance_provider,
                'insurance_policy_number' => $request->insurance_policy_number,
                'primary_physician' => $request->primary_physician,
                'medical_history' => $request->medical_history,
                'medications' => $request->medications,
                'allergies' => $request->allergies,
                'blood_type' => $request->blood_type,
                'status' => $request->status,
            ]);

            $user = User::findOrFail($id);
            if ($user->status == 0) {
                $user->tokens()->delete();
            }

            Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'User updated',
                'message' =>  'User: ' . $request->name . ' , user Id: ' . $id . ' , User updated by ' . Auth::user()->name,
            ]);

            return redirect()->route('users2.index')->with('success', 'User updated successfully.');
        } catch (Exception $e) {
            
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->tokens()->delete();
        $user->delete();

        Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'User Deleted',
                'message' =>  'User: ' . $user->name . ' , user Id: ' . $id . ' , User deleted by ' . Auth::user()->name,
            ]);

        return redirect()->route('users.index')->with('success', 'User deleted successfully.');
    }

     public function destroy2($id)
    {
        $user = User::findOrFail($id);
        $user->tokens()->delete();
        $user->delete();

        Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'User Deleted',
                'message' =>  'User: ' . $user->name . ' , user Id: ' . $id . ' , User deleted by ' . Auth::user()->name,
            ]);

        return redirect()->route('users2.index')->with('success', 'User deleted successfully.');
    }
}
