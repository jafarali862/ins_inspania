<?php

namespace App\Http\Controllers;

use App\Models\Log;
use App\Models\User;
use App\Models\Medicine;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use App\Models\PharmacyMedicine;
use App\Models\ClinicPrescription;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Models\PharmacyPrescription as pprescription;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;

class PharmacyPrescription extends Controller
{
    public function index()
    {   
        $val=0;
        $medicines = Medicine::all();
        
        $pharmacyPrescriptions = pprescription::with(['user', 'pharmacy'])
        ->where('status', 0)
        ->orderBy('created_at', 'desc')
        ->paginate(10);

        // $hasPaymentColumn = pprescription::where('status', 2)
        // ->whereIn('payment_method', [1, 2])
        // ->exists(); // ✅ Works globally
        $pharmacies = Pharmacy::all(); // or ->orderBy('name')->get();
       $deliveryAgents=User::where('user_type',1)->get();
        return view('backend.pharmacypres.index', compact('pharmacyPrescriptions','medicines','val','pharmacies','deliveryAgents'));
    }

     public function index2()
    {   
         $val=0;
        $medicines = Medicine::all();
           $loginId = auth()->user()->login_id2;
        $pharmacyPrescriptions = pprescription::with(['user', 'pharmacy'])
        ->where('status', 0)
            ->where('pharmacy_id', $loginId) // filter by login_id

        ->orderBy('created_at', 'desc')
        ->paginate(10);
   $deliveryAgents=User::where('user_type',1)->get();

        return view('backend.pharmacypres2.index', compact('pharmacyPrescriptions', 'medicines','val','deliveryAgents'));
    }



        // public function checkNew()
        // {
        // // count new prescriptions with status = 0
        // $newCount = pprescription::where('status', 0)->count();

        // return response()->json(['new_count' => $newCount]);
        // }

    public function checkNew()
    {
    $latest = pprescription::orderBy('id', 'desc')->first();

    return response()->json([
    'latest_id' => $latest ? $latest->id : 0
    ]);
    }

    public function checkNew2()
    {
    $latest = ClinicPrescription::orderBy('id', 'desc')->first();

    return response()->json([
    'latest_id' => $latest ? $latest->id : 0
    ]);
    }

    public function completeAuth(Request $request)
    {
    $request->validate([
        'auth_password' => 'required',
        'id2' => 'required|integer|exists:pharmacy_prescriptions,id',
    ]);

    $prescription = pprescription::findOrFail($request->id2);
    $user = auth()->user();

    // ✅ Proper way to check hashed password
    if (!Hash::check($request->auth_password, $user->password)) {
        return response()->json([
            'success' => false,
            'message' => 'Password does not match the authenticated user.',
            'errors'  => ['auth_password' => ['Password is incorrect.']]
        ], 422);
    }

    // Update prescription status
    $prescription->status = 4;
    $prescription->login_id_new = $user->id;
    $prescription->save();

    return response()->json([
        'success' => true,
        'message' => 'Prescription marked as completed successfully.',
    ]);
    }






  public function store(Request $request)
    {
        $request->validate([
            'name'             => 'required|string|max:255', // must match input name in blade
            'pharmacy_id'      => 'required|exists:pharmacies,id',
            'payment_method'   => 'required|string',
            'amount'           => 'required|numeric',
            'prescription'     => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
            'assigned_user'    => 'required|exists:users,id',
            'delivery_date'    => 'required|date',
            'delivery_address' => 'required|string',
        ]);

        $prescriptionPaths = [];

        if ($request->hasFile('prescription')) {
            $file = $request->file('prescription');
            $path = $file->store('prescriptions', 'public');
            $prescriptionPaths[] = $path;
        }

        pprescription::create([
            'name'             => $request->name, // match form input
            'pharmacy_id'      => $request->pharmacy_id,
            'user_id'          => auth()->id() ?? 1, // optional auth fallback
            'payment_method'   => $request->payment_method,
            'total_amount'     => $request->amount,
            'prescription'     => json_encode($prescriptionPaths),
            'delivery_id'      => $request->assigned_user,
            'expect_date'      => $request->delivery_date,
            'delivery_address' => $request->delivery_address,
            'status'           => 3,
            'lat_long'         => '11.2352648,76.0522042',
        ]);

       return redirect()->route('pharmacy-prescriptions.index')
                     ->with('success', 'Pharmacy prescription saved successfully!')
                      ->with('status_filter', 3);

    }



    public function edit($id)
    {
        $medicines = Medicine::all();
        // $pharmacyPrescription = pprescription::findOrFail($id);
        $pharmacyPrescription = pprescription::with('deliveryAgent')->findOrFail($id);
        $users = User::all();
        $deliveryAgents=User::where('user_type',1)->get();
        $pharmacies = Pharmacy::all();
        $medicinesPhar = PharmacyMedicine::with('medicine')->withTrashed()->where('pharmacy_prescription_id', $id)->distinct()->get();


        $pharmacyPrescription22 = pprescription::with('deliveryAgent')
    ->where('id', $id) // fetch the row with this ID
    ->select('*') // select all columns
    ->selectRaw("
        CASE 
            WHEN status = 1 
                 AND (total_amount IS NOT NULL AND TRIM(total_amount) != '') 
                 AND receipt = '1' 
            THEN 1 ELSE 0 
        END as med_status
    ")
    ->firstOrFail();

        return view('backend.pharmacyPres.edit_ppres', compact('pharmacyPrescription','pharmacyPrescription22', 'users', 'pharmacies', 'medicinesPhar', 'medicines','deliveryAgents'));
    }

     public function edit2($id)
    {
        $medicines = Medicine::all();
        $pharmacyPrescription = pprescription::findOrFail($id);
        $users = User::all();
        $deliveryAgents=User::where('user_type',1)->get();
        $pharmacies = Pharmacy::all();
        $medicinesPhar = PharmacyMedicine::with('medicine')->withTrashed()->where('pharmacy_prescription_id', $id)->distinct()->get();
         
          $pharmacyPrescription22 = pprescription::with('deliveryAgent')
    ->where('id', $id) // fetch the row with this ID
    ->select('*') // select all columns
    ->selectRaw("
        CASE 
            WHEN status = 1 
                 AND (total_amount IS NOT NULL AND TRIM(total_amount) != '') 
                 AND receipt = '1' 
            THEN 1 ELSE 0 
        END as med_status
    ")
    ->firstOrFail();

        return view('backend.pharmacyPres2.edit_ppres', compact('pharmacyPrescription','pharmacyPrescription22', 'users', 'pharmacies', 'medicinesPhar', 'medicines','deliveryAgents'));
    }


    public function update(Request $request, $id)
    {
        //   dd($request->all());
        $request->validate([

            'delivery_address' => 'required|string',
        ]);

        $pharmacyPrescription = pprescription::findOrFail($id);
        $pharmacyPrescription->delivery_address = $request->delivery_address;
        $pharmacyPrescription->save();

      

        Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'Pharmacy Pescription Address Updated',
            'message' =>  'Pharmacy Pescription Address Updated: ' . $request->delivery_address . 'created by ' . Auth::user()->name,
        ]);

        return redirect()->route('pharmacy-prescriptions.index')->with('success', 'Prescription updated successfully.');
    }

     public function update2(Request $request, $id)
    {
        //   dd($request->all());
        $request->validate([

            'delivery_address' => 'required|string',
        ]);

        $pharmacyPrescription = pprescription::findOrFail($id);
        $pharmacyPrescription->delivery_address = $request->delivery_address;
        $pharmacyPrescription->save();

      

        Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'Pharmacy Pescription Address Updated',
            'message' =>  'Pharmacy Pescription Address Updated: ' . $request->delivery_address . 'created by ' . Auth::user()->name,
        ]);

        return redirect()->route('pharmacy-prescriptions2.index')->with('success', 'Prescription updated successfully.');
    }

    public function store2(Request $request)
    {
        $request->validate([
            'name'             => 'required|string|max:255', // must match input name in blade
            // 'pharmacy_id'      => 'required|exists:pharmacies,id',
            'payment_method'   => 'required|string',
            'amount'           => 'required|numeric',
            'prescription'     => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
            'assigned_user'    => 'required|exists:users,id',
            'delivery_date'    => 'required|date',
            'delivery_address' => 'required|string',
        ]);

        $prescriptionPaths = [];

        if ($request->hasFile('prescription')) {
            $file = $request->file('prescription');
            $path = $file->store('prescriptions', 'public');
            $prescriptionPaths[] = $path;
        }

        pprescription::create([
            'name'             => $request->name, // match form input
            'pharmacy_id'      => auth()->user()->login_id2,
            'user_id'          => auth()->id() ?? 1, // optional auth fallback
            'payment_method'   => $request->payment_method,
            'total_amount'     => $request->amount,
            'prescription'     => json_encode($prescriptionPaths),
            'delivery_id'      => $request->assigned_user,
            'expect_date'      => $request->delivery_date,
            'delivery_address' => $request->delivery_address,
            'status'           => 3,
            'lat_long'         => '11.2352648,76.0522042',
        ]);

       return redirect()->route('pharmacy-prescriptions2.index')
                     ->with('success', 'Pharmacy prescription saved successfully!')
                   ->with('status_filter', 3);

    }



    public function pharmacyPresStatus(Request $request)
    {
        $query = $request->input('status');
       // $page = $request->input('page', 1);
        // $pPrescriptions = pprescription::where('status', '=', $query)->orderBy('created_at', 'desc')->get();
        $pPrescriptions = pprescription::where('status', '=', $query)->orderBy('created_at', 'desc')->paginate(10);
        

        $output = '';
        foreach ($pPrescriptions as $prescription) {
        $prescriptionImages = '';
        if ($prescription->prescription) {
        $images = json_decode($prescription->prescription, true);
        $imageUrls = array_map(function ($img) {
        return asset('storage/' . $img);
        }, $images);

        $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

        if (count($images) > 1) {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
        <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i></a>';
        } else {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
        <i class="fas fa-images" style="color: green; font-size: 20px;"></i></a>';
        }
        } else {
        $prescriptionImages = '<span>No image</span>';
        }

        $style = '';


    if ($prescription->payment_method == 1) {
        $style = 'background-color: lightgreen;';
    } elseif ($prescription->payment_method == 2) {
        $style = 'background-color: #fcff42;';
    }


$output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';


        $output .= '
        <td>' . htmlspecialchars($prescription->user->name) . '</td>
        <td>' . htmlspecialchars($prescription->name) . '</td> 
        <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name) . '</td>
        <td>' . htmlspecialchars($prescription->user->phone_number) . '</td>
        <td>' . $prescriptionImages . '</td>
        <td>' . htmlspecialchars($prescription->delivery_address) . '</td>
        <td>' . htmlspecialchars($prescription->lat_long) . '</td> 
        <td class="payment-method-th">' 
        . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
        . '</td>
        <td>' . $prescription->created_at . '</td> 
        <td>
        <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
        <i class="fas fa-eye"></i>
        </button>
        </td>
        </tr>';

        }

        return response()->json([
        'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);

    }


       public function pharmacyPresStatus2(Request $request)
    {
          $loginId = auth()->user()->login_id2;
        $query = $request->input('status');
       // $page = $request->input('page', 1);
        // $pPrescriptions = pprescription::where('status', '=', $query)->orderBy('created_at', 'desc')->get();
        $pPrescriptions = pprescription::where('status', '=', $query)
            ->where('pharmacy_id', $loginId)->orderBy('created_at', 'desc')->paginate(10);
        

        $output = '';
        foreach ($pPrescriptions as $prescription) {
            $prescriptionImages = '';
            if ($prescription->prescription) {
    $images = json_decode($prescription->prescription, true);
    $imageUrls = array_map(function ($img) {
        return asset('storage/' . $img);
    }, $images);

    $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

    if (count($images) > 1) {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
            <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i></a>';
    } else {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
            <i class="fas fa-images" style="color: green; font-size: 20px;"></i></a>';
    }
} else {
    $prescriptionImages = '<span>No image</span>';
}

      $style = '';


    if ($prescription->payment_method == 1) {
        $style = 'background-color: lightgreen;';
    } elseif ($prescription->payment_method == 2) {
        $style = 'background-color: #fcff42;';
    }


$output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';


$output .= '
    <td>' . htmlspecialchars($prescription->user->name) . '</td>
    <td>' . htmlspecialchars($prescription->name) . '</td> 
    <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name) . '</td>
    <td>' . htmlspecialchars($prescription->user->phone_number) . '</td>
    <td>' . $prescriptionImages . '</td>
    <td>' . htmlspecialchars($prescription->delivery_address) . '</td>
    <td>' . htmlspecialchars($prescription->lat_long) . '</td> 
    <td class="payment-method-th">' 
        . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
    . '</td>
    <td>' . $prescription->created_at . '</td> 
    <td>
        <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
            <i class="fas fa-eye"></i>
        </button>
    </td>
</tr>';


        
        }

        return response()->json([
            'output' => $output,
             'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);
    }

    public function pharmacyPresDate(Request $request)
    {
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');



        $pPrescriptions = pprescription::whereBetween('created_at', [$startDate . '%', $endDate . '%'])->orderBy('created_at', 'desc')->paginate(10);

        $output = '';
        foreach ($pPrescriptions as $prescription) {
        $prescriptionImages = '';
        if ($prescription->prescription) {
        $images = json_decode($prescription->prescription, true);
        $imageUrls = array_map(function ($img) {
        return asset('storage/' . $img);
        }, $images);

        $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

        if (count($images) > 1) {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
        <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i></a>';
        } else {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
        <i class="fas fa-images" style="color: green; font-size: 20px;"></i></a>';
        }
        } else {
        $prescriptionImages = '<span>No image</span>';
        }
 $style = '';

     
        if ($prescription->payment_method == 1) {
        $style = 'background-color: lightgreen;';
        } elseif ($prescription->payment_method == 2) {
        $style = 'background-color: #fcff42;';
        }
     

        $output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';

        $output .= '
        <td>' . htmlspecialchars($prescription->user->name) . '</td>
        <td>' . htmlspecialchars($prescription->name) . '</td> 
        <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name) . '</td>
        <td>' . htmlspecialchars($prescription->user->phone_number) . '</td>
        <td>' . $prescriptionImages . '</td>
        <td>' . htmlspecialchars($prescription->delivery_address) . '</td>
        <td>' . htmlspecialchars($prescription->lat_long) . '</td> 
        <td class="payment-method-th">' 
        . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
        . '</td>
        <td>' . $prescription->created_at . '</td> 
        <td>
        <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
        <i class="fas fa-eye"></i>
        </button>
        </td>
        </tr>';

        }

        return response()->json([
        'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);
    }


     public function pharmacyPresDate2(Request $request)
    {
         $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');


$loginId = auth()->user()->login_id2;

$pPrescriptions = pprescription::where('pharmacy_id', $loginId)
    ->whereBetween('created_at', [$startDate, $endDate])
    ->orderBy('created_at', 'desc')
    ->paginate(10);
        // $pPrescriptions = pprescription::whereBetween('created_at', [$startDate . '%', $endDate . '%'])->orderBy('created_at', 'desc')->paginate(10);

        $output = '';
        foreach ($pPrescriptions as $prescription) {
        $prescriptionImages = '';
        if ($prescription->prescription) {
        $images = json_decode($prescription->prescription, true);
        $imageUrls = array_map(function ($img) {
        return asset('storage/' . $img);
        }, $images);

        $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

        if (count($images) > 1) {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
        <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i></a>';
        } else {
        $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
        <i class="fas fa-images" style="color: green; font-size: 20px;"></i></a>';
        }
        } else {
        $prescriptionImages = '<span>No image</span>';
        }

        $style = '';

       
        if ($prescription->payment_method == 1) {
        $style = 'background-color: lightgreen;';
        } elseif ($prescription->payment_method == 2) {
        $style = 'background-color: #fcff42;';
        }
      

        $output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';

        $output .= '
        <td>' . htmlspecialchars($prescription->user->name) . '</td>
        <td>' . htmlspecialchars($prescription->name) . '</td> 
        <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name) . '</td>
        <td>' . htmlspecialchars($prescription->user->phone_number) . '</td>
        <td>' . $prescriptionImages . '</td>
        <td>' . htmlspecialchars($prescription->delivery_address) . '</td>
        <td>' . htmlspecialchars($prescription->lat_long) . '</td> 
        <td class="payment-method-th">' 
        . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
        . '</td>
        <td>' . $prescription->created_at . '</td> 
        <td>
        <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
        <i class="fas fa-eye"></i>
        </button>
        </td>
        </tr>';

        }

        return response()->json([
        'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);
    }

    public function rejected($id)
    {
        $pharmacyPrescription = pprescription::findOrFail($id);
        $pharmacyPrescription->status=5;
        $pharmacyPrescription->save();
        return back();
    }
    
}
