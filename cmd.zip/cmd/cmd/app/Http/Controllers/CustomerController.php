<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Clinic;
use App\Models\Medicine;
use App\Models\Pharmacy;
use App\Models\Test;
use Illuminate\Http\Request;
use App\Models\ClinicPrescription;
use App\Models\PharmacyPrescription;
use Illuminate\Support\Facades\Http;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index()
    {   
        $today= Carbon::now()->toDateString();

        //  $users = User::where('login_id', auth()->id())->get();

        $userCount = User::where('status_new', '!=', 1)
        ->where('role', '!=', 'admin') // ✅ Exclude Admins
        ->where(function ($query) {
        $query->where(function ($q) {
        $q->whereNull('login_id')->orWhere('login_id', '');
        })->where(function ($q) {
        $q->whereNull('login_id2')->orWhere('login_id2', '');
        });
        })
        ->count();

        
        // $userCount=count($users);

        // $clinic=Clinic::where('user_id', auth()->id())->get();     
        // $clinicCount=count($clinic);
        // $pharmacy=Pharmacy::where('user_id', auth()->id())->get();
        // $pharmacyCount=count($pharmacy);
        $medicine=Medicine::all();
        $medicineCount=count($medicine);
        $pharmacyPres=PharmacyPrescription::where("created_at","like",$today.'%')->get();
        $pharmacyPresCount=count( $pharmacyPres);
        $clinicPres=ClinicPrescription::where("created_at","like",$today.'%')->get();
        $clinicPresCount=count($clinicPres);

        $loginId = auth()->user()->login_id;
         $loginId2 = auth()->user()->login_id2;

        $clinic=Clinic::all();
        $clinicCount=count($clinic);
        $pharmacy=Pharmacy::all();
        $pharmacyCount=count($pharmacy);
        $pharmacyPres2=PharmacyPrescription::where("payment_method",'1')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount2=count( $pharmacyPres2);

        $pharmacyPres3=PharmacyPrescription::where("payment_method",'2')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount3=count( $pharmacyPres3);

        $clinicPres11=ClinicPrescription::where("status",'1')->where('clinic_id', $loginId)->get();
        $clinicPresCount11=count( $clinicPres11);

        $clinicPres12=ClinicPrescription::where("status",'2')->where('clinic_id', $loginId)->get();
        $clinicPresCount12=count( $clinicPres12);

        $clinicPres13=ClinicPrescription::where("status",'3')->where('clinic_id', $loginId)->get();
        $clinicPresCount13=count( $clinicPres13);

        $clinicPres14=ClinicPrescription::where("status",'4')->where('clinic_id', $loginId)->get();
        $clinicPresCount14=count( $clinicPres14);

        $clinicPres15=ClinicPrescription::where("status",'5')->where('clinic_id', $loginId)->get();
        $clinicPresCount15=count( $clinicPres15);

        $pharmacyPres11=PharmacyPrescription::where("status",'1')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount11=count( $pharmacyPres11);

        $pharmacyPres12=PharmacyPrescription::where("status",'2')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount12=count( $pharmacyPres12);

        $pharmacyPres13=PharmacyPrescription::where("status",'3')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount13=count( $pharmacyPres13);

        $pharmacyPres14=PharmacyPrescription::where("status",'4')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount14=count( $pharmacyPres14);

        $pharmacyPres15=PharmacyPrescription::where("status",'5')->where('pharmacy_id', $loginId2)->get();
        $pharmacyPresCount15=count( $pharmacyPres15);

         $test=Test::where("clinic_id",$loginId2)->get();
                $testcount=count( $test);

     $smsBalance = $this->getSmsBalance();


$loginId = auth()->user()->login_id;

// Get all 'test' strings like "CBC, Lipid Profile"
$testStrings = \App\Models\ClinicPrescription::where('clinic_id', $loginId)
    ->pluck('test')
    ->filter() // removes null/empty
    ->toArray();

$allTests = [];

foreach ($testStrings as $testString) {
    if (is_string($testString) && str_starts_with($testString, '[')) {
        $decoded = json_decode($testString, true); // ["Blood Test,CB"]
        if (is_array($decoded)) {
            $testString = implode(',', $decoded); // "Blood Test,CB"
        }
    }



    $tests = explode(',', $testString);
    foreach ($tests as $test) {
        $cleanTest = trim($test, "[]\" "); // remove brackets/quotes/spaces
        if (!empty($cleanTest)) {
            $allTests[] = $cleanTest;
        }
    }
}

// Count how often each test appears
$testCounts = array_count_values($allTests);

// Sort and take top 4 tests
arsort($testCounts);
$topTests = array_slice($testCounts, 0, 4, true);

$labels = array_keys($topTests);   // 👉 ["Blood Test", "CB"]
$counts = array_values($topTests);



  
        return view('backend.home_customer',compact('userCount','clinicCount','pharmacyCount','medicineCount','pharmacyPresCount','clinicPresCount','clinicPresCount11',
        'clinicPresCount12',  'clinicPresCount13',  'clinicPresCount14','clinicPresCount15','smsBalance',
        'pharmacyPresCount11',  'pharmacyPresCount12','pharmacyPresCount13','pharmacyPresCount14','pharmacyPresCount15',
       'pharmacyPresCount2','pharmacyPresCount3','testcount','labels', 'counts'));
        
    }

    public function getSmsBalance()
{
    $response = Http::get('http://smsgt.niveosys.com/SMS_API/balanceinfo.php?apikey=595e1783-6ba7-11f0-9b8b-e29d2b69142c');

    if ($response->successful()) {
        $body = $response->body();  // e.g. "T-50<br>P-0"
        $parts = explode('<br>', $body);

        $tPart = trim($parts[0] ?? ''); // "T-50"

        // Remove "T-" prefix if exists
        if (str_starts_with($tPart, 'T-')) {
            $tPart = substr($tPart, 2);  // removes first 2 chars "T-"
        }

        return $tPart ?: 'N/A';
    }

    return 'N/A';
}


}
