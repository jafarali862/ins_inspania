<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\User;
use App\Models\Clinic;
use App\Models\Test;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log as Logs;
use App\Models\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ClinicController extends Controller
{
    public function index()
    {
        try {
            $clinics = Clinic::all();
            return view('backend.clinic.clinic', compact('clinics'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

    public function index2()
    {
        try {
            $clinics = Clinic::all();
            return view('backend.clinic2.clinic', compact('clinics'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }


     public function tests()
    {
        try {
            // $tests= Test::all();
            
            $tests = Test::with('clinic')->get(); // Eager loading

            $clinics = Clinic::all();

            return view('backend.test.test', compact('tests','clinics'));
        } 
        catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

  

    public function createtests()
    {
        try {
              $clinics = Clinic::all();
            return view('backend.test.test-add',compact('clinics'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

     public function mergeClinicTests(Request $request)
{
    $request->validate([
        'source_clinic_id' => 'required|exists:clinics,id',
        'target_clinic_ids' => 'required|array',
        'target_clinic_ids.*' => 'exists:clinics,id',
    ]);

    $sourceClinicId = $request->source_clinic_id;
    $targetClinicIds = $request->target_clinic_ids;

    $tests = Test::where('clinic_id', $sourceClinicId)->get();

    foreach ($targetClinicIds as $targetClinicId) {
        foreach ($tests as $test) {
            // Check if this test already exists for the target clinic to avoid duplicates
            $exists = Test::where('clinic_id', $targetClinicId)
                ->where('test_name', $test->test_name)
                ->exists();

            if (!$exists) {
                Test::create([
                    'clinic_id'   => $targetClinicId,
                    'test_name'   => $test->test_name,
                    'description' => $test->description,
                    'amount'      => $test->amount,
                ]);
            }
        }
    }

    return redirect()->route('tests')->with('success', 'Tests successfully merged to selected clinics.');
}





    public function store_test(Request $request)
    {

    try 
    {
    $request->validate([
    'clinic_selection' => 'required', 
    'test_name' => 'required|string|max:255',
    'amount' => 'required',
    'description' => 'nullable|string',
    ]);

    $clinicSelection = $request->clinic_selection;

    if ($clinicSelection === 'all') 
    {
    $clinics = Clinic::all(); // Fetch all clinics

    foreach ($clinics as $clinic) 
    {
    Test::create([
    'clinic_id'   => $clinic->id,
    'test_name'   => $request->test_name,
    'description' => $request->description,
    'amount'      => $request->amount,
    ]);
    }
    }

    else 
    {

    Test::create([
    'clinic_id'   => $clinicSelection,
    'test_name'   => $request->test_name,
    'description' => $request->description,
    'amount'      => $request->amount,
    ]);
    }

    return redirect()->route('tests')->with('success', 'Test(s) added successfully!');
    } 
    catch (Exception $e) 
    {
    Logs::error($e);
    return back()->withErrors(['error' => $e->getMessage()]);
    }



    }


    public function edit_test($id)
    {
        try {
            $test = Test::findOrFail($id);
           $clinics = Clinic::all();

            return view('backend.test.test-edit', compact('test','clinics'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }



     public function tests2()
{
    try {
        // Get logged in user's clinic_id (stored in login_id)
        $loginId = auth()->user()->login_id;

        // Only fetch tests that belong to this clinic
        $tests = Test::with('clinic')
                     ->where('clinic_id', $loginId)
                     ->get();

        // If you only need this user's clinic, no need to load all clinics
        $clinics = Clinic::where('id', $loginId)->get();

        return view('backend.test.test2', compact('tests', 'clinics'));
    } 
    catch (\Exception $e) {
        // \Log::error($e);
        return $e->getMessage();
    }
}


    public function createtests2()
    {
        try {
              $clinics = Clinic::all();
            return view('backend.test.test-add2',compact('clinics'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }


 public function store_test2(Request $request)
    {

      $loginId = auth()->user()->login_id;
    try 
    {
    $request->validate([
    'test_name' => 'required|string|max:255',
    'amount' => 'required',
    'description' => 'nullable|string',
    ]);



    Test::create([
    'clinic_id'   => $loginId,
    'test_name'   => $request->test_name,
    'description' => $request->description,
    'amount'      => $request->amount,
    ]);
    

    return redirect()->route('tests2')->with('success', 'Test(s) added successfully!');
    } 
    catch (Exception $e) 
    {
    Logs::error($e);
    return back()->withErrors(['error' => $e->getMessage()]);
    }

    }


public function edit_test2($id)
    {
        try {
            $test = Test::findOrFail($id);
           $clinics = Clinic::all();

            return view('backend.test.test-edit2', compact('test','clinics'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }


public function update_test2(Request $request, $id)
{

    try 
    {
        $request->validate([
      
            'test_name'        => 'required|string|max:255',
            'amount'           => 'required',
            'description'      => 'nullable|string',
        ]);

        
        $test = Test::findOrFail($id);

        $test->update([
            'test_name'   => $request->test_name,
            'amount'      => $request->amount,
            'description' => $request->description,
        ]);

        return redirect()->route('tests2')->with('success', 'Test updated successfully.');
    } 
    catch (Exception $e) 
    {
        Logs::error($e);
        return back()->withErrors(['error' => $e->getMessage()]);
    }
}


 public function destroy_test2($id)
    {
        try 
        {
            $test = Test::findOrFail($id);

            $test->delete();
            
            return redirect()->route('tests2')->with('success', 'Tests deleted successfully');
        }

        catch (Exception $e) 
        {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }




  public function update_test(Request $request, $id)
  {
    try {
        $request->validate([
            'clinic_selection' => 'required',
            'test_name'        => 'required|string|max:255',
            'amount'           => 'required',
            'description'      => 'nullable|string',
        ]);

        $clinicSelection = $request->clinic_selection;

        // Case: All Clinics selected
        if ($clinicSelection === 'all') {
            // Delete the current test (optional, or mark as template/archive)
            $test = Test::findOrFail($id);
            $test->delete();

            // Get all clinic IDs
            $allClinics = Clinic::pluck('id');

            // Create test for each clinic
            foreach ($allClinics as $clinicId) {
                Test::create([
                    'clinic_id'   => $clinicId,
                    'test_name'   => $request->test_name,
                    'amount'      => $request->amount,
                    'description' => $request->description,
                ]);
            }

            return redirect()->route('tests')->with('success', 'Test updated for all clinics.');
        }

        // Case: Single clinic update
        $test = Test::findOrFail($id);

        $test->update([
            'clinic_id'   => $clinicSelection,
            'test_name'   => $request->test_name,
            'amount'      => $request->amount,
            'description' => $request->description,
        ]);

        return redirect()->route('tests')->with('success', 'Test updated successfully.');
    } catch (Exception $e) {
        Logs::error($e);
        return back()->withErrors(['error' => $e->getMessage()]);
    }
}


    public function destroy_test($id)
    {
        try 
        {
            $test = Test::findOrFail($id);

            $test->delete();
            
            return redirect()->route('tests')->with('success', 'Tests deleted successfully');
        }

        catch (Exception $e) 
        {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }



    public function createClinic()
    {
        try {
            return view('backend.clinic.clinic-add');
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

     public function createClinic2()
    {
        try {
            return view('backend.clinic2.clinic-add');
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }



     public function store(Request $request)
{
    // Let validation throw exceptions that Laravel handles automatically
    $request->validate([
        'clinic_name' => 'required|string|max:255',
        'clinic_address' => 'required|string',
        'city' => 'required|string|max:100',
        'phone_number' => 'required|string|max:20',
        'email' => 'required|email',
        'password' => 'required|min:6',
        'clinic_photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg'
    ]);

    try {
        $clinicPhotoPath = null;
        if ($request->hasFile('clinic_photo')) {
            $clinicPhoto = $request->file('clinic_photo');
            $clinicPhotoPath = $clinicPhoto->store('clinic_photos', 'public');
        }

        $clinic = Clinic::create([
            'clinic_name' => $request->clinic_name,
            'clinic_address' => $request->clinic_address,
            'password' => bcrypt($request->password),
            'city' => $request->city,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
            'clinic_photo' => $clinicPhotoPath,
        ]);

        User::create([
            'name' => $request->clinic_name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'login_id' => $clinic->id,
            'user_type' => 0,
        ]);

        Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'clinic created',
            'message' => 'clinic: '. $request->clinic_name .' created by '. Auth::user()->name,
        ]);

        return redirect()->route('clinic')->with('success', 'Clinic added successfully!');
    } catch (Exception $e) {
        Logs::error($e);
        return back()->withErrors('Something went wrong. Please try again.'); // better error handling here
    }
}


     public function store2(Request $request)
    {
        try {
            $request->validate([
                'clinic_name' => 'required|string|max:255',
                'tests.*' => 'nullable',
                'clinic_address' => 'required|string',
                'city' => 'required|string|max:100',
                'phone_number' => 'required|string|max:20',
                'email' => 'required|email',
                'clinic_photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
            ]);

            $clinicPhotoPath = null;
            if ($request->hasFile('clinic_photo')) {
                $clinicPhoto = $request->file('clinic_photo');
                $clinicPhotoPath = $clinicPhoto->store('clinic_photos', 'public');
            }

            Clinic::create([
                'clinic_name' => $request->clinic_name,
                'tests' => json_encode($request->tests),
                'clinic_address' => $request->clinic_address,
                'city' => $request->city,
                'phone_number' => $request->phone_number,
                'email' => $request->email,
                'clinic_photo' => $clinicPhotoPath,
            ]);

            Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'clinic created',
                'message' =>'clinic: '. $request->clinic_name .' created by '. Auth::user()->name  ,
            ]);

            return redirect()->route('clinic2')->with('success', 'Clinic added successfully!');
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }


    public function edit($id)
    {
        try {
            $clinic = Clinic::findOrFail($id);
            return view('backend.clinic.clinic-edit', compact('clinic'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

        public function edit2($id)
    {
        try {
            $clinic = Clinic::findOrFail($id);
            return view('backend.clinic.clinic-edit', compact('clinic'));
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

    public function update(Request $request, $id)
{
    try {
        $request->validate([
            'clinic_name' => 'required|string|max:255',
            'password' => 'nullable|min:6',
            'clinic_address' => 'required|string',
            'city' => 'required|string|max:100',
            'phone_number' => 'required|string|max:20',
            'email' => 'required|email|max:255',
            'clinic_photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
        ]);

        $clinic = Clinic::findOrFail($id);

        // Handle clinic photo update
        if ($request->hasFile('clinic_photo')) {
            if ($clinic->clinic_photo) {
                Storage::delete('public/' . $clinic->clinic_photo);
            }
            $clinicPhotoPath = $request->file('clinic_photo')->store('clinic_photos', 'public');
        } else {
            $clinicPhotoPath = $clinic->clinic_photo;
        }

        // Update clinic details
        $clinic->update([
            'clinic_name' => $request->clinic_name,
            'password' => $request->filled('password') ? bcrypt($request->password) : $clinic->password,
            'clinic_address' => $request->clinic_address,
            'city' => $request->city,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
            'clinic_photo' => $clinicPhotoPath,
        ]);

        // Update related User
        $user = User::where('login_id', $clinic->id)->first();

        if ($user) {
            $user->name = $request->clinic_name;
            $user->email = $request->email;
            if ($request->filled('password')) {
                $user->password = bcrypt($request->password);
            }
            $user->save();
        }

        Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'clinic Updated',
            'message' => 'clinic: ' . $clinic->clinic_name . ' updated by: ' . Auth::user()->name,
        ]);

        return redirect()->route('clinic')->with('success', 'Clinic updated successfully.');
    } catch (Exception $e) {
        Logs::error($e);
        return back()->withErrors('Something went wrong. Please try again.');
    }
}

     public function update2(Request $request, $id)
    {
        try {
            $request->validate([
                'clinic_name' => 'required|string|max:255',
                'tests.*' => 'nullable',
                'clinic_address' => 'required|string',
                'city' => 'required|string|max:100',
                'phone_number' => 'required|string|max:20',
                'email' => 'required|email|max:255',
                'clinic_photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);

            $clinic = Clinic::findOrFail($id);

            if ($request->hasFile('clinic_photo')) {

                if ($clinic->clinic_photo) {
                    Storage::delete('public/' . $clinic->clinic_photo);
                }
                $clinicPhotoPath = $request->file('clinic_photo')->store('clinic_photos', 'public');
            } else {
                $clinicPhotoPath = $clinic->clinic_photo;
            }
            $clinic->update([
                'clinic_name' => $request->clinic_name,
                'tests' => json_encode($request->tests),
                'clinic_address' => $request->clinic_address,
                'city' => $request->city,
                'phone_number' => $request->phone_number,
                'email' => $request->email,
                'clinic_photo' => $clinicPhotoPath,
            ]);

            Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'clinic Updated',
                'message' => 'clinic: '.$clinic->clinic_name .' updated by: '. Auth::user()->name  ,
            ]);

            return redirect()->route('clinic2')->with('success', 'Clinic updated successfully.');
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

    public function destroy($id)
    {
        try {
            $clinic = Clinic::findOrFail($id);
            $clinicName=Clinic::where('id',$id)->first();

            Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'clinic Deleted',
                'message' => 'Clinic: '. $clinicName->clinic_name .' deleted by: '. Auth::user()->name  ,
            ]);

            $clinic->delete();
            
            return redirect()->route('clinic')->with('success', 'Clinic deleted successfully.');
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

       public function destroy2($id)
    {
        try {
            $clinic = Clinic::findOrFail($id);
            $clinicName=Clinic::where('id',$id)->first();

            Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'clinic Deleted',
                'message' => 'Clinic: '. $clinicName->clinic_name .' deleted by: '. Auth::user()->name  ,
            ]);

            $clinic->delete();
            
            return redirect()->route('clinic2')->with('success', 'Clinic deleted successfully.');
        } catch (Exception $e) {
            Logs::error($e);
            return  $e->getMessage() ;
        }
    }

}
