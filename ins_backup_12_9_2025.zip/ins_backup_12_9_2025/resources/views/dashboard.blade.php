<x-admin>
    @section('title','Dashboard')
    <x-dashboard />
</x-admin>
