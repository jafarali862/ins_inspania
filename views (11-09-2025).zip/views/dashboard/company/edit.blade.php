@extends('dashboard.layout.app')
@section('title', 'Edit Company')

@section('content')


<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-edit me-2 text-primary"></i> Edit Company
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('company.list') }}">Company</a></li>
                    <li class="breadcrumb-item active">Edit Company</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-edit me-2"></i>
                            <h5 class="mb-0">Edit Company</h5>
                        </div>
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="{{ route('user.list') }}" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                        </div>
                    </div>
                    <div class="card-body">

                        <!-- Success Message -->
                        @if (session('success'))
                        <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3">
                            <i class="fa fa-check-circle me-2"></i> 
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        @endif

    <!-- <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800 text-center">Edit Company</h1>

        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <div class="card border-0 shadow-lg rounded-lg">
                    <div class="card-header bg-primary text-white border-0 rounded-top">
                        <h6 class="m-0 font-weight-bold">Company Details</h6>
                    </div>
                    <div class="card-body">
                        <div id="successMessage" class="alert alert-success" style="display: none;"></div> -->
                       
                     <form method="POST" action="{{ route('company.update') }}" id="updateCompany" novalidate>
    @csrf
    <input type="hidden" name="id" value="{{ $company->id }}" required>

    <!-- Company Name -->
    <div class="mb-3">
        <label for="name" class="form-label fw-bold">Company Name <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="name" name="name" 
               value="{{ old('name', $company->name) }}" placeholder="Enter company name" required>
        <span class="text-danger error" id="name-error"></span>
    </div>

    <!-- Tabs Card -->
    <div class="card mb-3">
        <div class="card-header p-2">
            <ul class="nav nav-pills" id="insuranceTabs" role="tablist">
                @foreach(['garage', 'driver', 'spot', 'meeting', 'accident'] as $tabId)
                <li class="nav-item" role="presentation">
                    <a class="nav-link {{ $loop->first ? 'active' : '' }}" 
                       id="{{ $tabId }}-tab" 
                       data-bs-toggle="tab" 
                       href="#{{ $tabId }}" 
                       role="tab" 
                       aria-controls="{{ $tabId }}" 
                       aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                       {{ ucfirst($tabId) }} Data
                    </a>
                </li>
                @endforeach
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content" id="insuranceTabsContent">
                @foreach(['garage', 'driver', 'spot', 'meeting', 'accident'] as $tabId)
                <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}" 
                     id="{{ $tabId }}" 
                     role="tabpanel" 
                     aria-labelledby="{{ $tabId }}-tab">
                    <!-- Add your tab content here -->
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <!-- Contact Person -->
    <div class="mb-3">
        <label for="contact_person" class="form-label fw-bold">Contact Person <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="contact_person" name="contact_person" 
               value="{{ old('contact_person', $company->contact_person) }}" 
               placeholder="Enter contact person" required>
        <span class="text-danger error" id="contact_person-error"></span>
    </div>

    <!-- Email -->
    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
        <input type="email" class="form-control" id="email" name="email" 
               value="{{ old('email', $company->email) }}" 
               placeholder="Enter email address" required>
        <span class="text-danger error" id="email-error"></span>
    </div>

    <!-- Phone -->
    <div class="mb-3">
        <label for="phone" class="form-label fw-bold">Phone Number <span class="text-danger">*</span></label>
        <input type="tel" class="form-control" id="phone" name="phone" 
               value="{{ old('phone', $company->phone) }}" 
               placeholder="Enter phone number" required>
        <span class="text-danger error" id="phone-error"></span>
    </div>

    <!-- Address -->
    <div class="mb-3">
        <label for="address" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
        <textarea class="form-control" id="address" name="address" rows="3" 
                  placeholder="Enter address" required>{{ old('address', $company->address) }}</textarea>
        <span class="text-danger error" id="address-error"></span>
    </div>

    <!-- Status -->
    <div class="mb-3">
        <label for="status" class="form-label fw-bold">Status <span class="text-danger">*</span></label>
        <select class="form-select" id="status" name="status" required>
            <option value="1" {{ old('status', $company->status) == '1' ? 'selected' : '' }}>Active</option>
            <option value="0" {{ old('status', $company->status) == '0' ? 'selected' : '' }}>Inactive</option>
        </select>
        <span class="text-danger error" id="status-error"></span>
    </div>

    <!-- Template Selection -->
    <div class="mb-3">
        <label for="selectTemplate" class="form-label fw-bold">Select Final Report Template <span class="text-danger">*</span></label>
        <select class="form-select" id="selectTemplate" name="template" required>
            <option value="" disabled {{ empty($company->template) ? 'selected' : '' }}>Please select</option>
            @for ($i = 1; $i <= 9; $i++)
                <option value="{{ $i }}" {{ $company->template == $i ? 'selected' : '' }}>
                    {{ $i == 9 ? 'Default Template' : 'Template ' . $i }}
                </option>
            @endfor
        </select>
        <span class="text-danger error" id="template-error"></span>
    </div>

    <!-- Submit Buttons -->
    <div class="d-flex justify-content-between">
        <button type="submit" class="btn btn-primary">Update Company</button>
        <a href="{{ route('company.list') }}" class="btn btn-secondary">Cancel</a>
    </div>
</form>


                </div>
            </div>
        </div>
    </div>
</div>

<style>
  .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active
 {
    color: #ffffff;
    background-color: #6c6c6c;
    border-color: #dee2e6 #dee2e6 #fff;
}
</style>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

   <script>
// Pass existing selections from backend
window.existingSelections = @json($questionnaires || {});

const categoryMap = {
    garage: 'garage_data',
    driver: 'driver_data',
    spot: 'spot_data',
    meeting: 'owner_data',
    accident: 'accident_person_data',
};

document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('#insuranceTabs .nav-link');

    tabs.forEach(tab => {
        const target = tab.getAttribute('data-bs-target') || tab.getAttribute('href');
        if (!target) return;
        const tabId = target.startsWith('#') ? target.substring(1) : target;
        const dataCategory = categoryMap[tabId];
        const tabPane = document.getElementById(tabId);

        if (!tabPane) {
            console.warn(`Tab pane with id '${tabId}' not found in markup.`);
            return;
        }

        // If tab is active initially (on page load), load its questions
        if (tab.classList.contains('active')) {
            loadTabQuestions(tabId, dataCategory);
        }

        // Listen for Bootstrap 5 tab shown event
        tab.addEventListener('shown.bs.tab', () => {
            loadTabQuestions(tabId, dataCategory);
        });
    });
});

async function loadTabQuestions(tabId, dataCategory) {
    const tabPane = document.getElementById(tabId);
    if (!tabPane) {
        console.error(`Tab pane with id '${tabId}' missing.`);
        return;
    }

    if (tabPane.dataset.loaded === 'true') {
        console.log(`Tab '${tabId}' already loaded, skipping fetch.`);
        return;
    }

    try {
        console.log(`Fetching questions for category '${dataCategory}'.`);
        const response = await fetch(`/questions/${dataCategory}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const questions = await response.json();
        console.log('Questions fetched:', questions);

        // Build HTML
        let html = `<h5 class="mb-3">${dataCategory.replace(/_/g, ' ').toUpperCase()}</h5>`;
        questions.forEach(q => {
            // Check if q.column_name is in existingSelections
            const existingForTab = (window.existingSelections[tabId] || {});
            const checked = existingForTab[q.column_name] ? 'checked' : '';

            const colId = `check_${tabId}_${q.column_name}`;
            let fileTypeInput = '';
            if (q.input_type === 'file' && q.file_type) {
                fileTypeInput = `<input type="hidden" name="file_types[${tabId}][${q.column_name}]" value="${q.file_type}">`;
            }

            html += `
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox"
                        name="selected_questions[${tabId}][]"
                        value="${q.column_name}"
                        id="${colId}" ${checked}>

                    <input type="hidden"
                        name="question_types[${tabId}][${q.column_name}]"
                        value="${q.input_type}">

                    ${fileTypeInput}

                    <label class="form-check-label" for="${colId}">
                        ${q.question}
                    </label>
                </div>`;
        });

        tabPane.innerHTML = html;
        tabPane.dataset.loaded = 'true';
    } catch (err) {
        tabPane.innerHTML = `<div class="alert alert-danger">Could not load questions. ${err.message}</div>`;
        console.error('Error in loadTabQuestions:', err);
    }
}
</script>






<script>
  $(document).ready(function() {
    $('#updateCompany').on('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: '{{ route('company.update') }}',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                $('#successMessage')
                    .text(response.success)
                    .removeClass('d-none')
                    .fadeIn();

                $('html, body').animate({ scrollTop: 0 }, 'fast');

                $('.text-danger').text('');

                // Reload after 3 seconds (3000 milliseconds)
                // setTimeout(function() {
                //     location.reload();
                // }, 3000);

                setTimeout(function() {
                // Redirect to the URL sent from backend
                window.location.href = response.redirect_url;
                }, 3000);
                
            },
            error: function(xhr) {
                var errors = xhr.responseJSON.errors;
                $('.text-danger').text('');
                $.each(errors, function(key, value) {
                    $('#' + key + '-error').text(value[0]);
                });
            }
        });
    });
});

</script>

@endsection
