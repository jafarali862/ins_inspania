@extends('dashboard.layout.app')
@section('title', 'Company List')



@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-building me-2 text-primary"></i> Company List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Companies</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('company.create') }}" class="btn btn-primary">
                <i class="fa-solid fa-building-circle-plus me-1"></i> Add Company
            </a>
        </div>

        <!-- Card -->
   <div class="card shadow-sm border-0">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Companies</h5>
        <!-- <small class="text-white-500">Total: {{ $companies->count() }}</small> -->
    </div>

    <div class="card-body p-0">
        @if($companies->isEmpty())
            <div class="p-4 text-center text-muted fst-italic">
                No companies found.
            </div>
        @else
            <!-- Add padding and margin-bottom here -->
            <div class="table-responsive p-3 mb-3">
                <table id="companyTable" class="table table-striped table-hover mb-0 text-center align-middle" style="width:100%">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Company Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Template</th>
                            <th>Status</th>
                            <th style="width: 120px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($companies as $index => $company)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $company->name }}</td>
                                <td>{{ $company->email }}</td>
                                <td>{{ $company->phone }}</td>
                                <td>{{ $company->template ? "Template {$company->template}" : 'Default Template' }}</td>
                                <td>
                                    @if ($company->status == 1)
                                        <span class="badge bg-success">Active</span>
                                    @else
                                        <span class="badge bg-danger">Inactive</span>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('companies.edit', $company->id) }}" class="btn btn-sm btn-info" title="Edit">
                                        <i class="fa-solid fa-edit"></i>
                                    </a>

                                    <form action="{{ route('companies.destroy', $company->id) }}" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure you want to delete this company?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>



    <!-- jQuery and DataTables JS -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">





<style>
@media (max-width: 576px) {
    /* Hide only the Action column header */
    #companyTable th:nth-child(7) {
        display: none !important;
    }

    /* Hide only the "Action" title in responsive child rows, keep the data visible */
    li[data-dtr-index="6"] > span.dtr-title {
        display: none !important;
    }
}



</style>

  <script>
    $(document).ready(function () {
        const table = $('#companyTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search companies..."
                },
                columnDefs: [
                    { orderable: false, targets: [6] } // Disable sorting on the "Action" column
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }
    });
</script>

@endsection

