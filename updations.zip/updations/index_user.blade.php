@extends('dashboard.layout.app')
@section('title', 'User List')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-users me-2 text-primary"></i> User List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Users</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('user.create') }}" class="btn btn-primary">
                <i class="fa-solid fa-user-plus me-1"></i> Add User
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fa-solid fa-users me-2"></i> Manage Users</h5>
               <form id="statusForm" method="GET" class="d-flex align-items-center gap-3 mb-0">
    <div class="form-check form-check-inline">
        <input class="form-check-input" 
               type="radio" 
               name="status" 
               id="statusActive" 
               value="1"
               {{ ($status == 1) ? 'checked' : '' }}>
        <label class="form-check-label text-white" for="statusActive">Active</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" 
               type="radio" 
               name="status" 
               id="statusInactive" 
               value="0"
               {{ ($status === 0) ? 'checked' : '' }}>
        <label class="form-check-label text-white" for="statusInactive">Inactive</label>
    </div>
</form>

            </div>

            <div class="card-body">
                @if($users->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered align-middle" id="userTable">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>IMEI</th>
                                    <th>Status</th>
                                    <th style="width: 100px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($users as $index => $user)
                                    <tr>
                                        <td>{{ $users->firstItem() + $index }}</td>
                                        <td>{{ $user->name }}</td>
                                        <td>{{ $user->email }}</td>
                                        <td>
                                            @if($user->role == 2)
                                                <span class="badge bg-info">Sub Admin</span>
                                            @elseif($user->role == 3)
                                                <span class="badge bg-secondary">Executive</span>
                                            @else
                                                <span class="badge bg-dark">N/A</span>
                                            @endif
                                        </td>
                                        <td>{{ $user->imei ?? '-' }}</td>
                                        <td>
                                            @if ($user->status == 1)
                                                <span class="badge bg-success">Active</span>
                                            @else
                                                <span class="badge bg-danger">Inactive</span>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            <a href="{{ route('user.edit', $user->id) }}"
                                               class="btn btn-sm btn-outline-primary"
                                               title="Edit User">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="alert alert-warning mb-0 text-center">
                        <i class="fa-solid fa-circle-exclamation me-1"></i> No users found.
                    </div>
                @endif
            </div>

            <!-- Pagination -->
           
        </div>
    </div>
</div>

<!-- DataTables CSS (Bootstrap 5 theme) -->


<!-- jQuery (needed for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<style>
@media (max-width: 576px) {
    /* Hide only the Action column header */
    #userTable th:nth-child(7) {
        display: none !important;
    }

    /* Hide only the "Action" title in responsive child rows, keep the data visible */
    li[data-dtr-index="6"] > span.dtr-title {
        display: none !important;
    }
}



</style>
<script>
    $(document).ready(function () {
        const table = $('#userTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search users..."
                },
                columnDefs: [
                    { orderable: false, targets: [6] } // Disable sort on "Action" column
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }

        // Status filter submit
        $('#statusActive, #statusInactive').on('change', function () {
            $('#statusForm').submit();
        });
    });
</script>
@endsection
