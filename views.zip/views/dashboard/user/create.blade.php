@extends('dashboard.layout.app')
@section('title', 'Add User')

@section('content')

    <div class="row mb-3">
        <div class="col-md-12 d-flex justify-content-end gap-2">
            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                <i class="fa fa-arrow-left"></i> Back
            </a>
            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                <i class="fa fa-sync"></i> Reload
            </a>
            <a href="{{ route('user.list') }}" class="btn btn-primary btn-sm">
                <i class="fa fa-users"></i> User List
            </a>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="ibox">
                <div class="ibox-title bg-primary text-white" style="padding: 15px 20px; margin-bottom: 15px;">
    <h5><i class="fa fa-user-plus mr-2"></i> Add User</h5>
</div>

                <div class="ibox-content">
                    <div id="successMessage" class="alert alert-success d-none"></div>

                    <form id="addUser" action="{{ route('user.store') }}" method="POST" novalidate>
                        @csrf

                        <div class="form-group mb-3">
                            <label for="name" class="font-weight-bold">Name <span class="text-danger">*</span></label>
                            <input type="text" 
                                   class="form-control @error('name') is-invalid @enderror" 
                                   id="name" 
                                   name="name" 
                                   placeholder="Enter name" 
                                   required>
                            <x-error name="name" />
                        </div>

                        <div class="form-group mb-3">
                            <label for="email" class="font-weight-bold">Email Address <span class="text-danger">*</span></label>
                            <input type="email" 
                                   class="form-control @error('email') is-invalid @enderror" 
                                   id="email" 
                                   name="email" 
                                   placeholder="Enter email" 
                                   required>
                            <x-error name="email" />
                        </div>

                        <div class="form-group mb-3">
                            <label for="contact_number" class="font-weight-bold">Contact Number <span class="text-danger">*</span></label>
                            <input type="text" 
                                   class="form-control @error('phone') is-invalid @enderror" 
                                   id="contact_number" 
                                   name="phone" 
                                   placeholder="Enter contact number" 
                                   required>
                            <x-error name="contact_number" />
                        </div>

                        <div class="form-group mb-3">
                            <label for="place" class="font-weight-bold">Place <span class="text-danger">*</span></label>
                            <input type="text" 
                                   class="form-control @error('place') is-invalid @enderror" 
                                   id="place" 
                                   name="place" 
                                   placeholder="Enter place" 
                                   required>
                            <x-error name="place" />
                        </div>

                        <div class="form-group mb-3">
                            <label for="role" class="font-weight-bold">Role <span class="text-danger">*</span></label>
                            <select id="role" 
                                    name="role" 
                                    class="form-control @error('role') is-invalid @enderror" 
                                    required>
                                <option value="" disabled selected>Select user role</option>
                                <option value="3">Executive</option>
                                <option value="2">Sub Admin</option>
                            </select>
                            <x-error name="role" />
                        </div>

                        <div class="form-group mb-4">
                            <label for="password" class="font-weight-bold">Password <span class="text-danger">*</span></label>
                            <input type="password" 
                                   class="form-control @error('password') is-invalid @enderror" 
                                   id="password" 
                                   name="password" 
                                   required>
                            <x-error name="password" />
                        </div>

                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save mr-1"></i> Add User
                            </button>
                        </div>
                    </form>
                </div> <!-- /.ibox-content -->
            </div> <!-- /.ibox -->
        </div>
    </div>
</div>





<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function () {
        $('#addUser').on('submit', function (e) {
            e.preventDefault();

            $.ajax({
                url: '{{ route('user.store') }}',
                type: 'POST',
                data: $(this).serialize(),
                success: function (response) {
                    if (response.success) {
                        // Show success message
                        $('#successMessage')
                            .text(response.success)
                            .fadeIn()
                            .removeClass('d-none')
                            .addClass('alert alert-success');

                        // Reset the form and remove previous errors
                        $('#addUser')[0].reset();
                        $('.form-control').removeClass('is-invalid');
                        $('.error').text('').hide();

                        // Delay redirect so the message is visible for 2.5 seconds
                        setTimeout(function () {
                            window.location.href = response.redirect_url;
                        }, 2500);
                    }
                },
                error: function (xhr) {
                    var errors = xhr.responseJSON.errors;
                    $('.error').text('').hide();
                    $('.form-control').removeClass('is-invalid');

                    $.each(errors, function (key, value) {
                        $('#' + key + '-error').text(value).show();
                        $('#' + key).addClass('is-invalid');
                    });
                }
            });
        });
    });
</script>

@endsection
