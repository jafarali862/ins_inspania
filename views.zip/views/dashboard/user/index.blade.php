@extends('dashboard.layout.app')
@section('title', 'User List')

@section('content')

<!-- Page Heading -->
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>User List</h2>
    </div>
    <div class="col-lg-4 text-right">
        <button class="btn btn-danger btn-sm" onclick="window.history.back()" title="Back">
            <i class="fa fa-arrow-left"></i>
        </button>
        <button class="btn btn-warning btn-sm ml-1" onclick="window.location.reload()" title="Reload">
            <i class="fa fa-sync"></i>
        </button>
        <a href="{{ route('user.create') }}" class="btn btn-primary btn-sm ml-1" title="Add User">
            <i class="fa fa-user-plus"></i>
        </a>
    </div>
</div>

<!-- Content -->
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox">
                <div class="ibox-title d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">User List</h5>
                    <form id="statusForm" method="GET" class="form-inline">
                        <label class="mr-2">Filter:</label>
                        <div class="radio radio-info radio-inline">
                            <input type="radio" name="status" id="statusActive" value="1" {{ ($status == 1) ? 'checked' : '' }}>
                            <label for="statusActive">Active</label>
                        </div>
                        <div class="radio radio-info radio-inline ml-3">
                            <input type="radio" name="status" id="statusInactive" value="0" {{ ($status === 0) ? 'checked' : '' }}>
                            <label for="statusInactive">Inactive</label>
                        </div>
                    </form>
                </div>

                <div class="ibox-content">
                    @if($users->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover dataTables-example" id="userTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>IMEI</th>
                                        <th>Status</th>
                                        <th style="width: 100px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($users as $index => $user)
                                    <tr>
                                        <td>{{ $users->firstItem() + $index }}</td>
                                        <td>{{ $user->name }}</td>
                                        <td>{{ $user->email }}</td>
                                        <td>
                                            @if($user->role == 2)
                                                Sub Admin
                                            @elseif($user->role == 3)
                                                Executive
                                            @else
                                                N/A
                                            @endif
                                        </td>
                                        <td>{{ $user->imei ?? '-' }}</td>
                                        <td>
                                            @if ($user->status == 1)
                                                <span class="label label-success">Active</span>
                                            @else
                                                <span class="label label-danger">Inactive</span>
                                            @endif
                                        </td>
                                        <td>
    <a href="{{ route('user.edit', $user->id) }}" class="btn btn-sm btn-primary" title="Edit User">
        <i class="fa fa-edit"></i> Edit
    </a>
</td>

                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="alert alert-warning m-t-md">No users found.</div>
                    @endif

                    <!-- Pagination -->
                    <div class="text-center m-t-md">
                        {{ $users->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

{{-- Inspinia DataTables Scripts --}}
@push('styles')
    <link href="{{ asset('assets/plugins/datatables/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/plugins/datatables/responsive.bootstrap4.min.css') }}" rel="stylesheet">
@endpush

@push('scripts')
    <script src="{{ asset('assets/plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/responsive.bootstrap4.min.js') }}"></script>

    <script>
        $(document).ready(function () {
            $('#userTable').DataTable({
                responsive: true,
                pageLength: 10,
                dom: '<"html5buttons"B>lTfgitp',
                language: {
                    paginate: {
                        previous: "<i class='fa fa-angle-left'></i>",
                        next: "<i class='fa fa-angle-right'></i>"
                    }
                }
            });

            $('input[name="status"]').on('change', function () {
                $('#statusForm').submit();
            });
        });
    </script>
@endpush
