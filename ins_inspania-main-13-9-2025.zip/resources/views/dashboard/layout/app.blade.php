<?php
$user = Auth::user();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>INSURANCE - @yield('title')</title>

    <link rel="shortcut icon" href="{{ asset('img/icon.png') }}" type="image/x-icon">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback" rel="stylesheet">

    <!-- Vendor css -->
    <link href="{{ asset('assets/css/vendors.min.css') }}" rel="stylesheet" type="text/css">

    <!-- App css -->
    <link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{ asset('assets/plugins/jsvectormap/jsvectormap.min.css') }}">


     <link href="{{ asset('assets/plugins/datatables/dataTables.bootstrap5.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/plugins/datatables/responsive.bootstrap5.min.css') }}" rel="stylesheet">

    <!-- Additional CSS for your app -->
    @stack('styles')
</head>

<body>

<div id="wrapper">

    <!-- Sidebar -->
    @if ($user->role == 1)
        @include('dashboard.include.sidebar')
    @elseif ($user->role == 2)
        @include('dashboard.include.sub-admin-sidebar')
    @elseif ($user->role == 3)
        @include('dashboard.include.executive-sidebar')
    @endif
    <!-- /Sidebar -->

    <!-- Page wrapper -->
    <div id="page-wrapper" class="gray-bg">

        <!-- Navbar -->
        @include('dashboard.include.navbar')
        <!-- /Navbar -->

        <!-- Page header (optional) -->
        {{-- Uncomment if needed --}}
        {{-- 
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-12">
                @yield('page-header')
            </div>
        </div>
        --}}

        <!-- Main content -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                @yield('content')
            </div>
        </div>
        <!-- /Main content -->

        <!-- Footer -->
        @include('dashboard.include.footer')

    </div>
    <!-- /Page wrapper -->

</div>
<!-- /#wrapper -->

<!-- Logout Modal -->
@include('dashboard.include.logout')

<!-- Scripts -->
<script src="{{ asset('assets/js/config.js') }}"></script>
<script src="{{ asset('assets/js/vendors.min.js') }}"></script>
<script src="{{ asset('assets/js/app.js') }}"></script>

<!-- Plugins -->
<script src="{{ asset('assets/plugins/echarts/echarts.min.js') }}"></script>
<script src="{{ asset('assets/plugins/jsvectormap/jsvectormap.min.js') }}"></script>
<script src="{{ asset('assets/js/maps/world.js') }}"></script>

<!-- Custom -->
<script src="{{ asset('assets/js/pages/custom-table.js') }}"></script>
<script src="{{ asset('assets/js/pages/dashboard-2.js') }}"></script>

  <script src="{{ asset('assets/plugins/datatables/dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/dataTables.bootstrap5.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/responsive.bootstrap5.min.js') }}"></script>
<!-- Bootstrap 5 JS Bundle (includes Popper) -->
<!-- Bootstrap 5 JS (Make sure it’s included) -->



@stack('scripts')
@yield('scripts')

<script>
    // Scroll to Top Button
    var mybutton = document.getElementById("scrollToTopBtn");
    if(mybutton){
        window.onscroll = function () {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        };

        mybutton.onclick = function (e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        };
    }
</script>

</body>
</html>
