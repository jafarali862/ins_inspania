@extends('dashboard.layout.app')
@section('title', 'Edit User')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-edit me-2 text-primary"></i> Edit User
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('user.list') }}">Users</a></li>
                    <li class="breadcrumb-item active">Edit User</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-edit me-2"></i>
                            <h5 class="mb-0">Edit User</h5>

                             <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
        style="margin-left: 20px;align-items: center;">
        <i class="fa fa-check-circle me-2"></i>
        <span id="successText"></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
        
                        </div>
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="{{ route('user.list') }}" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                        </div>
                    </div>
                    <div class="card-body">

                      

                        <!-- Edit User Form -->
                        <form id="updateUser" action="{{ route('user.update') }}" method="POST" novalidate>
                            @csrf
                            <input type="hidden" name="id" value="{{ $user->id }}">

                            <!-- Name -->
                            <div class="mb-3">
                                <label for="name" class="form-label fw-bold">Name <span class="text-danger">*</span></label>
                                <input type="text" id="name" name="name" 
                                       class="form-control" 
                                       value="{{ old('name', $user->name) }}" 
                                       placeholder="Enter name" required>
                                <span class="text-danger error" id="name-error"></span>
                            </div>

                            <!-- Phone -->
                            <div class="mb-3">
                                <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                                <input type="tel" id="phone" name="phone" 
                                       class="form-control" 
                                       value="{{ old('phone', $user->phone) }}" 
                                       placeholder="Enter phone" required>
                                <span class="text-danger error" id="phone-error"></span>
                            </div>

                            <!-- Email -->
                            <div class="mb-3">
                                <label for="email" class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                                <input type="email" id="email" name="email" 
                                       class="form-control" 
                                       value="{{ old('email', $user->email) }}" 
                                       placeholder="Enter email" required>
                                <span class="text-danger error" id="email-error"></span>
                            </div>


                            <!-- Place -->
                        <div class="mb-3">
                        <label for="place" class="form-label fw-bold">Place <span class="text-danger">*</span></label>
                        <input type="text" 
                        class="form-control" 
                        id="place" 
                        name="place" 
                        value="{{ old('place', $user->place) }}"
                        placeholder="Enter place" 
                        required>
                         <span class="text-danger error" id="place-error"></span>
                        </div>


                            <!-- Role -->
                            <div class="mb-3">
                                <label for="role" class="form-label fw-bold">Role <span class="text-danger">*</span></label>
                                <select id="role" name="role" class="form-select" required>
                                    <option value="2" {{ old('role', $user->role) == 2 ? 'selected' : '' }}>Sub Admin</option>
                                    <option value="3" {{ old('role', $user->role) == 3 ? 'selected' : '' }}>Executive</option>
                                </select>
                            </div>

                            <!-- Status -->
                            <div class="mb-3">
                                <label for="status2" class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                                <select id="status2" name="status2" class="form-select" required>
                                    <option value="1" {{ old('status2', $user->status) == 1 ? 'selected' : '' }}>Active</option>
                                    <option value="0" {{ old('status2', $user->status) == 0 ? 'selected' : '' }}>Inactive</option>
                                </select>
                            </div>

                            <!-- Password -->
                            <div class="mb-3">
                                <label for="password" class="form-label fw-bold">Password</label>
                                <input type="password" id="password" name="password" 
                                       class="form-control" placeholder="Leave blank to keep current password">
                                <span class="text-danger error" id="password-error"></span>
                            </div>

                            <!-- Buttons -->
                            <div class="d-flex justify-content-between">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-save me-1"></i> Update User
                                </button>
                                <a href="{{ route('user.list') }}" class="btn btn-secondary">
                                    <i class="fa fa-times me-1"></i> Cancel
                                </a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    $(function() {
        $('#updateUser').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: '{{ route('user.update') }}',
                method: 'POST',
                data: $(this).serialize(),
                success: function(response) {
            
            if (response.success) {
            $('#successMessage')
            .removeClass('d-none alert-danger')
            .addClass('alert alert-success')
            .fadeIn();
            $('#successText').text(response.success);
            $('html, body').animate({
            scrollTop: $("#successMessage").offset().top - 100
            }, 500);
            // Reset form
            $('#updateUser')[0].reset();
            $('.form-control').removeClass('is-invalid');
            $('.error').text('');

            setTimeout(function () {
            window.location.href = response.redirect_url;
            }, 2500);
            }
            },
                error: function(xhr) {
                    var errors = xhr.responseJSON.errors;
                    $('.text-danger').text('');
                    $.each(errors, function(key, val) {
                        $('#' + key + '-error').text(val);
                    });
                }
            });
        });
    });
</script>
@endsection
