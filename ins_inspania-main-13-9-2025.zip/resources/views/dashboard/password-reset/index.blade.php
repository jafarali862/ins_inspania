@extends('dashboard.layout.app')
@section('title', 'Password Reset List')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-building me-2 text-primary"></i> Pending Password Reset
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item">
                        <a href="{{ route('dashboard') }}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Pending Password Reset</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-rotate me-1"></i> Reload
            </button>
            <a href="{{ route('all.password.reset.request') }}" class="btn btn-primary">
                <i class="fas fa-list-ul me-1"></i> Show All Requests
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Pending Password Reset List</h5>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                  <table id="passwordResetTable" class="table table-bordered table-striped align-middle text-center">
    <thead class="table-dark">
        <tr>
            <th>S.No</th>
            <th>Name</th>
            <th>Request Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($requests as $index => $request)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $request->user_name }}</td>
                <td>{{ \Carbon\Carbon::parse($request->request_date)->format('d M, Y H:i') }}</td>
                <td>
                    <a href="{{ route('password.reset.edit', $request->id) }}" class="btn btn-sm btn-primary" title="Edit Request">
                        <i class="fas fa-pencil-alt"></i>
                    </a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>

                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">



    <script>
         $(document).ready(function () {
        $('#passwordResetTable').DataTable({
            pageLength: 10,
            responsive: true,
            autoWidth: false,
            language: {
                emptyTable: "No pending reset requests available.",
                search: "_INPUT_",
                searchPlaceholder: "Search requests..."
            },
            dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
        });
    });
    </script>

@endsection
