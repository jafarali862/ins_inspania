@extends('dashboard.layout.app')
@section('title', 'Edit Templates')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-edit me-2 text-primary"></i> Edit Template
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('templates.list_templates') }}">Templates</a></li>
                    <li class="breadcrumb-item active">Edit Templates</li>
                </ol>
            </div>
        </div>

             <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-question-circle me-2"></i>
                            <h5 class="mb-0">Edit Templates</h5>

                            <!-- Success Message -->
                                <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
style="margin-left: 20px;align-items: center;">
<i class="fa fa-check-circle me-2"></i>
<span id="successText"></span>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:location.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                       <form method="POST" action="{{ route('templates.update_templates', $template->id) }}" id="tempform">
    @csrf
    {{-- @method('PUT') --}}


    <!-- Nav Tabs -->
    <ul class="nav nav-tabs" id="questionTabs" role="tablist">
        @foreach($questions as $category => $group)
            <li class="nav-item" role="presentation">
                <button class="nav-link {{ $loop->first ? 'active' : '' }}"
                        id="{{ $category }}-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#{{ $category }}"
                        type="button"
                        role="tab"
                        aria-controls="{{ $category }}"
                        aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                    {{ ucfirst(str_replace('_', ' ', $category)) }}
                </button>
            </li>
        @endforeach
    </ul>

    <!-- Tab Content -->
    <div class="tab-content mt-3" id="questionTabsContent">
        @foreach($questions as $category => $group)
            <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}"
                 id="{{ $category }}"
                 role="tabpanel"
                 aria-labelledby="{{ $category }}-tab">

                <div class="row">
                    @foreach($group as $question)
                        <div class="col-md-6 mb-2">
                            <div class="form-check">
                                <input class="form-check-input"
                                       type="checkbox"
                                       style="border-color: #424141;"
                                       name="questions[]"
                                       value="{{ $question->id }}"
                                       id="q{{ $question->id }}"
                                       {{ in_array($question->id, $template->questions->pluck('id')->toArray()) ? 'checked' : '' }}>
                                <label class="form-check-label" for="q{{ $question->id }}">
                                    {{ $question->question }}
                                </label>
                            </div>
                        </div>
                    @endforeach
                </div>

            </div>
        @endforeach
    </div>

    <div class="mt-4">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-save me-1"></i> Update Template
        </button>
        <a href="{{ route('templates.list_templates') }}" class="btn btn-secondary">
            <i class="fa fa-times me-1"></i> Cancel
        </a>
    </div>
</form>

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div>
        </div>
    </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <script>

   $(document).ready(function() {
    $('#tempform').on('submit', function(e) {
        e.preventDefault();
        $('.text-danger').text('');
        $('#successText').text('');
        $('#successMessage').addClass('d-none');

        const form = $(this);
        const actionUrl = form.attr('action');

        $.ajax({
            url: actionUrl,
            type: 'POST',
            data: form.serialize(),
            success: function(response) {
                if (response.success) {
                    $('#successText').text(response.success);
                    $('#successMessage')
                        .removeClass('d-none alert-danger')
                        .addClass('alert alert-success')
                        .fadeIn();

                    $('html, body').animate({
                        scrollTop: $("#successMessage").offset().top - 100
                    }, 500);

                    // Reset form
                    $('#tempform')[0].reset();
                    $('.form-control').removeClass('is-invalid');
                    $('.error').text('');

                    setTimeout(function () {
                        window.location.href = response.redirect_url;
                    }, 2500);
                }
            },

            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(field, messages) {
                        $('#' + field + '-error').text(messages[0]);
                    });
                } else {
                    alert('An unexpected error occurred.');
                }
            }
        });
    });
});

    </script>
  @endsection
