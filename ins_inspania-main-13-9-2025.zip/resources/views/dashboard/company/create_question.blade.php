@extends('dashboard.layout.app')
@section('title', 'Add Questionnaire')

@push('styles')
    <!-- Optional: AdminLTE custom styles can go here -->
@endpush

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-plus me-2 text-primary"></i> Add Question
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('company.list') }}">Questions</a></li>
                    <li class="breadcrumb-item active">Add Question</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-plus me-2"></i>
                            <h5 class="mb-0">Add Question</h5>
                            

<div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
style="margin-left: 20px;align-items: center;">
<i class="fa fa-check-circle me-2"></i>
<span id="successText"></span>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
                        </div>



                        
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                           
                        </div>
                    </div>
                    <div class="card-body">
                   
                    <form action="{{ route('companies.store_question') }}" method="POST" id="companyForm" novalidate>
    @csrf

    <!-- Question Field -->
    <div class="mb-3">
        <label for="question" class="form-label fw-bold">Question <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="question" name="question" placeholder="Enter question" required>
        <span id="question-error" class="text-danger error"></span>
    </div>

    <!-- Input Type -->
    <div class="mb-3">
        <label for="input_type" class="form-label fw-bold">Input Type <span class="text-danger">*</span></label>
        <select class="form-control" id="input_type" name="input_type" required>
            <option value="" disabled selected>Select Type</option>
            <option value="text">Text</option>
            <option value="textarea">Textarea</option>
            <option value="select">Select</option>
            <option value="file">File</option>
            <option value="date">Date</option>
        </select>
        <span id="input_type-error" class="text-danger error"></span>
    </div>

    <!-- File Type (Conditional) -->
    <div class="mb-3" id="fileTypeContainer" style="display: none;">
        <label for="file_type" class="form-label fw-bold">File Type <span class="text-danger">*</span></label>
        <select class="form-control" id="file_type" name="file_type">
            <option value="" disabled selected>Select File Type</option>
            <option value="image">Image</option>
            <option value="audio">Audio</option>
        </select>
        <span id="file_type-error" class="text-danger error"></span>
    </div>

    <!-- Data Category -->
    <div class="mb-3">
        <label for="data_category" class="form-label fw-bold">Data Category <span class="text-danger">*</span></label>
        <select class="form-control" id="data_category" name="data_category" required>
            <option value="" disabled selected>Select Data Category</option>
            <option value="garage_data">Garage Data</option>
            <option value="spot_data">Spot Data</option>
            <option value="owner_data">Owner Data</option>
            <option value="driver_data">Driver Data</option>
            <option value="accident_person_data">Accident Person Data</option>
        </select>
        <span id="data_category-error" class="text-danger error"></span>
    </div>

    <!-- Submit Button -->
    <button type="submit" class="btn btn-primary">
        <i class="fas fa-plus-circle me-1"></i> Add Question
    </button>
</form>

                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
  $(document).ready(function () {
    // Set CSRF token for AJAX
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    // Handle form submission
    $('#companyForm').on('submit', function (e) {
        e.preventDefault();

        $.ajax({
            url: '{{ route('companies.store_question') }}',
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                if (response.success) {
                    // Show success message
                    $('#successMessage')
                        .removeClass('d-none alert-danger')
                        .addClass('alert-success')
                        .fadeIn();
                    
                    $('#successText').text(response.success);

                    // Scroll to success message
                    $('html, body').animate({
                        scrollTop: $('#successMessage').offset().top - 120
                    }, 500);

                    // Reset the form and clear error states
                    $('#companyForm')[0].reset();
                    $('.form-control').removeClass('is-invalid');
                    $('.error').text('');

                    // Redirect after a short delay
                    setTimeout(function () {
                        window.location.href = response.redirect_url;
                    }, 2500);
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    const errors = xhr.responseJSON.errors;

                    // Reset previous errors
                    $('.error').text('');
                    $('.form-control').removeClass('is-invalid');

                    // Show new errors
                    $.each(errors, function (key, value) {
                        const input = $('#' + key);
                        input.addClass('is-invalid');

                        // Update the error text
                        $('#' + key + '-error').text(value[0]);
                    });
                } else {
                    // General error (optional handling)
                    $('#successMessage')
                        .removeClass('d-none alert-success')
                        .addClass('alert-danger')
                        .fadeIn()
                        .html('<i class="fa fa-exclamation-circle me-2"></i> Something went wrong. Please try again.');
                }
            }
        });
    });

    // Handle conditional file type visibility
    $('#input_type').on('change', function () {
        const fileTypeContainer = $('#fileTypeContainer');
        if ($(this).val() === 'file') {
            fileTypeContainer.show();
            $('#file_type').attr('required', 'required');
        } else {
            fileTypeContainer.hide();
            $('#file_type').removeAttr('required');
            $('#file_type-error').text('');
        }
    });
});

</script>
@endsection
