@extends('dashboard.layout.app')
@section('title', 'Edit User')

@section('content')
  <div class="content-page">
    <div class="container-fluid">

        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-edit me-2 text-primary"></i> Edit Compnay Info
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>

        <!-- Template Edit Form -->
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Update Compnay Info</h5>
                    </div>

                    <div class="card-body">
                        
                        
                    <form action="{{ route('logo.update', $logo->id) }}" method="POST" enctype="multipart/form-data" id="updateUser">
    @csrf
    @method('PUT')

    <div class="mb-3">
        <label for="name" class="form-label fw-bold">Company Name <span class="text-danger">*</span></label>
        <input type="text"
               class="form-control"
               id="name"
               name="name"
               value="{{ old('name', $logo->name) }}"
               placeholder="Enter company name"
               required>
        <span class="text-danger error" id="name-error"></span>
    </div>

    <div class="mb-3">
        <label for="phone" class="form-label fw-bold">Company Phone <span class="text-danger">*</span></label>
        <input type="tel"
               class="form-control"
               id="phone"
               name="phone"
               value="{{ old('phone', $logo->phone) }}"
               placeholder="Enter phone number"
               required>
        <span class="text-danger error" id="phone-error"></span>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Company Email <span class="text-danger">*</span></label>
        <input type="email"
               class="form-control"
               id="email"
               name="email"
               value="{{ old('email', $logo->email) }}"
               placeholder="Enter email"
               required>
        <span class="text-danger error" id="email-error"></span>
    </div>

    <div class="mb-3">
        <label for="place" class="form-label fw-bold">Place <span class="text-danger">*</span></label>
        <input type="text"
               class="form-control"
               id="place"
               name="place"
               value="{{ old('place', $logo->place) }}"
               placeholder="Enter company location"
               required>
        <span class="text-danger error" id="place-error"></span>
    </div>

    <div class="mb-3">
        <label for="logo" class="form-label fw-bold">Select Logo <span class="text-danger">*</span></label>
        <input type="file"
               class="form-control"
               id="logo"
               name="logo"
               accept="image/*">
        <span class="text-danger error" id="logo-error"></span>
    </div>

    <div class="d-flex justify-content-between">
        <button type="submit" class="btn btn-primary px-4">Update Logo</button>
        <a href="{{ route('logos') }}" class="btn btn-outline-secondary px-4">Cancel</a>
    </div>
</form>


                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
