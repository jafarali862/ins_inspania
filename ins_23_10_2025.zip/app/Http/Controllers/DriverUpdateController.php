<?php

namespace App\Http\Controllers;

use App\Models\DriverData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class DriverUpdateController extends Controller
{

    public function updateDriverDatanew(Request $request)
{
    try {
        $selected = $request->input('selected_field');

        if (!$selected || !str_contains($selected, ':')) {
            return back()->withErrors(['error' => 'Please select a driver record to update.']);
        }

        [$fieldName, $garageId] = explode(':', $selected);

        // Sanitize field name to prevent injection
        $fieldName = preg_replace('/[^a-zA-Z0-9_]/', '', $fieldName);

        $garage = DriverData::findOrFail($garageId);

        $inputKey = "field_value.$garageId.$fieldName";
        $otherKey = "other_value.$garageId.$fieldName";

        $finalValue = null;

        if ($request->hasFile($inputKey)) {
            $file = $request->file($inputKey);
            $path = $file->store('driver_uploads', 'public');
            $finalValue = $path;
        } elseif ($request->filled($inputKey)) {
            $value = $request->input($inputKey);

            if ($value === 'Other' && $request->filled($otherKey)) {
                $finalValue = $request->input($otherKey);
            } else {
                $finalValue = $value;
            }
        } else {
            return back()->withErrors(['error' => 'No valid input found to update.']);
        }

        $garage->$fieldName = $finalValue;
        $garage->save();

        $tab = $request->input('tab', '');
        return redirect()->back()
            ->withFragment($tab)
            ->with('success', 'Driver Data Updated Successfully!');
    } catch (\Exception $e) {
        Log::error('Driver data update failed', [
            'error' => $e->getMessage(),
            'selected_field' => $request->input('selected_field')
        ]);

        return redirect()->back()
            ->withErrors(['error' => 'An error occurred while updating driver data. Please try again.']);
    }
}

    // public function driverSpecialCase($id)
    // {
    //     $driverData = DriverData::findOrFail($id);
    //     $driverData->sp_case = 1;
    //     $driverData->save();
    //     return back()->with('success', 'Driver section data Reasigned successfully!');
    // }



    public function driverSpecialCase($id)
{
    try {
        $driverData = DriverData::findOrFail($id);
        $driverData->sp_case = 1;
        $driverData->save();

        return back()->with('success', 'Driver section data reassigned successfully!');
    } catch (\Exception $e) {
        Log::error('Error in driverSpecialCase', [
            'driver_data_id' => $id,
            'error' => $e->getMessage(),
        ]);

        return back()->withErrors(['error' => 'Something went wrong while reassigning driver data. Please try again.']);
    }
}


}
