<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\User;
use App\Models\Salary;
use App\Models\OdometerReading;
class ExecutiveController extends Controller
{
   

    public function odometerList(Request $request)
    {
       
     try {
        $query = OdometerReading::with('user');

        if ($request->filled('from_date')) {
            $query->whereDate('created_at', '>=', $request->from_date);
        }

        if ($request->filled('to_date')) {
            $query->whereDate('created_at', '<=', $request->to_date);
        }

        $data = $query->orderBy('updated_at', 'desc')->get();

        return view('dashboard.odometer.index')->with([
            'odometerRecords' => $data,
            'from_date' => $request->from_date,
            'to_date' => $request->to_date,
        ]);
    } catch (\Exception $e) {
        Log::error('Error fetching odometer readings: ' . $e->getMessage());

        return back()->withErrors(['error' => 'Failed to fetch odometer readings. Please try again.']);
    }
    }


public function view($id)
{
    try {
        $record = OdometerReading::with('user')
            ->select(
                'id',
                'user_id',
                'check_in_km',
                'check_in_image',
                'check_in_time',
                'check_in_date',
                'check_out_km',
                'check_out_image',
                'check_out_time',
                'check_out_date',
                'check_in_latitude_and_longitude',
                'check_out_latitude_and_longitude'
            )
            ->findOrFail($id);

        return view('dashboard.odometer.view')->with(['record' => $record]);

    } catch (\Exception $e) {
        Log::error('Failed to fetch odometer record: ' . $e->getMessage());
        return back()->withErrors(['error' => 'Failed to load the odometer record.']);
    }
}


    public function salaryCreate(Request $request)
    {
        $users = User::where('role', '!=', 1)->get();
        return view('dashboard.salary.create')->with(['users' => $users]);
    }

   public function salaryStore(Request $request)
{
    $request->validate([
        'user' => 'required|exists:users,id',
        'basic_salary' => 'required|numeric|min:0',
        'allowance' => 'nullable|numeric|min:0',
        'bonus' => 'nullable|numeric|min:0',
        'month_year' => 'required|string',
        'total_salary' => 'required|numeric|min:0',
    ]);

    try {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('d-m-Y');

        Salary::create([
            'user_id'    => $request->user,
            'basic'      => $request->basic_salary,
            'allowance'  => $request->allowance ?? 0,
            'bonus'      => $request->bonus ?? 0,
            'total'      => $request->total_salary,
            'month_year' => $request->month_year,
            'date'       => $date,
        ]);

        return response()->json(['message' => 'Salary created successfully!'], 201);

    } catch (\Exception $e) {
        Log::error('Salary creation failed: ' . $e->getMessage());

        return response()->json([
            'error' => 'Failed to create salary. Please try again later.'
        ], 500);
    }
}

    public function salaryIndex()
    {
        $salaries = Salary::orderBy('created_at', 'desc')->paginate(10);
        return view('dashboard.salary.index', compact('salaries'));
    }
}


