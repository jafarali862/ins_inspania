<?php

namespace App\Http\Controllers;

use App\Models\SpotData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class SpotUpdateController extends Controller
{
   

public function updateSpotDatanew(Request $request)
{
    try {
        $selected = $request->input('selected_field');

        if (!$selected || !str_contains($selected, ':')) {
            return back()->withErrors(['error' => 'Please select a spot record to update.']);
        }

        [$fieldName, $garageId] = explode(':', $selected);

        // Sanitize the field name to avoid injection or invalid columns
        $fieldName = preg_replace('/[^a-zA-Z0-9_]/', '', $fieldName);

        $garage = SpotData::findOrFail($garageId);

        $inputKey = "field_value.$garageId.$fieldName";
        $otherKey = "other_value.$garageId.$fieldName";

        $finalValue = null;

        if ($request->hasFile($inputKey)) {
            $file = $request->file($inputKey);
            $path = $file->store('spot_uploads', 'public');
            $finalValue = $path;
            Log::info("File uploaded for SpotData ID {$garageId}, field {$fieldName}, path: {$path}");
        } elseif ($request->filled($inputKey)) {
            $value = $request->input($inputKey);

            if ($value === 'Other' && $request->filled($otherKey)) {
                $finalValue = $request->input($otherKey);
                Log::info("Using 'Other' value for SpotData ID {$garageId}, field {$fieldName}: {$finalValue}");
            } else {
                $finalValue = $value;
                Log::info("Using input value for SpotData ID {$garageId}, field {$fieldName}: {$finalValue}");
            }
        } else {
            Log::warning("No valid input found to update for SpotData ID {$garageId}, field {$fieldName}");
            return back()->withErrors(['error' => 'No valid input found to update.']);
        }

        $garage->$fieldName = $finalValue;
        $garage->save();

        Log::info("SpotData ID {$garageId} updated successfully: {$fieldName} set.");

        $tab = $request->input('tab', '');
        return redirect()->back()->withFragment($tab)->with('success', 'Spot Data Updated Successfully!');
    } catch (\Exception $e) {
        Log::error("Failed to update SpotData. Error: {$e->getMessage()}", [
            'selected_field' => $request->input('selected_field'),
            'request_data' => $request->all(),
            'trace' => $e->getTraceAsString(),
        ]);
        return back()->withErrors(['error' => 'An error occurred while updating Spot Data. Please try again.']);
    }
}



public function spotSpecialCase($id)
{
    try {
        $accidentData = SpotData::findOrFail($id);
        $accidentData->sp_case = 1;
        $accidentData->save();

        Log::info("SpotData ID {$id} marked as special case successfully.");

        return back()->with('success', 'Spot section data reassigned successfully!');
    } catch (\Exception $e) {
        Log::error("Failed to mark SpotData ID {$id} as special case: " . $e->getMessage(), [
            'trace' => $e->getTraceAsString()
        ]);
        return back()->withErrors(['error' => 'Failed to reassign spot section data. Please try again.']);
    }
}


}
