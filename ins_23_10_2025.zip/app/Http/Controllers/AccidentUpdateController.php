<?php

namespace App\Http\Controllers;

use App\Models\AccidentPersonData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;


class AccidentUpdateController extends Controller
{
   

   public function updateAccidentDatanew(Request $request)
{
    try {
        Log::info('Received updateAccidentDatanew request', $request->all());

        $selected = $request->input('selected_field');

        if (!$selected || !str_contains($selected, ':')) {
            Log::warning('Invalid or missing selected_field value.');
            return back()->withErrors(['error' => 'Please select an accident record to update.']);
        }

        // Parse selected input (format: field:ID)
        [$fieldName, $garageId] = explode(':', $selected);

        $fieldName = preg_replace('/[^a-zA-Z0-9_]/', '', $fieldName); // sanitize
        Log::info('Parsed selected_field', compact('fieldName', 'garageId'));

        $garage = AccidentPersonData::find($garageId);
        if (!$garage) {
            Log::error("AccidentPersonData not found for ID: $garageId");
            return back()->withErrors(['error' => 'Accident record not found.']);
        }

        // Determine the request keys
        $inputKey = "field_value.$garageId.$fieldName";
        $otherKey = "other_value.$garageId.$fieldName";
        Log::debug('Input keys identified', compact('inputKey', 'otherKey'));

        $finalValue = null;

        // Handle file upload
        if ($request->hasFile($inputKey)) {
            $file = $request->file($inputKey);
            $path = $file->store('spot_uploads', 'public');
            $finalValue = $path;

            Log::info('File uploaded successfully', ['path' => $path]);
        }

        // Handle standard form input
        elseif ($request->filled($inputKey)) {
            $value = $request->input($inputKey);
            Log::info('Form value received', compact('value'));

            if ($value === 'Other') {
                if ($request->filled($otherKey)) {
                    $finalValue = $request->input($otherKey);
                    Log::info('Using "Other" value provided', ['other_value' => $finalValue]);
                } else {
                    Log::warning("Expected 'Other' value input missing for key: $otherKey");
                    return back()->withErrors(['error' => 'Other value selected but not provided.']);
                }
            } else {
                $finalValue = $value;
            }
        }

        // If neither file nor input is provided
        else {
            Log::warning('No valid input or file provided', [
                'input_key' => $inputKey,
                'all_request_data' => $request->all()
            ]);
            return back()->withErrors(['error' => 'No valid input found to update.']);
        }

        // Save the updated field
        $garage->$fieldName = $finalValue;
        $garage->save();

        Log::info('AccidentPersonData updated successfully', [
            'id' => $garageId,
            'field' => $fieldName,
            'new_value' => $finalValue
        ]);

        // Optional: support tab switching
        $tab = $request->input('tab', '');

        return redirect()->back()->withFragment($tab)->with('success', 'Accident Data Updated Successfully!');
    
    } catch (\Exception $e) {
        Log::error('Error updating AccidentPersonData', [
            'error_message' => $e->getMessage(),
            'stack_trace' => $e->getTraceAsString(),
            'request_data' => $request->all()
        ]);

        return back()->withErrors(['error' => 'An unexpected error occurred while updating accident data.']);
    }
}


    public function accidentSpecialCase($id)
    {
    try {
        // Validate that ID is a valid number
        if (!is_numeric($id)) {
            return back()->withErrors(['error' => 'Invalid ID provided.']);
        }

        // Retrieve the record or fail
        $accidentData = AccidentPersonData::findOrFail($id);

        // Check if already marked as special case
        if ($accidentData->sp_case == 1) {
            return back()->withErrors(['error' => 'This record is already marked as a special case.']);
        }

        // Update the record
        $accidentData->sp_case = 1;
        $accidentData->save();

        return back()->with('success', 'Accident Person section data reassigned successfully!');

    } catch (\Exception $e) {
        Log::error('Error in accidentSpecialCase:', [
            'id' => $id,
            'message' => $e->getMessage()
        ]);

        return back()->withErrors(['error' => 'An unexpected error occurred while updating the record.']);
    }
    }

}
