<?php

namespace App\Http\Controllers;

use App\Models\CompanyLogo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class LogoManagenentController extends Controller
{

    public function index()
    {
        $logos = CompanyLogo::paginate(10);
        return view('dashboard.logo.index', compact('logos'));
    }

    public function getLogo()
    {
    return view('dashboard.logo.create');
    }


public function storeLogo(Request $request)
{
    try {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:company_logos,email',
            'phone' => 'required|string|max:15',
            'place' => 'required|string|max:255',
            'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $logoPath = null;

        if ($request->hasFile('logo')) {
            $logoPath = $request->file('logo')->store('logos', 'public');
        }

        CompanyLogo::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'place' => $request->place,
            'logo' => $logoPath,
        ]);

        return redirect()->route('logos')->with('success', 'Company logo added successfully!');
    } catch (\Illuminate\Validation\ValidationException $e) {
        // If validation fails, it automatically redirects back with errors,
        // but you can handle or customize if needed here.
        return redirect()->back()->withErrors($e->errors())->withInput();
    } catch (\Exception $e) {
        // Log unexpected errors
        Log::error('Error storing company logo:', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()->back()->with('error', 'An error occurred while uploading the company logo. Please try again.');
    }
}

   public function editLogo($id)
{
    try {
        $logo = CompanyLogo::findOrFail($id);
        return view('dashboard.logo.edit', compact('logo'));
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        // Logo not found
        return redirect()->route('logos')->with('error', 'Company logo not found.');
    } catch (\Exception $e) {
        // Other unexpected errors
        Log::error('Error fetching company logo for edit:', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTraceAsString(),
        ]);
        return redirect()->route('logos')->with('error', 'An error occurred while fetching the company logo.');
    }
}


public function updateLogo(Request $request, $id)
{
    try {
        $request->validate([
            'name'      => 'required|string|max:255',
            'email'     => 'required|email|unique:company_logos,email,' . $id,
            'phone'     => 'required|string|max:15',
            'place'     => 'required|string|max:255',
            'logo'      => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'logo_path' => 'nullable|image|mimes:jpeg,jpg,png,webp|max:150', // 150 KB max
        ]);

        $logo = CompanyLogo::findOrFail($id);
        $logo->name = $request->name;
        $logo->email = $request->email;
        $logo->phone = $request->phone;
        $logo->place = $request->place;

        // Upload plain logo
        if ($request->hasFile('logo')) {
            if ($logo->logo && Storage::disk('public')->exists($logo->logo)) {
                Storage::disk('public')->delete($logo->logo);
            }
            $path = $request->file('logo')->store('logos', 'public');
            $logo->logo = $path;
        }

        // Upload processed logo (logo_path)
        if ($request->hasFile('logo_path')) {
            if ($logo->logo_path && Storage::disk('public')->exists($logo->logo_path)) {
                Storage::disk('public')->delete($logo->logo_path);
            }

            $file = $request->file('logo_path');
            $extension = $file->getClientOriginalExtension();

            $filename = 'company_logo_' . time() . '_' . Str::random(5) . '.' . $extension;

            $path = $file->storeAs('logos', $filename, 'public');

            $logo->logo_path = $path;
        }

        $logo->save();

        session()->flash('success', 'Company logo updated successfully!');
        return redirect()->route('logo.edit', ['id' => $id]);

    } catch (\Exception $e) {
        Log::error('Error updating company logo:', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()->route('logo.edit', ['id' => $id])
            ->with('error', 'An error occurred while updating the company logo.');
    }
}

}
