<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;

class UserRolePermissionController extends Controller
{
    public function showAssignForm()
    {
        $users = User::all();
        $roles = Role::with('permissions')->get();
        $permissions = Permission::with('children')->whereNull('parent_id')->get();

        return view('admin.assign_roles', compact('users', 'roles', 'permissions'));
    }

    public function assign(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'role_id' => 'required|exists:roles,id',
            'permissions' => 'nullable|array',
            'permissions.*' => 'exists:permissions,id',
        ]);

        $user = User::findOrFail($request->user_id);
        $role = Role::findOrFail($request->role_id);

        // Sync role for user
        $user->roles()->sync([$role->id]);

        // Sync permissions to role
        $role->permissions()->sync($request->permissions ?? []);

        return redirect()->back()->with('success', 'Role & permissions assigned successfully.');
    }
}
