<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FinalReport extends Model
{
    use HasFactory;

    protected $fillable = ['case_id'];
     protected $table = 'final_reports';

    public $timestamps = true; // enables created_at and updated_at


    // FinalReport.php
public function caseAssignment()
{
    return $this->belongsTo(CaseAssignment::class, 'case_id');
}



}
