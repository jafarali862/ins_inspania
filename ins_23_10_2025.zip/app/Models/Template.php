<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Template extends Model
{
    use HasFactory;
    use SoftDeletes;

     protected $fillable = [
        'company_id',
        'template_id',
        'template_logo',
        'case_type',
        'mact_type'
    ];



    public function company()
    {
        return $this->belongsTo(InsuranceCompany::class, 'company_id');
    }

    // Template.php
   public function questions()
{
    return $this->belongsToMany(Question::class, 'question_template');
}


    

}


