<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OwnerData extends Model
{
    use HasFactory;

    protected $fillable = ['assign_work_id','executive_id'];

     public function executive()
    {
        return $this->belongsTo(User::class, 'executive_id', 'id');
    }
    
}
