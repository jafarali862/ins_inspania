<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\InteractsWithSockets;

class LoginRequestNotification implements ShouldBroadcast
{
    use InteractsWithSockets, SerializesModels;

    public $userId;
    public $userName;

    public function __construct($userId, $userName)
    {
        $this->userId = $userId;
        $this->userName = $userName;
    }

    public function broadcastOn(): Channel
    {
        return new Channel('login-requests');
    }

    public function broadcastWith(): array
    {
        return [
            'user_id' => $this->userId,
            'name' => $this->userName,
        ];
    }

    public function broadcastAs(): string
    {
        return 'LoginRequestNotification';
    }
}
