<h1>Edit Role</h1>

@if ($errors->any())
    <div>
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form method="POST" action="{{ route('roles.update', $role->id) }}">
    @csrf
    @method('PUT')

    <label>Role Name</label>
    <input type="text" name="name" value="{{ old('name', $role->name) }}" required>

    <h3>Assign Permissions</h3>

    @foreach($permissions as $permission)
    <div>
        <input type="checkbox" name="permissions[]" id="perm_{{ $permission->id }}" value="{{ $permission->name }}"
            {{ $role->hasPermissionTo($permission->name) ? 'checked' : '' }}>
        <label for="perm_{{ $permission->id }}">{{ $permission->name }}</label>
    </div>
    @endforeach

    <button type="submit">Update</button>
</form>
