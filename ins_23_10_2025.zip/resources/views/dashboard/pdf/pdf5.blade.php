<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;

        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
<div id="container" style="display: flex; justify-content: center;margin-top:40px;">
    <div>
        <!-- Header Row -->
       <div style="width: 100%; display: block; margin-bottom: 100px;">
  
  <!-- Left div: red bar with title -->
  <div style="
    display: inline-block;
    vertical-align: middle;
    width: calc(100% - 200px);
    border-top: 20px solid #822727;
    text-align: center;
    position: relative;
    padding-top: 5px;
  ">
    <span style="
      font-weight: bold;
      font-size: 16px;
      position: relative;
      top: -16px;
      color: rgb(2, 2, 2);
      text-decoration: underline;
      display: inline-block;
    ">
      INVESTIGATION REPORT:
    </span>
  </div>

  <!-- Right div: investigator box -->
  <div style="
    display: inline-block;
    vertical-align: middle;
    width: 180px;
    border: 1px solid #000;
    border-radius: 10px;
    height: 70px;
    text-align: center;
    padding-top: 10px;
    box-sizing: border-box;
  ">
    <div style="font-size: 18px; font-weight: bold;">ANOOP N.G</div>
    <div style="font-size: 14px; font-weight: bold;">INVESTIGATOR</div>
  </div>

</div>



  @php
    // Group questions by category
    $groupedQuestions = $validQuestions12->groupBy('group_category');

    // Filter out groups with no data in $finalReport
    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return !empty($finalReport->{$question->column_name});
        });
    });

    // Define category titles with section numbers (optional)
    $sectionTitles = [
        'introduction' => 'I. INTRODUCTION:',
        'case_details' => 'II. CASE/CLAIM DETAILS:',
        'accident_person_data' => 'III. ACCIDENT DETAILS:',
        // Add more categories here if needed
    ];
@endphp

@foreach($filteredGroups as $category => $questions)
    @php
        // Generate section title
        $title = $sectionTitles[$category] ?? strtoupper(str_replace('_', ' ', $category));
                $rowNumber = 1; // Initialize row number

    @endphp

    <h3 style="font-weight: bold; margin-top: 20px;">{{ $title }}</h3>

    <table>
        @foreach($questions->where('input_type', '!=', 'file') as $question)
            @php
                $answer = $finalReport->{$question->column_name} ?? null;
            @endphp

            @if(!empty($answer) || $answer === '0' || $answer === 0)
                <tr>
                       <td>{{ $rowNumber++ }}</td>
                    <td>{{ $question->question }}</td>
                    <td>
                        @if($answer === '0' || $answer === 0)
                            No
                        @elseif($answer === '1' || $answer === 1)
                            Yes
                        @else
                            {{ $answer }}
                        @endif
                    </td>
                </tr>
            @endif
        @endforeach
    </table>
@endforeach


          <h3>VIII. FIR DETAILS (Enclose copy):</h3>

            <table>

                <tr>
                    <td >1</td>
                    <td>Name of Police Station, District & State</td>
                    <td>NEYYATTINKARA, THIRUVANANTHAPURAM RURAL</td>
                </tr>

               
            </table>

            <h3>X. CHARGE-SHEET/CHALLAN DETAILS</h3>

            <table>

                <tr>
                    <td>1</td>
                    <td>Court where Charge-Sheet/Final Report filed & CC No.</td>
                    <td>Before the Hon’ble Judicial First-Class Magistrate Court –I Neyyattinkara</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Date of Charge-Sheet/Final Report</td>
                    <td>04.01.2024</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Sections in the Charge-Sheet</td>
                    <td>306 (1) (c) PSO</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Who all are charged with (e.g. Our Driver, Other Driver)</td>
                    <td>NA</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Gist of Charge-Sheet</td>
                    <td>On 09.11.2023 at about 02:30 hrs, the complainant’s husband Santhosh Kumar was the driver of
                        motor car bearing Reg.No. KL-19-D-1801 in which the complainant and his colleague Sreekala were
                        the passengers and drove through Parassala-Neyyattinkara road from Parassala side to
                        Neyyattinkara side and reached near Gramam Toll gate, Kadavattaram, Neyyattinkara village and
                        the vehicle unexpectedly skid and hit the back side of KL-44-C-2882 tourist bus which was on the
                        north side of the said road. Due to the impact of the hit, complainant and others had sustained
                        severe injuries and fractures. The accident was happened unexpectedly so it is registered under
                        motor occurrence.</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Any Petty Case charged, if so, details</td>
                    <td>NA</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Present Status of the Criminal Case</td>
                    <td>Pending</td>
                </tr>
            </table>

            <h3>XI. INVESTIGATION DETAILS:</h3>

            <table>

                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Whether the Accident Genuine or Not as per the evidence gathered.</td>
                        <td>The accident is Genuine.</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Opinion on disablement/dependency</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Opinion on Income of Injured/Deceased</td>
                        <td>Middle class</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Opinion on what capacity the Injured/deceased travelled in the Vehicle.</td>
                        <td>The injured was a rider of motor car.</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Opinion on Contribution of our vehicle & Other Vehicle, if more than one Vehicle is
                            involved.</td>
                        <td>NIL</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Opinion on DL effectiveness/validity as on Date of Accident.</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Whether DL extract obtained, if not, reasons thereof.</td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>Whether involvement of the Injured/Deceased established from the FIR, if not, clarify.</td>
                        <td>YES</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>Whether involvement of Insured Vehicle is established from the FIR, if not, clarify</td>
                        <td>YES</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Comments on defence on the evidence available</td>
                        <td>NA</td>
                    </tr>
                </tbody>
            </table>
            <h3>XII.WOUND/DISABILITY CERTIFICATE (Enclose copy):</h3>
            <p style="font-size: 30;">Immediately after the accident, the injured Sunitha, Sreekala and Santhosh Kumar
                was taken to NIMS Hospital, Aaralummoodu and treated there. We have collected the wound certificate of
                injured Sunitha and Sreekala. While verifying the same it is mentioned that “A/H/o RTA (Car vs Bike) at
                around 02:25am at Gramam on 09/11/2023”. A copy of each attached with it.</p>


            <h3>XIII. WEARING OF PROTECTIVE HEADWEAR/HELMET IN CASE OFHEAD INJURY
                CAUSED TO TWO-WHEELER RIDER OR PILLION RIDER AS CLAIMANT: -</h3>

            <h3>XIV. DISCUSSION OF EVIDENCE AVAILABLE:</h3>


            <table>

                <tbody>
                    <tr>
                        <td>A</td>
                        <td>Result on verification of Medical Records</td>
                        <td>We have collected the wound certificate of injured Sunitha and Sreekala. While verifying the
                            same it is mentioned that “A/H/o RTA (Car vs Bike) at around 02:25am at Gramam on
                            09/11/2023”. A Copy of each attached with it.</td>
                    </tr>
                    <tr>
                        <td>B</td>
                        <td>Result of discussion with the Injured/deceased family & neighbours</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>C</td>
                        <td>Discuss on what capacity the Injured/deceased was travelling in the Vehicle</td>
                        <td>The injured was the pillion rider of motor cycle.</td>
                    </tr>
                    <tr>
                        <td>D</td>
                        <td>Result of discussion with the insured</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>E</td>
                        <td>Result of discussion with the employer for confirming the occupation & income of the
                            injured/deceased</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>F</td>
                        <td>Result of discussion with the rider of the IV</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>G</td>
                        <td>Discussion on the Financial Investigation on the Insured with regard to his employment,
                            employer, salary, movable & immovable property, total monthly income, etc.</td>
                        <td>NA</td>
                    </tr>
                </tbody>
            </table>

            <h3>FACTS AND FINDINGS:</h3>

            <ul>
                <li>On 09.11.2023 at about 02:30 hrs, the complainant’s husband Santhosh Kumar was the driver of motor
                    car bearing Reg.No. KL-19-D-1801 in the which complainant and his colleague Sreekala were the
                    passengers and drove through Parassala-Neyyattinkara road from Parassala side to Neyyattinkara side
                    and reached near Gramam Toll gate, Kadavattaram, Neyyattinkara village and vehicle unexpectedly skid
                    and hit the back side of KL-44-C-2882 tourist bus which was on the north side of the said road. Due
                    to the impact of the hit, complainant and others had sustained severe injuries and fractures. </li>

                <li>The accident was happened unexpectedly hence it is registered under motor occurrence.</li>

                <li>Immediately after the accident, the injured Sunitha, Sreekala and Santhosh Kumar was taken to NIMS
                    Hospital, Aaralummoodu and treated there. We have collected the wound certificate of injured Sunitha
                    and Sreekala. While verifying the same it is mentioned that “A/H/o RTA (Car vs Bike) at around
                    02:25am at Gramam on 09/11/2023”. A Copy of each attached with it.</li>

                <li>We have collected the discharge summary of injured Mrs. Sreekala from NIMS Hospital, Aaralummoodu
                    and a copy of the same enclosed with it.</li>

                <li>IV Details: The IV is bus bearing Reg.No. KL-44-C-2882 owned by Mr. Subin</li>
                <li>Policy Details: The IV is insured with UNITED INDIA INSURANCE COMPANY LIMITED</li>


                <li>Policy No: 1004003123P100594371 and the period of validity cover from 14.04.2023 to13.04.2024</li>
                <li>IV driver: The IV driver Mr. Subin who has valid DL at the time of accident.</li>
            </ul>

            <h3>CONCLUSION</h3>
            <p style="font-size: 20px;"> On the course of investigation, meeting with concerned parties and verifying
                the medical documents, we come to the conclusion that the accident is genuine. The accident was happened
                unexpectedly hence the case is registered under motor occurrence (306 (1) (c)).</p>
            <br>
            <br>

            <div style="display: flex; justify-content: space-between;">
                <div>10.09.2024<br>Trivandrum</div>
                <div>ANOOP N G </div>
            </div>

            <h3>Photo of injured Anagha</h3>
            <img src="picture1.png" alt="">
            <br>
            <h3>Adhaar Card Of Injured sunitha</h3>
            <img src="picture2.png" alt="">
            <img src="picture3.png" alt="">
            <br>
            <h3>Photo of injured Sreekala</h3>
            <img src="picture4.png" alt="">
            <br>
            <h3>Ration Card Of Injured Sreekala</h3>
            <img src="picture5.png" alt="">
            <img src="picture6.png" alt="">
            <br>
            <h3>Adhar Card Of Injured Sreekala</h3>
            <img src="picture7.png" alt="">
            <img src="picture8.png" alt="">
            <br>
            <h3>Spot</h3>
            <img src="picture9.png" alt="">
            <img src="picture10.png" alt="">




        </div>
    </div>

</body>

</html>