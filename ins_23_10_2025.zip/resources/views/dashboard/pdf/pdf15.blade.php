<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New india tvm report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            width: 50%;
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center;">
        <div>
            <div style="text-align: end;">
                <!-- <img src="image.png"> -->


            @if($template->template_logo)
            <img src="{{ public_path('storage/' . $template->template_logo) }}" 
            alt="Company Logo" 
            style="max-width: 200px; height: auto; margin-top: 10px;">
            @endif


            </div>


            <table>
                <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                        <p style="font-size: 25;">Investigation Report -{{$template->insurance_com_name}}</p>
                    </th>
                </tr>
                <tr>
                    <td>Name of Customer</td>
                    <td>Babu</td>
                </tr>
                <tr>
                    <td>Contact Details of Customer</td>
                    <td><br>Adreess12<br/>
                   
                        <br>Phone no:996124255 <br>Email: samp34@gmail.com
                    </td>
                </tr>

                 <tr>
                    <td>Policy Date</td>
                    <td>       
                    2025-08-08 - 

                   2025-08-08
                    </td>
                </tr>


                 <tr>
                    <td>Policy No</td>
                    <td>134564</td>
                </tr>

                 <tr>
                    <td>Crime Number</td>
                    <td>23/2025</td>
                </tr>

                  <tr>
                    <td>Police Station</td>
                    <td>Malappuram</td>
                </tr>

                  <tr>
                    <td>Case Type</td>
                    <td>OD</td>
                </tr>

                 <tr>
                    <td>Investigation Date</td>
                    <td>2025-08-10</td>
                </tr>




            </table>
            <br>


         <div id="container" style="margin-top: 25px; text-align: center; margin: 0 auto;">
    <div style="width: 600px; margin: 0 auto;">

        {{-- Group questions by data_category --}}
        @php
            $groupedQuestions = $questions->groupBy('data_category');
            $counter = 1;
        @endphp

        @foreach($groupedQuestions as $category => $categoryQuestions)
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <tr>
                    <th colspan="3" style="text-align: center; background-color: yellow; padding: 10px;">
                        {{ strtoupper(str_replace('_', ' ', $category)) }}
                    </th>
                </tr>

                @foreach($categoryQuestions as $question)
                    @if($question->file_type !== 'image')
                        <tr>
                            <td style="width: 30px; border: 1px solid #000;">{{ $counter++ }}.</td>
                            <td style="width: 300px; border: 1px solid #000;"><strong>{{ $question->question }}</strong></td>
                            <td style="border: 1px solid #000;">
                                @php
                                    $value = $finalReport->{$question->column_name} ?? null;
                                @endphp

                                @if($question->input_type === 'text')
                                    {{ $value ?? 'Sample text answer' }}
                                @elseif($question->input_type === 'select')
                                    {{ $value == 1 ? 'Yes' : 'No' }}
                                @elseif($question->input_type === 'date')
                                    {{ $value ? \Carbon\Carbon::parse($value)->format('d-m-Y') : '05-08-2025' }}
                                @elseif($question->input_type === 'textarea')
                                    {{ $value ?? 'Sample Text Description' }}
                                @else
                                    N/A
                                @endif
                            </td>
                        </tr>
                    @endif
                @endforeach
            </table>
        @endforeach

        {{-- Footer --}}
        <div style="display: flex; justify-content: space-between; margin-top: 30px;">
            <div style="text-align: left;">
            
            <p>Executive Name: Executive5</p>
            <p>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}</p>
          
                
            </div>
        </div>

        {{-- Image Questions --}}
        @php $imageCounter = 1; @endphp
           @foreach($questions as $question1)
            @if($question1->file_type === 'image')
                <div style="margin-top: 30px; text-align: center;">
                    <p><strong>{{ $imageCounter++ }}. {{ $question1->question }}</strong></p>
                    <img src="{{ public_path('storage/uploads/0sGvZo9McMzP978qZBOdmH0mXM13aS2SYSHrUY3y.jpg') }}"
                         alt="Image">
                </div>
            @endif
        @endforeach

    </div>
</div>

</body>

</html>