 
Companycontrollelr/index_question
 $search = $request->input('search', '');

        $questions = Question::when(!empty($search), function ($query) use ($search) {
        $query->where(function ($q) use ($search) {
        $q->where('question', 'like', '%' . $search . '%')
        ->orWhere('input_type', 'like', '%' . $search . '%')
        ->orWhere('data_category', 'like', '%' . $search . '%');
        });
        })
        ->orderBy('created_at', 'desc')
        ->get();