@extends('dashboard.layout.app')
@section('title', 'Add Company')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-plus me-2 text-primary"></i> Add Company
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('company.list') }}">Companies</a></li>
                    <li class="breadcrumb-item active">Add Company</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-plus me-2"></i>
                            <h5 class="mb-0" style="color: #fff;">Add Company</h5>
                            

            <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" style="margin-left: 20px;align-items: center;">
            <i class="fa fa-check-circle me-2"></i>
            <span id="successText"></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
                        </div>



                        
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                           
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Add User Form -->
                     <!-- Add User Form -->
                    

              <form id="companyForm" method="POST" action="{{ route('companies.store') }}" novalidate>
    @csrf

    <!-- Company Name -->
    <div class="mb-3">
        <label for="name" class="form-label fw-bold">Company Name <span class="text-danger">*</span></label>
        <input type="text" 
               class="form-control" 
               id="name" 
               name="name" 
               value="{{ old('name') }}" 
               placeholder="Enter company name" 
               required>
        <span id="name-error" class="text-danger error"></span>
    </div>

 




    <!-- Contact Person -->
    <div class="mb-3">
        <label for="contact_person" class="form-label fw-bold">Contact Person <span class="text-danger">*</span></label>
        <input type="text" 
               class="form-control" 
               id="contact_person" 
               name="contact_person" 
               value="{{ old('contact_person') }}"
               placeholder="Enter contact person" 
               required>
        <span id="contact_person-error" class="text-danger error"></span>
    </div>

    <!-- Phone Number -->


 @php
use Illuminate\Support\Facades\Http;

// Fetch countries dynamically with SSL verification disabled
$countries = Http::withOptions([
    'verify' => false
])->get('https://restcountries.com/v3.1/all?fields=name,idd,cca2')->json();
@endphp


    <div class="mb-3">
    <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
    <div class="d-flex align-items-center gap-2">
        <!-- Country Code -->
        <select id="country_code" name="country_code" class="select2 form-select form-select-sm" data-placeholder="Code">
            <option value="">Select Country Code</option>
    @foreach($countries as $country)
        @php
            $dialCode = isset($country['idd']['root'], $country['idd']['suffixes'][0]) 
                ? $country['idd']['root'] . $country['idd']['suffixes'][0] 
                : null;
        @endphp

        @if($dialCode)
            <option value="{{ $dialCode }}"
                {{ $dialCode == '+91' ? 'selected' : '' }}>
                {{ $dialCode }} ({{ $country['name']['common'] }})
            </option>
        @endif
    @endforeach
        </select>

        <!-- Phone Number -->
        <input type="text" id="phone" name="phone" class="form-control" 
               placeholder="Enter phone number"
               required maxlength="15" inputmode="numeric"
               oninput="validatePhoneInput(this)">
    </div>
    <div id="phoneError" class="text-danger mt-1" style="display:none;">
        Please enter digits only (0-9).
    </div>
</div>

    

    <!-- Email Address -->
    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
        <input type="email" 
               class="form-control" 
               id="email" 
               name="email" 
               value="{{ old('email') }}"
               placeholder="Enter email address" 
               required>
   <small id="emailError" style="color: red; display: none;"></small>
    </div>

    <!-- Address -->
    <div class="mb-3">
        <label for="address" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
        <textarea class="form-control" 
                  id="address" 
                  name="address" 
                  rows="3" 
                  placeholder="Enter address" 
                  required>{{ old('address') }}</textarea>
        <span id="address-error" class="text-danger error"></span>
    </div>

    <!-- Select Final Report Template -->

   <div class="mb-3">
  <label for="selectTemplate" class="form-label fw-bold">
    Select Final Report Template <span class="text-danger">*</span>
  </label>

  <!-- Flex container for select + button -->
  <div class="d-flex align-items-end gap-2">
  <!-- Select dropdown -->
  <div class="flex-grow-1">
  <select name="template" class="select2 form-select" id="selectTemplate" required data-placeholder="Select Template">
  <!-- <option value="" disabled selected>Please select</option> -->

  <option value="">Please select</option> 

        <option value="0">Default Template</option>
        
  @foreach ($templates as $template)
    <option value="{{ $template->id }}">{{ $template->template_id }}</option>
  @endforeach
  </select>
  </div>

  <!-- Preview button container -->
  <div id="previewButtonContainer"></div>
  </div>

  <span id="template-error" class="text-danger error mt-1 d-block"></span>
  </div>


    
{{-- Tab navs and panes as you already have --}}
<div class="card mb-3">
  <div class="card-header p-2">
    <ul class="nav nav-pills" id="questionTabs" role="tablist">
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="garage-tab" data-bs-toggle="tab" href="#garage" role="tab" aria-controls="garage">Garage Data</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="driver-tab" data-bs-toggle="tab" href="#driver" role="tab" aria-controls="driver">Driver Data</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="spot-tab" data-bs-toggle="tab" href="#spot" role="tab" aria-controls="spot">Spot Data</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="meeting-tab" data-bs-toggle="tab" href="#meeting" role="tab" aria-controls="meeting">Owner Data</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="accident-tab" data-bs-toggle="tab" href="#accident" role="tab" aria-controls="accident">Accident Data</a>
      </li>
    </ul>

     

  </div>
  <div class="card-body">
    <div class="tab-content" id="questionTabsContent">
      <div class="tab-pane fade" id="garage" role="tabpanel" aria-labelledby="garage-tab"></div>
   
      <div class="tab-pane fade" id="driver" role="tabpanel" aria-labelledby="driver-tab"></div>
      <div class="tab-pane fade" id="spot" role="tabpanel" aria-labelledby="spot-tab"></div>
      <div class="tab-pane fade" id="meeting" role="tabpanel" aria-labelledby="meeting-tab"></div>
      <div class="tab-pane fade" id="accident" role="tabpanel" aria-labelledby="accident-tab"></div>
    </div>
  </div>
</div>

        





    <div class="text-left">
        <button type="submit" class="btn btn-success">Add Company</button>
    </div>
</form>

        </div>
        </div>
        </div>
        </div>




        <div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title">Template Preview</h5>
                <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content loaded dynamically -->
            </div>
        </div>
    </div>
</div>

<style>

.card-secondary:not(.card-outline)>.card-header a.active
{
color:#fff;
}

.nav-pills .nav-link {
    /* color: #000000; */
    font-weight: 650;
}


#country_code.select2-hidden-accessible + .select2-container {
  width: 30% !important;
}




    .card-header
{
border-bottom: unset;
}

   .select2-container--bootstrap4 .select2-selection--single .select2-selection__arrow
    {
        visibility: hidden;
    }


select2-container--bootstrap4 .select2-results__option 
{
    color: #000 !important;
    }


</style>


<!-- jQuery -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Select2 Bootstrap 4 Theme -->
<link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css" rel="stylesheet" />

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>





<script>


  $('#country_code').select2({
  theme: 'bootstrap4',  // ✅ correct!
  width: 'resolve',
  placeholder: $('#country_code').data('placeholder'),
  allowClear: true,
  minimumResultsForSearch: 0
});

 $('#selectTemplate').select2({
      theme: 'bootstrap4', // or 'default' if not using Bootstrap
      width: '100%',
      placeholder: $('#selectTemplate').data('placeholder'),
      allowClear: true,
      minimumResultsForSearch: 0 // always show search box
    });

 $('#selectTemplate').on('change', function () {
    let selectedId = $(this).val();

    if (selectedId) {
      // Inject preview button
      let buttonHtml = `
        <button type="button" class="btn btn-sm btn-danger preview-btn mt-2" data-id="${selectedId}">
          <i class="fas fa-eye"></i> Preview
        </button>
      `;
      $("#previewButtonContainer").html(buttonHtml);
    } else {
      $("#previewButtonContainer").html("");
    }
  });

  // ✅ Handle preview button click
  $(document).on("click", ".preview-btn", function () {
    let templateId = $(this).data("id");
    let url = "{{ route('templates.download', ':id') }}".replace(":id", templateId);
    window.open(url, '_blank');
  });
 

  const categories = {
    garage: 'garage_data',
    driver: 'driver_data',
    spot: 'spot_data',
    meeting: 'owner_data',
    accident: 'accident_person_data'
  };

  function loadQuestions(templateId) {
    if (!templateId) return;

    // Clear previous content
    Object.keys(categories).forEach(cat => {
      const pane = document.getElementById(cat);
      if (pane) {
        pane.innerHTML = '';
        pane.dataset.loaded = '';
      }
    });

    fetch(`/template/${templateId}/questions`)
      .then(response => response.json())
      .then(data => {
        const qByCat = data.questions_by_category || {};

        Object.keys(categories).forEach(tabKey => {
          const catName = categories[tabKey];
          const tabPane = document.getElementById(tabKey);

          if (!tabPane || tabPane.dataset.loaded === 'true') return;

          const questions = qByCat[catName] || [];
          let html = `<h5 class="mb-3 fw-bold text-primary text-uppercase">${catName.replace(/_/g, ' ')}</h5>`;

          if (questions.length > 0) {
            questions.forEach(q => {
              const colId = `check_${catName}_${q.column_name}`;
              const isFile = q.input_type === 'file';

              const fileTypeInput = isFile && q.file_type
                ? `<input type="hidden" name="file_types[${catName}][${q.column_name}]" value="${q.file_type}">`
                : '';

              html += `
                <div class="form-check mb-2">
                  <input class="form-check-input" type="checkbox" style="border-color: #6e6868;"  name="selected_questions[${catName}][]" value="${q.column_name}" id="${colId}">
                  <input type="hidden" name="question_types[${catName}][${q.column_name}]" value="${q.input_type}">
                  ${fileTypeInput}
                  <label class="form-check-label" for="${colId}">${q.question}</label>
                </div>`;
            });
          } else {
            html += `<p>No questions in this category for the selected template.</p>`;
          }

          tabPane.innerHTML = html;
          tabPane.dataset.loaded = 'true';
        });

        // Activate first tab
        const firstTabLink = document.querySelector('#questionTabs .nav-link');
        const allTabLinks = document.querySelectorAll('#questionTabs .nav-link');
        const allTabPanes = document.querySelectorAll('#questionTabsContent .tab-pane');

        allTabLinks.forEach(link => link.classList.remove('active'));
        allTabPanes.forEach(pane => pane.classList.remove('show', 'active'));

        if (firstTabLink) {
          firstTabLink.classList.add('active');
          const firstPaneId = firstTabLink.getAttribute('href').substring(1);
          const firstPane = document.getElementById(firstPaneId);
          if (firstPane) firstPane.classList.add('show', 'active');
        }
      })
      .catch(error => {
        console.error('Error loading questions:', error);
      });
  }

  // ✅ Load on change using jQuery (works with Select2)
  $('#selectTemplate').on('change', function () {
    const selected = $(this).val();
    loadQuestions(selected);
  });

  // ✅ Load if already selected on page load
  const preSelected = $('#selectTemplate').val();
  if (preSelected) {
    loadQuestions(preSelected);
  }




</script>


<script>
   $(document).ready(function () {
  
    const categories = {
        garage: 'garage_data',
        driver: 'driver_data',
        spot: 'spot_data',
        meeting: 'owner_data',
        accident: 'accident_person_data'
    };

    $('#companyForm').on('submit', function (e) {
        e.preventDefault();

        let isChecked = false;
        $.each(categories, function (catKey, catName) {
            const checkboxes = $(`input[name="selected_questions[${catName}][]"]`);
            checkboxes.each(function () {
                if ($(this).is(':checked')) {
                    isChecked = true;
                    return false; // break inner loop
                }
            });
            if (isChecked) return false; // break outer loop
        });

        // if (!isChecked) {
        //     $('#category-error').text('Please select at least one question checkbox in any category before submitting.');
        //     return false; // stop submission
        // } else {
        //     $('#category-error').text(''); // clear error if checked
        // }

        // Proceed with AJAX submission
        $.ajax({
            url: '{{ route('companies.store') }}',
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                if (response.success) {
                    $('#successMessage')
                        .removeClass('d-none alert-danger')
                        .addClass('alert alert-success')
                        .fadeIn();
                    $('#successText').text(response.success);
                    $('html, body').animate({
                        scrollTop: $("#successMessage").offset().top - 100
                    }, 500);
                    $('#companyForm')[0].reset();
                    $('.form-control').removeClass('is-invalid');
                    $('.error').text('');

                    setTimeout(function () {
                        window.location.href = response.redirect_url;
                    }, 2500);
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    var errors = xhr.responseJSON.errors;

                    $('.error').text('');
                    $('.form-control').removeClass('is-invalid');

                    $.each(errors, function (key, value) {
                        $('#' + key).addClass('is-invalid');
                        $('#' + key + '-error').text(value[0]);
                    });
                }
            }
        });
    });
});

  function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }


</script>


<script>
  const emailInput = document.getElementById('email');
  const emailError = document.getElementById('emailError');

  // Simple regex for email validation (basic)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  emailInput.addEventListener('input', function() {
    const emailValue = emailInput.value;

    if (emailValue === '') {
      emailError.style.display = 'none'; // Hide error if empty, required will handle on submit
    } else if (!emailRegex.test(emailValue)) {
      emailError.textContent = 'Please enter a valid email address (e.g. user@example.com)';
      emailError.style.display = 'block';
    } else {
      emailError.style.display = 'none'; // Hide error if valid
    }
  });
</script>


@endsection
