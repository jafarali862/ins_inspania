@extends('dashboard.layout.app')
@section('title', 'Create Template')

@section('content')
    <div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-plus me-2 text-primary"></i> Add Templates
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('templates.list_templates') }}">Templates</a></li>
                    <li class="breadcrumb-item active">Add Templates</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-plus me-2"></i>
                            <h5 class="mb-0" style="color: #fff;">Add Templates</h5>
                            
<div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" style="margin-left: 20px; align-items: center;">
    <i class="fa fa-check-circle me-2"></i>
    <span id="successText"></span>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
                        </div>



                        
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="javascript:history.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                           
                        </div>
                    </div>

                <div class="card">
    <div class="card-header">
        <h5 class="mb-0">Create New Template</h5>
    </div>

    <div class="card-body">
        <!-- Template creation form -->
        <form method="POST" action="{{ route('templates.store_templates') }}" id="tempform" enctype="multipart/form-data">
            @csrf



             <div class="mb-3 mt-3">
        <label for="company_id" class="form-label">Select Company<span class="text-danger">*</span></label>
        <select class="form-select" id="company_id" name="company_id" required>
            <option value="" selected disabled>-- Select Company --</option>
            @foreach($companies as $company)
                <option value="{{ $company->id }}">{{ $company->name }}</option>
            @endforeach
        </select>
          <small class="text-danger error" id="company_id-error" style="font-size: 15px;"></small>

    </div>




     <div class="mb-3">
        <label for="case_type" class="form-label fw-bold">Case Type <span class="text-danger">*</span></label>
        <select class="form-control" id="case_type" name="case_type" required>
            <option value="" disabled selected>Select Type</option>
            <option value="OD">OD</option>
            <option value="MACT">MACT</option>
          
        </select>
        <span id="case_type-error" class="text-danger error"></span>
    </div>



    <div class="mb-3" id="mact_type_container" style="display: none;">
    <label for="mact_type" class="form-label fw-bold">MACT Type </label>
    <select class="form-control" id="mact_type" name="mact_type">
        <option value="" disabled selected>Select MACT Type</option>
        <option value="TPPD">TPPD</option>
        <option value="Death">Death</option>
        <option value="Injury">Injury</option>
    </select>
</div>


            <!-- Nav Tabs -->
          <!-- Case Type Dropdown -->


<!-- Question Tabs -->
<ul class="nav nav-tabs" id="questionTabs" role="tablist">
    @foreach($questions as $category => $group)
        <li class="nav-item" role="presentation">
            <button class="nav-link {{ $loop->first ? 'active' : '' }}"
                id="{{ $category }}-tab"
                data-bs-toggle="tab"
                data-bs-target="#{{ $category }}"
                type="button"
                role="tab"
                aria-controls="{{ $category }}"
                aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                {{ ucfirst(str_replace('_', ' ', $category)) }}
            </button>
        </li>
    @endforeach
</ul>

<div class="tab-content mt-3" id="questionTabsContent">
    @foreach($questions as $category => $group)
        <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}"
             id="{{ $category }}"
             role="tabpanel"
             aria-labelledby="{{ $category }}-tab">
            <div class="row g-0">
                @foreach($group as $question)
                    <div class="col-md-6 question-box"
                         data-case-type="{{ $question->case_type }}"
                         data-category="{{ $category }}"
                         @if($question->case_type === 'MACT' && !empty($question->mact_type))
                             data-mact-type="{{ $question->mact_type }}"
                         @endif>
                        <div class="form-check mb-1">
                            <input class="form-check-input"
                                   type="checkbox"
                                   name="questions[]"
                                   value="{{ $question->id }}"
                                   style="border-color: #424141;"
                                   id="q{{ $question->id }}">
                            <label class="form-check-label" for="q{{ $question->id }}">
                                {{ $question->question }}
                            </label>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endforeach
</div>

 


            
              <div class="mb-3 mt-4">
        <label for="template_logo" class="form-label">Upload Template Logo (Single Image)</label>
        <input type="file" class="form-control" id="template_logo" name="template_logo" accept="image/*" />
    </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">Create Template</button>
            </div>
        </form>
    </div>
</div>



    </div>
    </div>
    </div>
    </div>


    <style>

        /* Remove all padding/gutters inside rows */
#questionTabsContent .row {
    margin-left: 0 !important;
    margin-right: 0 !important;
}

/* Remove padding on columns */
#questionTabsContent .row > [class*='col-'] {
    padding-left: 0 !important;
    padding-right: 0 !important;
}

/* Reduce bottom margin for question boxes */
#questionTabsContent .question-box {
    margin-bottom: 4px !important;
}

/* Reduce margin inside form-check to make questions tighter */
#questionTabsContent .form-check {
    margin-bottom: 2px !important;
}

/* Also, remove bottom padding inside tab-pane */
#questionTabsContent .tab-pane {
    padding-bottom: 0 !important;
}

</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
$(document).ready(function() {
    $('#tempform').on('submit', function(e) {
        e.preventDefault();

        var form = $(this)[0]; // get raw form element
        var formData = new FormData(form);

        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            contentType: false,  // must be false for FormData
            processData: false,  // must be false for FormData
            success: function(response) {
                if (response.success) {
                    $('#successText').text(response.success);
                    $('#successMessage')
                        .removeClass('d-none alert-danger')
                        .addClass('alert alert-success')
                        .fadeIn();

                    $('html, body').animate({
                        scrollTop: $("#successMessage").offset().top - 100
                    }, 500);

                    // Reset form
                    $('#tempform')[0].reset();
                    $('.form-control').removeClass('is-invalid');
                    $('.error').text('');

                    // Redirect after 2.5 seconds
                    setTimeout(function () {
                        window.location.href = response.redirect_url;
                    }, 2500);
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    var errors = xhr.responseJSON.errors;
                    $('.error').text('');
                    $('.form-control').removeClass('is-invalid');
                    $.each(errors, function(key, value) {
                        $('#' + key).addClass('is-invalid');
                        $('#' + key + '-error').text(value[0]);
                    });
                } else {
                    alert('An unexpected error occurred.');
                }
            }
        });
    });
});



document.addEventListener('DOMContentLoaded', function () {
    const companySelect = document.getElementById('company_id');
    const caseTypeSelect = document.getElementById('case_type');
    const mactTypeContainer = document.getElementById('mact_type_container');
    const mactTypeSelect = document.getElementById('mact_type');

    function filterQuestions() {
        const selectedCaseType = caseTypeSelect.value;
        const selectedMactType = mactTypeSelect.value;

        // Hide all question boxes initially
        document.querySelectorAll('.question-box').forEach(box => {
            box.style.display = 'none';
        });

        // If no case type selected, hide all tabs and tab panes
        if (!selectedCaseType) {
            document.querySelectorAll('#questionTabs li.nav-item').forEach(li => {
                li.style.display = 'none';
            });
            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.remove('show', 'active');
            });
            return;
        }

        const matchedCategories = new Set();

        // Show matching question boxes and collect their categories
        document.querySelectorAll('.question-box').forEach(box => {
            const boxCaseType = box.dataset.caseType;
            const boxMactType = box.dataset.mactType || '';

            if (boxCaseType === selectedCaseType) {
                if (selectedCaseType === 'MACT') {
                    if (!selectedMactType || selectedMactType === '' || boxMactType === selectedMactType) {
                        box.style.display = 'block';
                        matchedCategories.add(box.dataset.category);
                    }
                } else {
                    box.style.display = 'block';
                    matchedCategories.add(box.dataset.category);
                }
            }
        });

        // Hide all tab list items and remove active classes from tab panes
        document.querySelectorAll('#questionTabs li.nav-item').forEach(li => {
            li.style.display = 'none';
        });
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('show', 'active');
        });
        document.querySelectorAll('#questionTabs .nav-link').forEach(tab => {
            tab.classList.remove('active');
        });

        // Show only matched tabs and tab panes, activate first one
        let firstActive = true;
        matchedCategories.forEach(category => {
            const tabLi = document.querySelector(`#${category}-tab`).closest('li.nav-item');
            const tabBtn = document.querySelector(`#${category}-tab`);
            const tabPane = document.getElementById(category);

            if (tabLi && tabBtn && tabPane) {
                tabLi.style.display = 'block';

                if (firstActive) {
                    tabBtn.classList.add('active');
                    tabPane.classList.add('show', 'active');
                    firstActive = false;
                } else {
                    tabBtn.classList.remove('active');
                    tabPane.classList.remove('show', 'active');
                }
            }
        });
    }

    companySelect.addEventListener('change', function () {
        if (this.value === '1') {
            caseTypeSelect.value = 'MACT';

            for (let option of caseTypeSelect.options) {
                option.disabled = (option.value === 'OD');
            }

            mactTypeContainer.style.display = 'block';
        } else {
            for (let option of caseTypeSelect.options) {
                option.disabled = false;
            }
            caseTypeSelect.value = '';
            mactTypeContainer.style.display = 'none';
            mactTypeSelect.value = '';
        }
        filterQuestions();
    });

    caseTypeSelect.addEventListener('change', filterQuestions);
    mactTypeSelect.addEventListener('change', filterQuestions);

    // Initialize on page load
    mactTypeContainer.style.display = 'none';
    filterQuestions();

    // **Remove the tab click listener that calls filterQuestions**
    // Bootstrap's JS handles tab switching and active class toggling automatically
});







</script>


@endsection
