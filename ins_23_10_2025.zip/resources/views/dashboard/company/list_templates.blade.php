@extends('dashboard.layout.app')
@section('title', 'List Templates')

@section('content')


<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-clipboard me-2 text-primary"></i> Templates List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Templates</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('templates.create_templates') }}" class="btn btn-primary">
                <i class="fas fa-clipboard me-1"></i> Add Template
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0" style="color: #fff;">Templates List</h5>
            </div>

            <div class="card-body p-0">
                @if($templates->isEmpty())
                    <div class="p-4 text-center text-muted fst-italic">
                        No templates found.
                    </div>
                @else
                    <div class="table-responsive p-3 mb-3">
                        <table id="templatesTable" class="table table-bordered table-hover text-center align-middle mb-0">
    <thead class="thead-dark text-start">
        <tr>
            <th>ID</th>
            <th>Template ID</th>
            <th>Case Type</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($templates as $template)
            <tr>
                <td class="text-start">{{ $loop->iteration }}</td>
                <td class="text-start">{{ $template->template_id }}</td>

                     <td class="text-start">{{ $template->case_type }}</td>

                
                <td class="text-start">
                    <button class="btn btn-sm btn-primary preview-btn" data-id="{{ $template->id }}">
                        <i class="fas fa-eye"></i> 
                    </button>

                    <a href="{{ route('templates.edit_templates', $template->id) }}" class="btn btn-sm btn-info">
                        <i class="fas fa-edit"></i>
                    </a>

                

                    
                                               <button type="button" 
        class="btn btn-sm btn-danger btn-delete" 
        data-bs-toggle="modal" 
        data-bs-target="#deleteModal" 
        data-url="{{ route('templates.destroy_templates', $template->id) }}"
        title="Delete">
    <i class="fa-solid fa-trash-can"></i>
</button>

                </td>
            </tr>
        @endforeach
    </tbody>
</table>

                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title">Template Preview</h5>
                <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close" style="background-color: white;
opacity: unset;"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <!-- Preview content loaded dynamically -->
            </div>
        </div>
    </div>
</div>




<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" id="deleteForm">
      @csrf
      @method('DELETE')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Are you sure you want to delete this templates?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
        </div>
      </div>
    </form>
  </div>
</div>




<style>

.card-header
{
border-bottom: unset;
}
</style>


<script>
document.addEventListener('DOMContentLoaded', function () {
  var deleteModal = document.getElementById('deleteModal');
  var deleteForm = document.getElementById('deleteForm');

  // Attach click event to all delete buttons
  document.querySelectorAll('.btn-delete').forEach(function(button) {
    button.addEventListener('click', function() {
      var url = this.getAttribute('data-url');
      deleteForm.setAttribute('action', url);
    });
  });
});
</script>






<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<style>
@media (max-width: 576px) {
    /* Hide only the Action column header */
    #templatesTable th:nth-child(3) {
        display: none !important;
    }

    /* Hide only the "Action" title in responsive child rows, keep the data visible */
    li[data-dtr-index="3"] > span.dtr-title {
        display: none !important;
    }
}



</style>


<script>
    $(document).ready(function () {
        const table = $('#templatesTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search templates..."
                },
                columnDefs: [
                    { orderable: false, targets: [3] } // Action column (4th column = index 3)
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }
    });
</script>



<script>
// $(document).on("click", ".preview-btn", function () {
//     let templateId = $(this).data("id");
//     let url = "{{ route('templates.preview', ':id') }}".replace(":id", templateId);

//     $("#previewContent").html('<div class="text-center text-muted">Loading...</div>');

//     let modalEl = document.getElementById('previewModal');
//     let modal = new bootstrap.Modal(modalEl);
//     modal.show();

//     $.get(url, function (data) {
//         $("#previewContent").html(data);
//     }).fail(function () {
//         $("#previewContent").html('<div class="text-danger">Error loading preview</div>');
//     });
// });

  $(document).on("click", ".preview-btn", function () {
    let templateId = $(this).data("id");
    let url = "{{ route('templates.download', ':id') }}".replace(":id", templateId);
    window.open(url, '_blank');
  });
 


</script>
@endsection
