@extends('dashboard.layout.app')
@section('title', 'Edit Company')

@section('content')
  <div class="content-page">
    <div class="container-fluid">

        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                     <i class="fa-solid fa-building me-2 text-primary"></i>Edit Company Info
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>

        <!-- Template Edit Form -->
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0" style="color:#fff;">Update Company Info</h5>
                    </div>

                    <div class="card-body">
                        
                        
                    <form action="{{ route('logo.update', $logo->id) }}" method="POST" enctype="multipart/form-data" id="updateUser">
    @csrf
    @method('PUT')

    <div class="mb-3">
        <label for="name" class="form-label fw-bold">Company Name <span class="text-danger">*</span></label>
        <input type="text"
               class="form-control"
               id="name"
               name="name"
               value="{{ old('name', $logo->name) }}"
               placeholder="Enter company name"
               required>
        <span class="text-danger error" id="name-error"></span>
    </div>

    <div class="mb-3">
        <label for="phone" class="form-label fw-bold">Company Phone <span class="text-danger">*</span></label>
        <input type="tel"
               class="form-control"
               id="phone"
               name="phone"
               value="{{ old('phone', $logo->phone) }}"
               placeholder="Enter phone number"
               required>
        <span class="text-danger error" id="phone-error"></span>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label fw-bold">Company Email <span class="text-danger">*</span></label>
        <input type="email"
               class="form-control"
               id="email"
               name="email"
               value="{{ old('email', $logo->email) }}"
               placeholder="Enter email"
               required>
        <span class="text-danger error" id="email-error"></span>
    </div>

   <div class="mb-3">
    <label for="place" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
    <textarea class="form-control" 
    id="place" 
    name="place" 
    rows="3" 
    placeholder="Enter full address" 
    required>{{ old('place', $logo->place) }}</textarea>
    <span class="text-danger error" id="place-error"></span>
    </div>



    <div class="mb-3">
    <label for="logo" class="form-label fw-bold">Select Logo <span class="text-danger">*</span></label>
    <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
    <span class="text-danger error" id="logo-error"></span>

    <!-- Preview before upload -->
    <div class="mt-3">
    <img id="preview-cropped" src="#" class="img-fluid" style="max-width: 100px; display: none;" />
    </div>

    <!-- Display saved image after submit -->
    @if(isset($logo->logo))
    <div class="mt-3" id="existing-logo-wrapper">
    <img src="{{ asset('storage/' . $logo->logo) }}"
    alt="Company Logo"
    class="img-fluid border border-3 border-secondary rounded p-2 shadow-sm bg-white"
    style="max-width: 100px;">

    </div>
    @endif
   </div>


    <div class="mb-3">
    <label for="logo" class="form-label fw-bold">Select Splash Screen Logo <span class="text-danger">*</span></label>
    <input type="file" class="form-control" id="logo_path" name="logo_path"  accept=".png,.jpg,.jpeg,.webp">
    <span class="text-danger error" id="logo_path-error"></span>

    <!-- Preview before upload -->
    <!-- <div class="mt-3">
    <img id="preview-cropped" src="#" class="img-fluid" style="max-width: 100px; display: none;" />
    </div> -->

    <!-- Display saved image after submit -->
    @if(isset($logo->logo_path))
    <div class="mt-3">
    <img src="{{ asset('storage/' . $logo->logo_path) }}"
    alt="Company Logo"
    class="img-fluid border border-3 border-secondary rounded p-2 shadow-sm bg-white"
    style="max-width: 100px;">

    </div>
    @endif
   </div>



    <div class="d-flex justify-content-between">
        <button type="submit" class="btn btn-primary px-4">Update</button>
        <a href="{{ route('logo.edit', ['id' => 1]) }}" class="btn btn-outline-secondary px-4">Cancel</a>
    </div>
</form>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal for cropping -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Crop Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div>
          <img id="image-to-crop" src="" class="img-fluid" />
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" id="cropImageBtn" class="btn btn-primary">Crop & Save</button>
      </div>
    </div>
  </div>
</div>
<style>

  .card-header
{
border-bottom: unset;
}
</style>

<!-- Cropper.js CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" rel="stylesheet" />

<!-- Cropper.js JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<script>
let cropper;
const logoInput = document.getElementById('logo');
const imageToCrop = document.getElementById('image-to-crop');
const preview = document.getElementById('preview-cropped');

logoInput.addEventListener('change', function (e) {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function (event) {
            imageToCrop.src = event.target.result;
            new bootstrap.Modal(document.getElementById('cropModal')).show();
        };
        reader.readAsDataURL(file);
    }
});

document.getElementById('cropModal').addEventListener('shown.bs.modal', function () {
    cropper = new Cropper(imageToCrop, {
        aspectRatio: 1, // Change to 16 / 9 or other if needed
        viewMode: 1,
        autoCropArea: 1,
    });
});

document.getElementById('cropModal').addEventListener('hidden.bs.modal', function () {
    if (cropper) {
        cropper.destroy();
        cropper = null;
    }
});

document.getElementById('cropImageBtn').addEventListener('click', function () {
    const canvas = cropper.getCroppedCanvas({
        width: 500,
        height: 500,
    });

    canvas.toBlob(function (blob) {
        const url = URL.createObjectURL(blob);
        preview.src = url;
        preview.style.display = 'block';

        // Optional: replace file input value with cropped blob (if submitting via AJAX)
        const fileInput = document.getElementById('logo');
        const dataTransfer = new DataTransfer();
        const croppedFile = new File([blob], "cropped_logo.png", { type: "image/png" });
        dataTransfer.items.add(croppedFile);
        fileInput.files = dataTransfer.files;

        bootstrap.Modal.getInstance(document.getElementById('cropModal')).hide();
    });
});
</script>


<script>
    document.getElementById('logo').addEventListener('change', function (event) {
        const preview = document.getElementById('preview-cropped');
        const existingLogo = document.getElementById('existing-logo-wrapper');
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.display = 'block';

                // Hide existing saved logo if it exists
                if (existingLogo) {
                    existingLogo.style.display = 'none';
                }
            };

            reader.readAsDataURL(file);
        } 

        else 
            {    
            preview.style.display = 'none';
            if (existingLogo) {
                existingLogo.style.display = 'block';
            }
        }
    });
</script>

@endsection
