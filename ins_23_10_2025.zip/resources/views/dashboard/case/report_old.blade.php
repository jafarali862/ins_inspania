<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Case Report - Executive #{{ $executive_id }}</title>

    <!-- ✅ Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Optional: Google Fonts / Custom Styling -->
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
        }
        .nav-tabs .nav-link.active {
            font-weight: bold;
            border-bottom: 3px solid #0d6efd;
        }
        .fs-3 {
            font-size: 1.75rem;
        }
        h2 {
            margin-top: 20px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2 class="text-center">Case Report for Executive #{{ $executive_id }}</h2>

        {{-- Tabs --}}
        @php
            $periods = ['daily', 'weekly', 'monthly'];
        @endphp

        <ul class="nav nav-tabs justify-content-center mb-4">
            @foreach ($periods as $p)
                <li class="nav-item">
                    <a class="nav-link {{ $data['period'] === $p ? 'active' : '' }}" 
                       href="{{ route('case.report.view', ['executive_id' => $executive_id, 'period' => $p]) }}">
                        {{ ucfirst($p) }}
                    </a>
                </li>
            @endforeach
        </ul>

        {{-- Report summary --}}
        <div class="text-center mb-3">
            <p><strong>Period:</strong> {{ ucfirst($data['period']) }}</p>
            <p><strong>Start Date:</strong> {{ $data['start_date'] }}</p>
        </div>

        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="alert alert-primary text-center">
                    <h4>New Cases</h4>
                    <p class="fs-3">{{ $data['new'] }}</p>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="alert alert-success text-center">
                    <h4>Completed Cases</h4>
                    <p class="fs-3">{{ $data['completed'] }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ✅ Bootstrap JS Bundle (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
