<div class="container-fluid">
    <div class="row">
        <!-- Left Column -->
        <div class="col-md-6">
            <h5>Customer Name:</h5>
            <p>{{ $customers->name ?? 'N/A' }} ({{ $customers->phone ?? 'N/A' }})</p>

            <h5>Company:</h5>
            <p>{{ $customers->custname ?? 'N/A' }}</p>

            <h5>Crime Number:</h5>
            <p>{{ $customers->crime_number ?? 'N/A' }}</p>

            <h5>Police Station:</h5>
            <p>{{ $customers->police_station ?? 'N/A' }}</p>

            <h5>Executive Name:</h5>
            <p><b>Driver:</b> {{ $customers->driver_name ?? 'N/A' }}</p>
            <p><b>Garage:</b> {{ $customers->garage_name ?? 'N/A' }}</p>
            <p><b>Spot:</b> {{ $customers->spot_name ?? 'N/A' }}</p>
            <p><b>Meeting:</b> {{ $customers->meeting_name ?? 'N/A' }}</p>
            <p><b>Accident:</b> {{ $customers->accident_name ?? 'N/A' }}</p>
        </div>

        <!-- Right Column -->
        <div class="col-md-6">
            <h5>Assign Date:</h5>
            <p>
                {{ $customers->created_at ? \Carbon\Carbon::parse($customers->created_at)->format('d-m-Y') : 'N/A' }}
            </p>

            <h5>Status:</h5>
            <p>
                @if ($customers->case_status == 1)
                    <span class="badge bg-danger">Pending</span>
                @elseif ($customers->case_status == 0)
                    <span class="badge bg-success">Complete</span>
                @elseif ($customers->case_status == 2)
                    <span class="badge bg-warning text-dark">Assigned</span>
                @else
                    <span class="badge bg-secondary">Unknown</span>
                @endif
            </p>

            <h5>Investigation Date:</h5>
            <p>
                {{ $customers->case_date ? \Carbon\Carbon::parse($customers->case_date)->format('d-m-Y') : 'N/A' }}
            </p>

            <h5>Case Type:</h5>
            <p>{{ $customers->insurance_type ?? 'N/A' }}</p>

            <h5>Created Date:</h5>
            <p>
                {{ $customers->created_at ? \Carbon\Carbon::parse($customers->created_at)->format('d-m-Y') : 'N/A' }}
            </p>
        </div>
    </div>
</div>
