@extends('dashboard.layout.app')
@section('title', 'Edit Insurance Customer')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-edit me-2 text-primary"></i> Edit Case
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="">Case</a></li>
                    <li class="breadcrumb-item active">Edit Case</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
        <div class="col-lg-8 col-md-10">
        <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
        <i class="fa fa-user-edit me-2"></i>
        <h5 class="mb-0" style="color:#fff;">Edit Case</h5>

        <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
        style="margin-left: 20px;align-items: center;">
        <i class="fa fa-check-circle me-2"></i>
        <span id="successText"></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
        </div>
        <!-- Action Buttons -->
        <div class="d-flex gap-2">
        <a href="{{ route('user.list') }}" class="btn btn-danger btn-sm">
        <i class="fa fa-arrow-left me-1"></i> Back
        </a>
        <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
        <i class="fa fa-sync me-1"></i> Reload
        </a>
        </div>
        </div>
        <div class="card-body">

              

               <form id="insuranceForm" action="{{ route('case.update', $customerDetails->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <div class="card-body">
        <!-- Company -->
        <div class="mb-3">
            <label for="company" class="form-label fw-bold">Select Company <span class="text-danger">*</span></label>
            <select id="company" name="company" class="form-select2" required>
                <option disabled>Select Company</option>
                @foreach ($companies as $company)
                    <option value="{{ $company->id }}"
                        {{ old('company', $customerDetails->company_id) == $company->id ? 'selected' : '' }}>
                        {{ $company->name }}
                    </option>
                @endforeach
            </select>
            <span id="company-error" class="text-danger error"></span>
        </div>

        <!-- Name -->
        <div class="mb-3">
            <label for="name" class="form-label fw-bold">Name <span class="text-danger">*</span></label>
            <input type="text" id="name" name="name" class="form-control" placeholder="Enter full name" value="{{ old('name', $customerDetails->name) }}" required>
            <span id="name-error" class="text-danger error"></span>
        </div>

        <!-- Father's Name -->
        <div class="mb-3">
            <label for="father_name" class="form-label fw-bold">Father's Name <span class="text-danger">*</span></label>
            <input type="text" id="father_name" name="father_name" class="form-control" placeholder="Enter father's name" value="{{ old('father_name', $customerDetails->father_name) }}" required>
            <span id="father_name-error" class="text-danger error"></span>
        </div>

      


        
@php
use Illuminate\Support\Facades\Http;

// Fetch countries dynamically with SSL verification disabled
$countries = Http::withOptions([
    'verify' => false
])->get('https://restcountries.com/v3.1/all?fields=name,idd,cca2')->json();
@endphp


           <div class="mb-3">
          <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
          <div class="d-flex align-items-center gap-2">
          <!-- Country Code -->
          <select id="country_code" name="country_code" class="select2 form-select form-select-sm" data-placeholder="Code">

           <option value="">Select Country Code</option>
    @foreach($countries as $country)
        @php
            $dialCode = isset($country['idd']['root'], $country['idd']['suffixes'][0]) 
                ? $country['idd']['root'] . $country['idd']['suffixes'][0] 
                : null;
        @endphp

        @if($dialCode)
            <option value="{{ $dialCode }}"
                {{ $dialCode == '+91' ? 'selected' : '' }}>
                {{ $dialCode }} ({{ $country['name']['common'] }})
            </option>
        @endif
    @endforeach


          </select>

          <!-- Phone Number -->
          <input type="text"   class="form-control" 
          id="phone" 
          name="phone" 
          value="{{ old('phone', $customerDetails->phone) }}" 
          placeholder="Enter contact number" 
          required 
          maxlength="15"
          inputmode="numeric"
          oninput="validatePhoneInput(this)">
          </div>
          <div id="phoneError" class="text-danger mt-1" style="display:none;">
          Please enter digits only (0-9).
          </div>
          </div>

        <div class="form-check mb-3">
            <input type="checkbox" id="same_as_phone" class="form-check-input" style="border-color: #6e6868;">
            <label class="form-check-label text-primary" for="same_as_phone">
                Emergency contact number same as phone
            </label>
        </div>

        <!-- Emergency Contact -->
        <div class="mb-3">
            <label for="emergency_contact_number" class="form-label fw-bold">Emergency Contact Number <span class="text-danger">*</span></label>
            <input type="text" id="emergency_contact_number" name="emergency_contact_number" class="form-control" placeholder="Enter emergency contact number" 
            value="{{ old('emergency_contact_number', $customerDetails->emergency_contact_number) }}" required pattern="\d*" 
            inputmode="numeric"
            maxlength="15"
            oninput="this.value = this.value.replace(/[^0-9]/g, '')">
            <span id="emergency_contact_number-error" class="text-danger error"></span>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label fw-bold">Email</label>
            <input type="email" id="email" name="email" class="form-control" placeholder="Enter email address" value="{{ old('email', $customerDetails->email) }}">
            <small id="emailError" style="color: red; display: none;"></small>
        </div>

        <!-- Present Address -->
        <div class="mb-3">
            <label for="present_address" class="form-label fw-bold">Present Address <span class="text-danger">*</span></label>
            <textarea id="present_address" name="present_address" class="form-control" rows="3" placeholder="Enter present address" required>{{ old('present_address', $customerDetails->present_address) }}</textarea>
            <span id="present_address-error" class="text-danger error"></span>
        </div>

        <div class="form-check mb-3">
            <input type="checkbox" id="same_as_present" class="form-check-input" style="border-color: #6e6868;">
            <label class="form-check-label text-primary" for="same_as_present">
                Present address same as permanent address
            </label>
        </div>

        <!-- Permanent Address -->
        <div class="mb-3">
            <label for="permanent_address" class="form-label fw-bold">Permanent Address <span class="text-danger">*</span></label>
            <textarea id="permanent_address" name="permanent_address" class="form-control" rows="3" placeholder="Enter permanent address" required>{{ old('permanent_address', $customerDetails->permanent_address) }}</textarea>
            <span id="permanent_address-error" class="text-danger error"></span>
        </div>

        <!-- Insurance Type -->
        <div class="mb-3">
            <label for="insurance_type" class="form-label fw-bold">Insurance Type <span class="text-danger">*</span></label>
            <input type="text" id="insurance_type" name="insurance_type" class="form-control" placeholder="Enter insurance type" value="{{ old('insurance_type', $customerDetails->insuranceCase->insurance_type ?? '') }}" required>
            <span id="insurance_type-error" class="text-danger error"></span>
        </div>

        <!-- Case Details -->
        <div class="mb-3">
            <label for="case_details" class="form-label fw-bold">Case Details <span class="text-danger">*</span></label>
            <textarea id="case_details" name="case_details" class="form-control" rows="3" placeholder="Enter case details" required>{{ old('case_details', $customerDetails->insuranceCase->case_details ?? '') }}</textarea>
            <span id="case_details-error" class="text-danger error"></span>
        </div>

        <!-- Crime Number -->
        <div class="mb-3">
            <label for="crime_no" class="form-label fw-bold">Crime Number <span class="text-danger">*</span></label>
            <input type="text" id="crime_no" name="crime_no" class="form-control" placeholder="Enter crime number" value="{{ old('crime_no', $customerDetails->crime_number) }}" required>
            <span id="crime_no-error" class="text-danger error"></span>
        </div>

        <!-- Police Station -->
        <div class="mb-3">
            <label for="police_station" class="form-label fw-bold">Police Station <span class="text-danger">*</span></label>
            <input type="text" id="police_station" name="police_station" class="form-control" placeholder="Enter police station" value="{{ old('police_station', $customerDetails->police_station) }}" required>
            <span id="police_station-error" class="text-danger error"></span>
        </div>

        <!-- Policy No -->
        <div class="mb-3">
            <label for="policy_no" class="form-label fw-bold">Policy No <span class="text-danger">*</span></label>
            <input type="text" id="policy_no" name="policy_no" class="form-control" placeholder="Enter policy number" value="{{ old('policy_no', $customerDetails->policy_no) }}" required>
            <span id="policy_no-error" class="text-danger error"></span>
        </div>

        <!-- Policy Dates -->
        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="policy_start" class="form-label fw-bold">Policy Start Date <span class="text-danger">*</span></label>
                <input type="text" id="policy_start" name="policy_start" class="form-control" value="{{ \Carbon\Carbon::parse($customerDetails->policy_start)->format('Y-m-d') }}" required>
            </div>
            <div class="mb-3 col-md-6">
                <label for="policy_end" class="form-label fw-bold">Policy End Date</label>
                <input type="text" id="policy_end" name="policy_end" class="form-control" value="{{ \Carbon\Carbon::parse($customerDetails->policy_end)->format('Y-m-d') }}" required>
            </div>
        </div>

        <!-- Intimation Report -->
        <div class="mb-3">
            <label for="intimation_report" class="form-label fw-bold">Intimation Report</label>
            <input type="file" name="intimation_report" class="form-control">
            @if (!empty($customers->intimation_report))
                <div class="mt-2">
                    <a href="{{ asset('storage/' . $customerDetails->intimation_report) }}" target="_blank">View Existing Report</a>
                </div>
            @endif
        </div>

        <!-- Investigation Type -->
        <div class="mb-3">
            <label for="investigation_type" class="form-label fw-bold">Investigation Type <span class="text-danger">*</span></label>
            <select name="investigation_type" id="investigation_type" class="form-select2" required >
                <option value="OD" {{ old('investigation_type', $customerDetails->insuranceCase->insurance_type ?? '') == 'OD' ? 'selected' : '' }}>OD</option>
                <option value="MACT" {{ old('investigation_type', $customerDetails->insuranceCase->insurance_type ?? '') == 'MACT' ? 'selected' : '' }}>MACT</option>
            </select>
        </div>


    <div class="mb-3" id="mact_type_container" style="display: none;">
    <label for="mact_type" class="form-label fw-bold">MACT Type</label>
    <select class="select2 form-select" id="mact_type" name="mact_type" data-placeholder="Select MACT Type">
        <option></option>
         <option value="TPPD" {{ old('mact_type', $customerDetails->mact_type) == 'TPPD' ? 'selected' : '' }}>TPPD</option>
                <option value="Death" {{ old('mact_type', $customerDetails->mact_type) == 'Death' ? 'selected' : '' }}>Death</option>
                <option value="Injury" {{ old('mact_type', $customerDetails->mact_type) == 'Injury' ? 'selected' : '' }}>Injury</option>
    </select>
</div>

        <!-- Executives -->
        <div class="mb-3">
            <label for="executive_1" class="form-label fw-bold">Default Executive <span class="text-danger">*</span></label>
            <select name="Default_Executive" id="executive_1" class="form-select select2" required>
                <option disabled>Select the executive</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}" {{ $user->id == $customerDetails->caseAssignment->meeting_id ? 'selected' : '' }}>
                        {{ $user->name }} ({{ $user->place }})
                    </option>
                @endforeach
            </select>
        </div>

        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="executive_2" class="form-label fw-bold">Executive (Driver)</label>
                <select name="executive_driver" id="executive_2" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customerDetails->caseAssignment->driver_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3 col-md-6">
                <label for="executive_3" class="form-label fw-bold">Executive (Garage)</label>
                <select name="executive_garage" id="executive_3" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customerDetails->caseAssignment->garage_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="executive_4" class="form-label fw-bold">Executive (Spot)</label>
                <select name="executive_spot" id="executive_4" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customerDetails->caseAssignment->spot_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3 col-md-6">
                <label for="executive_5" class="form-label fw-bold">Executive (Meeting)</label>
                <select name="executive_meeting" id="executive_5" class="form-select">
                    <option disabled>Select the executive</option>
                    @foreach ($users as $user)
                        <option value="{{ $user->id }}" {{ $user->id == $customerDetails->caseAssignment->meeting_id ? 'selected' : '' }}>
                            {{ $user->name }} ({{ $user->place }})
                        </option>
                    @endforeach
                </select>
            </div>
        </div>


        <div class="mb-3">
            <label for="executive_6" class="form-label fw-bold">Executive (Accident Person)</label>
            <select name="executive_accident_person" id="executive_6" class="form-select">
                <option disabled>Select the executive</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}" {{ $user->id == $customerDetails->caseAssignment->accident_id ? 'selected' : '' }}>
                        {{ $user->name }} ({{ $user->place }})
                    </option>
                @endforeach
            </select>
        </div>
      
   

        <!-- Investigation Date -->
        <div class="mb-3">
            <label for="date" class="form-label fw-bold">Investigation Date <span class="text-danger">*</span></label>
            <input type="text" name="date" id="date" class="form-control"   value="{{ \Carbon\Carbon::parse($customerDetails->caseAssignment->case_date)->format('Y-m-d') }}" required>
        </div>

        <!-- Other Details -->
        <div class="mb-3">
            <label for="other" class="form-label fw-bold">Other Details</label>
            <textarea name="other" id="other" class="form-control" rows="4" placeholder="Enter other details">{{ old('other', $customerDetails->caseAssignment->other ?? '') }}</textarea>
        </div>
    </div>

    <!-- Submit -->
    <div class="card-footer text-left">
        <button type="submit" class="btn btn-success">Update Customer</button>
    </div>
</form>

            </div>
        </div>
    </div>
</div>




    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->

@push('styles')
<!-- AdminLTE DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" />
@endpush


<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->



<style>
.card-header
{
border-bottom: unset;
}

   .select2-container--bootstrap4 .select2-selection--single .select2-selection__arrow
    {
        visibility: hidden;
    }




    #country_code.select2-hidden-accessible + .select2-container {
  width: 30% !important;
}

select2-container--bootstrap4 .select2-results__option 
{
    color: #000 !important;
    }

</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Select2 Bootstrap 4 Theme -->
<link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css" rel="stylesheet" />

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
   
    <script>
$('#company').select2({
    theme: 'bootstrap4',
    width: '100%',
    placeholder: $('#company').data('placeholder'),
    allowClear: true,
    tags: true // allows typing new text
});


 $('#mact_type').select2({
      theme: 'bootstrap4', // or 'default' if not using Bootstrap
      width: '100%',
      placeholder: $('#mact_type').data('placeholder'),
      allowClear: true,
      minimumResultsForSearch: 0 // always show search box
    });

 $('#investigation_type').select2({
      theme: 'bootstrap4', // or 'default' if not using Bootstrap
      width: '100%',
      placeholder: $('#investigation_type').data('placeholder'),
      allowClear: true,
      minimumResultsForSearch: 0 // always show search box
    });

  $('#country_code').select2({
        theme: 'bootstrap4',
        width: 'resolve',           // fit the select box container
        placeholder: $('#country_code').data('placeholder'),
        allowClear: true,
        minimumResultsForSearch: 0 // always show search box
    });
    
            // Handle checkbox for emergency contact number
            $('#same_as_phone').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#emergency_contact_number').val($('#phone').val());
                } else {
                    $('#emergency_contact_number').val('');
                }
            });

            // Handle checkbox for addresses
            $('#same_as_present').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#permanent_address').val($('#present_address').val());
                } else {
                    $('#permanent_address').val('');
                }
            });

            // Handle form submission


      $('#insuranceForm').on('submit', function(e) {
    e.preventDefault();

    let form = $(this)[0];
    let formData = new FormData(form);

    $.ajax({
        url: form.action,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            if (response.success) {
                // $('#successMessage').text(response.success).show();

                $('#successMessage')
                .text(response.success)
                .fadeIn();

                // Scroll to the success message
                $('html, body').animate({
                scrollTop: $('#successMessage').offset().top - 100 // adjust offset as needed
                }, 500);

                $('#insuranceForm')[0].reset(); 
                $('.text-danger').text(''); 
                $('#same_as_phone').prop('checked', false); 
                $('#same_as_present').prop('checked', false); 

                if (response.redirect_url) {
                    setTimeout(function() {
                        window.location.href = response.redirect_url;
                    }, 2000);
                }
            }
        },
        error: function(xhr) {
            $('.text-danger').text(''); // Clear previous error messages

            if (xhr.responseJSON && xhr.responseJSON.errors) {
                $.each(xhr.responseJSON.errors, function(key, value) {
                    $('#' + key + '-error').text(value[0]);
                });
            } else if (xhr.responseJSON && xhr.responseJSON.message) {
                alert("Error: " + xhr.responseJSON.message);
            } else {
                alert("An unknown error occurred.");
                console.log(xhr.responseText);
            }
        }
    });
});


            

        
    </script>

    <script>

    // Initialize all select2 fields
    $('#executive_1').select2({
        theme: 'bootstrap4',
        width: '100%',
        placeholder: "Select the executive",
        allowClear: true
    });

    // Listen for change event on Select2-enhanced executive_1
    $('#executive_1').on('change', function () {
        let selectedValue = $(this).val();

        let otherSelects = [
            "#executive_2",
            "#executive_3",
            "#executive_4",
            "#executive_5",
            "#executive_6"
        ];

        otherSelects.forEach(function (selector) {
            let $select = $(selector);
            if ($select.length) {
                $select.val(selectedValue).trigger('change'); // works even if not initialized with select2
            }
        });
    });






 document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#date", {
        allowInput: false,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("date").value // use DB value
    });
});

 document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#policy_start", {
        allowInput: false,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("policy_start").value // use DB value
    });
});



 document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#policy_end", {
        allowInput: false,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("policy_end").value // use DB value
    });
});

function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }

</script>


 <script>
  const emailInput = document.getElementById('email');
  const emailError = document.getElementById('emailError');

  // Simple regex for email validation (basic)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  emailInput.addEventListener('input', function() {
    const emailValue = emailInput.value;

    if (emailValue === '') {
      emailError.style.display = 'none'; // Hide error if empty, required will handle on submit
    } else if (!emailRegex.test(emailValue)) {
      emailError.textContent = 'Please enter a valid email address (e.g. user@example.com)';
      emailError.style.display = 'block';
    } else {
      emailError.style.display = 'none'; // Hide error if valid
    }
  });
</script>

<script>
  
        const companySelect = $('#company');
        const investigationTypeSelect = $('#investigation_type');
        const mactTypeContainer = $('#mact_type_container');
        const mactTypeSelect = $('#mact_type');

        // Initialize Select2 for both dropdowns
       

        function handleCompanyChange() {
            const companyId = companySelect.val();

            if (companyId === '1') {
                // Set investigation type to MACT if not already
                if (investigationTypeSelect.val() !== 'MACT') {
                    investigationTypeSelect.val('MACT').trigger('change');
                }
            } else {
                // Reset investigation type
                // investigationTypeSelect.val('').trigger('change');
            }
        }

        function handleInvestigationTypeChange() {
        const companyId = companySelect.val();
        const investigationType = investigationTypeSelect.val();

        if (investigationType === 'MACT' && companyId === '1') {
        mactTypeContainer.show();
        } else {
        mactTypeContainer.hide();
        mactTypeSelect.val('').trigger('change'); // optional: reset selection
        }
        }


        // Bind change events
        companySelect.on('change', handleCompanyChange);
        investigationTypeSelect.on('change', handleInvestigationTypeChange);

        // ✅ Run only after Select2 is fully initialized
        // Handles cases where company is pre-selected (e.g. from server-side form)
        setTimeout(() => {
            handleCompanyChange();
            handleInvestigationTypeChange();
        }, 0);

</script>

@endsection
