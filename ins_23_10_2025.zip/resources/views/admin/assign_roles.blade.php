
<div class="container">
    <h1>Assign Roles & Permissions</h1>

    @if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    <form action="{{ route('admin.assign_roles') }}" method="POST">
        @csrf

        <div>
            <label>User</label>
            <select name="user_id" required>
                <option value="">Select User</option>
                @foreach($users as $user)
                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label>Role</label>
            <select name="role_id" id="role_id" required>
                <option value="">Select Role</option>
                @foreach($roles as $role)
                    <option value="{{ $role->id }}">{{ $role->name }}</option>
                @endforeach
            </select>
        </div>

        <h3>Permissions (Menus)</h3>
        <ul style="list-style: none; padding-left: 0;">
            @foreach ($permissions as $permission)
                <li>
                    <input type="checkbox" name="permissions[]" value="{{ $permission->id }}" id="perm_{{ $permission->id }}">
                    <label for="perm_{{ $permission->id }}"><strong>{{ $permission->name }}</strong></label>

                    @if($permission->children->count())
                        <ul style="list-style: none; padding-left: 20px;">
                            @foreach($permission->children as $child)
                                <li>
                                    <input type="checkbox" name="permissions[]" value="{{ $child->id }}" id="perm_{{ $child->id }}">
                                    <label for="perm_{{ $child->id }}">{{ $child->name }}</label>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </li>
            @endforeach
        </ul>

        <button type="submit">Assign</button>
    </form>
</div>

