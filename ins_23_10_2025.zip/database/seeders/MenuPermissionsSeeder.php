<?php

// database/seeders/MenuPermissionsSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class MenuPermissionsSeeder extends Seeder
{
    public function run()
    {
        $menus = [
            'dashboard.view',
            'users.view',
            'users.add',
            'users.edit',
            'companies.view',
            'companies.add',
            'companies.edit',
            'cases.view',
            'cases.add',
            'cases.edit',
            'reports.view',
            'approvals.manage',
            'odometer.view',
            'company.management',
        ];

        foreach ($menus as $menu) {
            Permission::firstOrCreate(['name' => $menu]);
        }
    }
}


