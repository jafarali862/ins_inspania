<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\OauthAccessToken;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\PasswordResetRequest;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
    $search = strtolower($request->input('search', ''));
    $status = $request->input('status', 1);
    $role = null;

    if ($search === 'executive') {
    $role = 3;
    } elseif ($search === 'sub admin') {
    $role = 2;
    }

    $users = User::query()
    ->when($search, function ($query) use ($search, $role) {
        $query->where(function ($q) use ($search, $role) {
            $q->where('name', 'like', '%' . $search . '%')
                ->orWhere('email', 'like', '%' . $search . '%');

            if (!is_null($role)) {
                $q->orWhere('role', $role);
            }
        });
    })
    ->where('status', $status)
    ->where('role', '!=', 1)
    ->orderBy('id', 'desc') // 👈 Add this line

    ->get(); // ✅ Fetch all results, no pagination

    return view("dashboard.user.index")->with([
    "users" => $users,
    "status" => $status,
    ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("dashboard.user.create");
    }

    /**
     * Store a newly created resource in storage.
     */


public function store(Request $request)
{
    try {
        // Validate the request
        $validated = $request->validate([
            "name" => ["required", "string", "max:100", "regex:/^[a-zA-Z\s]+$/"], // Only letters and spaces
            'email' => 'required|email:rfc,dns|unique:users,email',
            "password" => "required|string|min:6",
            "phone" => "required|unique:users,phone",
            "place" => "required|string|max:255",
            "role" => "required|integer", // assuming role is integer, adjust if needed
            "blood" => "required|string|max:10",
            "address" => "required|string|max:1000",
            "date_of_birth" => "required|date",  // Use date validation instead of string
            "join_date" => "required|date",      // Use date validation instead of string
            "country_code" => "required|string|max:10",
            "profile_picture" => "nullable|image|mimes:jpeg,png,jpg|max:2048", // max 2MB size
        ]);

        $profilePicturePath = null;
        if ($request->hasFile('profile_picture')) {
            $profilePicturePath = $request->file('profile_picture')->store('uploads', 'public');
        }

        // Create the user
        User::create([
            "name" => $validated['name'],
            "email" => $validated['email'],
            "phone" => $validated['phone'],
            "place" => $validated['place'],
            "password" => Hash::make($validated['password']),
            "role" => $validated['role'],
            "status" => 1,
            "create_by" => Auth::id(),
            "update_by" => Auth::id(),
            "blood" => $validated['blood'],
            "address" => $validated['address'],
            "country_code" => $validated['country_code'],
            "date_of_birth" => $validated['date_of_birth'],
            "join_date" => $validated['join_date'],
            "profile_image" => $profilePicturePath,
        ]);

        return response()->json([
            'success' => 'User added successfully',
            'redirect_url' => route('user.list')
        ], 201);

    } catch (\Illuminate\Validation\ValidationException $ve) {
        // Return validation errors as JSON response
        return response()->json([
            'errors' => $ve->errors()
        ], 422);

    } catch (\Exception $e) {
        Log::error('Error storing user: ' . $e->getMessage(), [
            'stack' => $e->getTraceAsString(),
            'input' => $request->all()
        ]);

        return response()->json([
            'error' => 'Failed to add user. Please try again later.'
        ], 500);
    }
}


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */


public function edit(string $id)
{
    try {
        $user = User::findOrFail($id); // Better: findOrFail will throw ModelNotFoundException if not found
        
        return view("dashboard.user.edit")->with("user", $user);

    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        // User not found
        return redirect()->route('user.list')->with('error', 'User not found.');

    } catch (\Exception $e) {
        // Log unexpected errors
        Log::error('Error fetching user for edit: '.$e->getMessage());

        return redirect()->route('user.list')->with('error', 'An unexpected error occurred.');
    }
}


   public function userActiveChange(Request $request)
{
    try {
        $request->validate([
            'id' => 'required|integer|exists:users,id',
            'action' => 'required|string|in:activate,deactivate',
        ]);

        $user = User::findOrFail($request->id);
        $status = $request->action === 'activate' ? 1 : 0;
        $user->update(['status' => $status]);

        return response()->json(['message' => 'User status updated successfully']);
    } catch (\Illuminate\Validation\ValidationException $e) {
        // Handle validation errors
        return response()->json(['error' => 'Validation failed', 'details' => $e->errors()], 422);
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        // Handle the case when user is not found
        return response()->json(['error' => 'User not found'], 404);
    } catch (\Exception $e) {
        // Handle any other exceptions
        return response()->json(['error' => 'Something went wrong', 'message' => $e->getMessage()], 500);
    }
}


    public function approval(Request $request)
    {
        $users = User::where('login_request', 1)->get();
        return view('dashboard.user.approval')->with('users', $users);
    }

  

    public function approve($id)
{
    try {
        $updated = User::where('id', $id)->update(['login_request' => 0]);

        if ($updated) {
            return redirect()->back()->with('success', 'Approved Successfully');
        } else {
            return redirect()->back()->with('error', 'User not found or already approved');
        }
    } catch (\Exception $e) {
        Log::error('Approval failed for user ID ' . $id . ': ' . $e->getMessage());
        return redirect()->back()->with('error', 'Something went wrong during approval.');
    }
}



    /**
     * Update the specified resource in storage.
     */
  
public function update(Request $request)
{
    try {
        $request->validate([
            "id" => "required|exists:users,id", // Ensure the user exists
            "name" => "required|string|max:255",
            "phone" => "required|string|max:20",
            'email' => 'required|email',
            "password" => "nullable|string|min:6",
            "role" => "required|string",
            "status2" => "required",
            "blood" => "required|string|max:10",
            "address" => "required|string|max:1000",    
            "date_of_birth" => "required|string",
            "join_date" => "required|string",
            "country_code" => "nullable|string",
            "profile_picture" => "nullable|image|mimes:jpeg,png,jpg",
        ], [
            'blood.max' => 'The blood group is required',
        ]);

        // Prepare data
        $data = [
            "name" => $request->name,
            "phone" => $request->phone,
            "email" => $request->email,
            "role" => $request->role,
            "status" => $request->status2,
            "blood" => $request->blood,
            "address" => $request->address,
            "country_code" => $request->country_code,
            "date_of_birth" => $request->date_of_birth,
            "join_date" => $request->join_date,
            // "update_by" => auth()->id(),
        ];

        // Update password only if provided
        if (!empty($request->password)) {
            $data['password'] = Hash::make($request->password);
        }

        // Handle profile picture upload
        if ($request->hasFile('profile_picture')) {
            $profilePicturePath = $request->file('profile_picture')->store('uploads', 'public');
            $data['profile_image'] = $profilePicturePath;
        }

        // Update the user
        User::where('id', $request->id)->update($data);

        return response()->json([
            'success' => 'User updated successfully',
            'redirect_url' => route('user.list'),
        ]);
    } catch (\Illuminate\Validation\ValidationException $e) {
        // Return validation errors
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Exception $e) {
        // Log the error
        Log::error('User update failed for user ID ' . $request->id . ': ' . $e->getMessage());

        // Return generic error message
        return response()->json([
            'error' => 'Failed to update user. Please try again later.'
        ], 500);
    }
}




public function block(Request $request, $id)
{
    $request->validate([
        'block_reason' => 'required|string|max:500',
    ]);

    try {
        DB::transaction(function () use ($id, $request) {
            // Update user status and block reason
            $user = User::findOrFail($id);
            $user->status = 0;
            $user->block_reason = $request->input('block_reason');
            $user->updated_at = now();
            $user->save();

            // Revoke all access tokens for this user
            OauthAccessToken::where('user_id', $id)->update(['revoked' => 1]);
        });

        return redirect()->back()->with('success', 'User has been blocked successfully.');
    } catch (\Exception $e) {
        Log::error("Failed to block user ID {$id}: " . $e->getMessage());
        return redirect()->back()->with('error', 'Failed to block user. Please try again later.');
    }
}





public function unblock($id)
{
    try {
        DB::transaction(function () use ($id) {
            // Update user status to 1 (unblocked)
            $user = User::findOrFail($id);
            $user->status = 1;
            $user->save();

            // Un-revoke all access tokens for this user
            OauthAccessToken::where('user_id', $id)->update([
                'revoked' => 0,
            ]);
        });

        return redirect()->back()->with('success', 'User has been unblocked successfully');
    } catch (\Exception $e) {
        Log::error("Failed to unblock user ID {$id}: " . $e->getMessage());
        return redirect()->back()->with('error', 'Failed to unblock user. Please try again later.');
    }
}




    // public function passwordResetRequest(Request $request)
    // {
    //     $requests = DB::table('password_reset_requests')
    //         ->leftJoin('users', 'users.id', '=', 'password_reset_requests.user_id')
    //         ->select('password_reset_requests.*', 'users.name as user_name')
    //         ->where('password_reset_requests.status', 1)
    //         ->orderBy('password_reset_requests.created_at', 'desc')
    //         ->paginate(10);

    //     return view('dashboard.password-reset.index')->with(['requests' => $requests]);
    // }


    // public function passwordResetEdit(Request $request, $id)
    // {
    //     $requestData = DB::table('password_reset_requests')
    //         ->leftJoin('users', 'users.id', '=', 'password_reset_requests.user_id')
    //         ->select('password_reset_requests.*', 'users.name as user_name')
    //         ->where('password_reset_requests.id', $id)
    //         ->first();

    //     if (!$requestData) {
    //         return redirect()->route('dashboard.password-reset.index')->with('error', 'Request not found.');
    //     }

    //     return view('dashboard.password-reset.edit', ['request' => $requestData]);
    // }

    // public function passwordResetUpdate(Request $request, $id)
    // {
    //     $request->validate([
    //         'user_id' => 'required',
    //         'new_password' => 'required|confirmed',
    //     ]);

    //     $user = User::find($request->user_id);

    //     if (!$user) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'User not found.'
    //         ], 404);
    //     }

    //     $user->password = Hash::make($request->new_password);
    //     $user->save();

    //     PasswordResetRequest::where('id', $id)->update(['status' => 0]);

    //     foreach ($user->tokens as $token) {
    //         $token->revoke();
    //     }

    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Password updated successfully.'
    //     ]);
    // }

    // public function passwordResetReject(Request $request, $id)
    // {
    //     PasswordResetRequest::where('id', $id)->update(['status' => 2]);

    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Request reject success'
    //     ]);
    // }

    // public function allPasswordRestRequest()
    // {
    //     $all_request = DB::table('password_reset_requests')
    //         ->leftJoin('users', 'users.id', '=', 'password_reset_requests.user_id')
    //         ->select('password_reset_requests.*', 'users.name as user_name')
    //         ->orderBy('password_reset_requests.created_at', 'desc')
    //         ->paginate(10);
    //     return view('dashboard.password-reset.all')->with(['data' => $all_request]);
    // }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
