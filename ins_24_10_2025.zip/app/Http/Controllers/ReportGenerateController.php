<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\User;
use App\Models\AssignWorkData;
use App\Models\GarageData;
use App\Models\DriverData;
use App\Models\AccidentPersonData;
use App\Models\OwnerData;
use App\Models\Template;
use App\Models\CaseAssignment;
use App\Models\SpotData;
use App\Models\SelectedGarageAnswer;
use App\Models\FinalReportNew;
use App\Models\FinalReport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ReportGenerateController extends Controller
{

   public function requestReport(Request $request)
{
    try {
        $search = $request->input('search', '');
        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        $query = AssignWorkData::with([
            'caseAssignment.customer',
            'caseAssignment.company',
            'questionnaireSubmissions' => function ($q) use ($fromDate, $toDate) {
                if ($fromDate && $toDate) {
                    $q->whereBetween('created_at', [
                        Carbon::parse($fromDate)->startOfDay(),
                        Carbon::parse($toDate)->endOfDay()
                    ]);
                }
            }
        ]);

        if (!empty($search)) {
            $query->whereHas('caseAssignment.customer', function ($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%');
            })->orWhereHas('caseAssignment.company', function ($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%');
            })->orWhereHas('caseAssignment', function ($q) use ($search) {
                $q->where('date', 'like', '%' . $search . '%')
                  ->orWhere('type', 'like', '%' . $search . '%');
            });
        }

        // Get latest AssignWorkData per case_id
        // Using subquery to get max id per case_id
        $subQuery = AssignWorkData::selectRaw('MAX(id) as max_id')
            ->groupBy('case_id');

        $query->whereIn('id', $subQuery->pluck('max_id'));

        $reports = $query->orderBy('id', 'desc')->paginate(10);

        return view('dashboard.report.report-request', compact('reports', 'fromDate', 'toDate', 'search'));
        
    } catch (\Exception $e) {
        Log::error('Error fetching report request:', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTraceAsString(),
        ]);
        return back()->withErrors('Failed to fetch reports.');
    }
}


     public function download($id)
    {

   $template = Template::findOrFail($id);

    if (!$template->template_pdf || !Storage::disk('public')->exists($template->template_pdf)) {
        abort(404, 'PDF not found');
    }

    $path = storage_path('app/public/' . $template->template_pdf);
    $filename = basename($template->template_pdf);

    // ✅ Use response()->file() instead of response()->stream()
    // Laravel automatically handles correct headers and Content-Length
    return response()->file($path, [
        'Content-Type' => 'application/pdf',
        'Content-Disposition' => 'inline; filename="' . $filename . '"',
    ]);
    }


public function requestReportView($id, Request $request)
{
    try {
        // Load report with related data
        $report = AssignWorkData::with([
            'caseAssignment.customer',
            'caseAssignment.company'
        ])->findOrFail($id);

        // Fetch related garage data with executive name (user)
        $garageData = GarageData::with('executive')
            ->where('assign_work_id', $id)
            ->orderByDesc('updated_at')
            ->get()
            ->unique('updated_at')
            ->values();

        // Fetch other datasets with executive user eager loaded
        $driverData = DriverData::with('executive')
            ->where('assign_work_id', $id)
            ->orderByDesc('updated_at')
            ->get();

        $spotData = SpotData::with('executive')
            ->where('assign_work_id', $id)
            ->orderByDesc('updated_at')
            ->get();

        $ownerData = OwnerData::with('executive')
            ->where('assign_work_id', $id)
            ->orderByDesc('updated_at')
            ->get();

        $accidentPersonData = AccidentPersonData::with('executive')
            ->where('assign_work_id', $id)
            ->orderByDesc('updated_at')
            ->get();

        // Questions by category
        $garageQuestions = Question::where('data_category', 'garage_data')->get();
        $driverQuestions = Question::where('data_category', 'driver_data')->get();
        $spotQuestions = Question::where('data_category', 'spot_data')->get();
        $ownerQuestions = Question::where('data_category', 'owner_data')->get();
        $accidentQuestions = Question::where('data_category', 'accident_person_data')->get();

        // Selected garage answers for this case
        $selectedGarageAnswers = SelectedGarageAnswer::where('case_id', $report->caseAssignment->id)
            ->get(['garage_id', 'column_name']);

        // Users excluding role 1 and status 0
        $users = User::where('role', '!=', 1)
            ->where('status', '!=', 0)
            ->get();

        return view('dashboard.report.view', compact(
            'report',
            'garageData',
            'driverData',
            'spotData',
            'ownerData',
            'accidentPersonData',
            'garageQuestions',
            'driverQuestions',
            'spotQuestions',
            'ownerQuestions',
            'accidentQuestions',
            'users',
            'selectedGarageAnswers'
        ));
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        Log::warning("AssignWorkData with ID {$id} not found: " . $e->getMessage());
        return redirect()->route('request.report')->with('error', 'Report not found.');
    } catch (\Exception $e) {
        Log::error('Error loading request report view:', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTraceAsString(),
        ]);
        return redirect()->route('request.report')->with('error', 'An unexpected error occurred while loading the report.');
    }
}



    public function generateReport($template)
    {

    // $questions = DB::table('questions')->get();

    $questions = DB::table('questions')
    ->join('question_template', 'questions.id', '=', 'question_template.question_id')
    ->where('question_template.template_id', $template)
    ->get();

    // $answers = [
    //     'claim_no' => '3125311391',
    //     'name_of_insured' => 'MR. ADARSH T',
    //     'insureds_address_contact_no' => 'HARINANDANAM, PALNIRAPPU, NALLLA P.O, VTC NEDUMPANA.',
    //     'vehicle_no' => 'KL02BX2070',

    // ];

        $answers = [
        'registration_no' => 'KL-44-C-2882',
        'claim_no' => '3125311391',
        'name_of_insured' => 'MR. ADARSH T',
        'insureds_address_contact_no' => 'HARINANDANAM, PALNIRAPPU, NALLLA P.O, VTC NEDUMPANA.',
        'vehicle_no' => 'KL02BX2070',
        'engine_no_chassis_no_model_make_etc' => [
        'Engine No' => 'DXEZ407198',
        'Chassis No' => 'MB1PBE7C9DEXL2232',
        'Make & Model' => 'ASOK LEYLAND BUS',
        ]
];

$templateFile = resource_path("views/templates/template{$template}.html");

if (!file_exists($templateFile)) {
    abort(404, "Template {$template} not found.");
}

$html = file_get_contents($templateFile);

// === Check what kind of template this is ===
if (strpos($html, '<tr #questions>') !== false) {
    // ==== FLAT TABLE TEMPLATE (Type 1) ====

    $rows = '';
    foreach ($questions as $question) {
        $q = $question->question;
        $a = $answers[$question->column_name] ?? 'N/A';
        $rows .= "<tr><td>{$q}</td><td>{$a}</td></tr>";
    }

    $html = str_replace('<tr #questions>', $rows, $html);

} 
else 
{

   $grouped = $questions->groupBy('group_category');

// foreach ($grouped as $category => $group) {
//     $rows = '';
//     $i = 1;

//     foreach ($group as $question) {
//         $q = $question->question;
//         $a = $answers[$question->column_name] ?? 'N/A';
//         $rows .= "<tr>
//                     <td>{$i}</td>
//                     <td>{$q}</td>
//                     <td>{$a}</td>
//                   </tr>";
//         $i++;
//     }

//     $html = str_replace("<tr #{$category}></tr>", $rows, $html);
// }


foreach ($grouped as $category => $group) {
    $rows = '';
    $i = 1;

    foreach ($group as $question) {
        $q = $question->question;
        $a = $answers[$question->column_name] ?? 'N/A';

        // Nested answer logic
       if (is_array($a)) {
            $nested = '<table border="1" width="100%">';
            foreach ($a as $label => $value) {
                $nested .= "<tr><td>{$label}</td><td>{$value}</td></tr>";
            }
            $nested .= '</table>';
            $a = $nested;
        }

        $rows .= "<tr>
                    <td>{$i}</td>
                    <td>{$q}</td>
                    <td>{$a}</td>
                  </tr>";
        $i++;
    }

    // Inject into HTML
    $html = str_replace("<tr #{$category}></tr>", $rows, $html);
}

foreach ($questions as $question) {
    $column = $question->column_name;
    $q = $question->question;
    $a = $answers[$column] ?? 'N/A';

    if (is_array($a)) {
        $nested = '<table border="1" width="100%">';
        foreach ($a as $label => $value) {
            $nested .= "<tr><td>{$label}</td><td>{$value}</td></tr>";
        }
        $nested .= '</table>';
        $a = $nested;
    }

    $row = "<tr>
                <td>1</td>
                <td>{$q}</td>
                <td>{$a}</td>
            </tr>";

    // Replace only if placeholder exists in the HTML
    $html = str_replace("<tr #{$column}></tr>", $row, $html);
}


} 
return response($html);

    }


public function garageReAssign(Request $request)
{
    $request->validate([
        'id' => 'required|integer|exists:assign_work_data,id',
        'executive_id' => 'required|integer|exists:users,id',
    ]);

    $assignWorkId = $request->id;
    $executiveId = $request->executive_id;

    DB::beginTransaction();

    try {
        $assignWork = AssignWorkData::findOrFail($assignWorkId);

        $caseAssignment = CaseAssignment::find($assignWork->case_id);
        if (!$caseAssignment) {
            throw new \Exception("CaseAssignment not found for case_id {$assignWork->case_id}");
        }

        // Update assign_work_data
        $assignWork->garage_reassign_status = 0;
        $assignWork->updated_at = Carbon::now();
        $assignWork->save();

        // Update garage_data rows linked to assign_work_id
        GarageData::where('assign_work_id', $assignWorkId)
            ->update([
                'executive_id' => $executiveId,
                'updated_at' => Carbon::now(),
            ]);

        // Update case_assignments
        $caseAssignment->executive_garage = $executiveId;
        $caseAssignment->updated_at = Carbon::now();
        $caseAssignment->save();

        DB::commit();

        return back()->with('success', 'Garage reassigned successfully.');
    } catch (\Exception $e) {
        DB::rollBack();
        Log::error('Garage reassignment failed', [
            'assign_work_id' => $assignWorkId,
            'executive_id' => $executiveId,
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);
        return back()->withErrors(['error' => 'Reassignment failed: ' . $e->getMessage()]);
    }
}




public function driverReAssign(Request $request)
{
    $request->validate([
        'id' => 'required|integer|exists:assign_work_data,id',
        'executive_id' => 'required|integer|exists:users,id',
    ]);

    $assignWorkId = $request->id;
    $executiveId = $request->executive_id;

    DB::beginTransaction();

    try {
        // Find assign work data model
        $assignWork = AssignWorkData::findOrFail($assignWorkId);
        
        // Get related case assignment
        $caseAssignment = CaseAssignment::findOrFail($assignWork->case_id);

        // Update assign work data status
        $assignWork->driver_reassign_status = 0;
        $assignWork->updated_at = Carbon::now();
        $assignWork->save();

        // Update all related driver data rows for this assign work
        DriverData::where('assign_work_id', $assignWorkId)
            ->update([
                'executive_id' => $executiveId,
                'updated_at' => Carbon::now(),
            ]);

        // Update executive_driver in case assignments
        $caseAssignment->executive_driver = $executiveId;
        $caseAssignment->updated_at = Carbon::now();
        $caseAssignment->save();

        DB::commit();

        Log::info("Driver reassigned successfully", [
            'assign_work_id' => $assignWorkId,
            'executive_id' => $executiveId,
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->with('success', 'Driver reassigned successfully.');
    } catch (\Exception $e) {
        DB::rollBack();

        Log::error('Driver reassignment failed', [
            'assign_work_id' => $assignWorkId ?? null,
            'executive_id' => $executiveId ?? null,
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->withErrors(['error' => 'Reassignment failed: ' . $e->getMessage()]);
    }
}



public function spotReAssign(Request $request)
{
    $request->validate([
        'id' => 'required|integer|exists:assign_work_data,id',
        'executive_id' => 'required|integer|exists:users,id',
    ]);

    $assignWorkId = $request->id;
    $executiveId = $request->executive_id;

    DB::beginTransaction();

    try {
        // Retrieve AssignWorkData model instance
        $assignWork = AssignWorkData::findOrFail($assignWorkId);

        // Retrieve associated CaseAssignment model instance
        $caseAssignment = CaseAssignment::findOrFail($assignWork->case_id);

        // Update spot reassignment status on assign work data
        $assignWork->spot_reassign_status = 0;
        $assignWork->updated_at = Carbon::now();
        $assignWork->save();

        // Update executive_id on related spot_data rows
        SpotData::where('assign_work_id', $assignWorkId)
            ->update([
                'executive_id' => $executiveId,
                'updated_at' => Carbon::now(),
            ]);

        // Update executive_spot on case assignment
        $caseAssignment->executive_spot = $executiveId;
        $caseAssignment->updated_at = Carbon::now();
        $caseAssignment->save();

        DB::commit();

        Log::info('Spot reassigned successfully', [
            'assign_work_id' => $assignWorkId,
            'executive_id' => $executiveId,
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->with('success', 'Spot reassigned successfully.');
    } catch (\Exception $e) {
        DB::rollBack();

        Log::error('Spot reassignment failed', [
            'assign_work_id' => $assignWorkId ?? null,
            'executive_id' => $executiveId ?? null,
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->withErrors(['error' => 'Reassignment failed: ' . $e->getMessage()]);
    }
}


public function ownerReAssign(Request $request)
{
    $request->validate([
        'id' => 'required|integer|exists:assign_work_data,id',
        'executive_id' => 'required|integer|exists:users,id',
    ]);

    $assignWorkId = $request->id;
    $executiveId = $request->executive_id;

    DB::beginTransaction();

    try {
        // Fetch AssignWorkData model
        $assignWork = AssignWorkData::findOrFail($assignWorkId);

        // Fetch related CaseAssignment model
        $caseAssignment = CaseAssignment::findOrFail($assignWork->case_id);

        // Update owner reassignment status
        $assignWork->owner_reassign_status = 0;
        $assignWork->updated_at = Carbon::now();
        $assignWork->save();

        // Update executive_id in owner_data for this assign work
        OwnerData::where('assign_work_id', $assignWorkId)
            ->update([
                'executive_id' => $executiveId,
                'updated_at' => Carbon::now(),
            ]);

        // Update executive_meeting in case_assignments
        $caseAssignment->executive_meeting = $executiveId;
        $caseAssignment->updated_at = Carbon::now();
        $caseAssignment->save();

        DB::commit();

        Log::info('Owner reassigned successfully', [
            'assign_work_id' => $assignWorkId,
            'executive_id' => $executiveId,
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->with('success', 'Owner reassigned successfully.');
    } catch (\Exception $e) {
        DB::rollBack();

        Log::error('Owner reassignment failed', [
            'assign_work_id' => $assignWorkId ?? null,
            'executive_id' => $executiveId ?? null,
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->withErrors(['error' => 'Reassignment failed: ' . $e->getMessage()]);
    }
}

   
public function accidentPersonReAssign(Request $request)
{
    $request->validate([
        'id' => 'required|integer|exists:assign_work_data,id',
        'executive_id' => 'required|integer|exists:users,id',
    ]);

    $assignWorkId = $request->id;
    $executiveId = $request->executive_id;

    DB::beginTransaction();

    try {
        // Fetch AssignWorkData model
        $assignWork = AssignWorkData::findOrFail($assignWorkId);

        // Fetch related CaseAssignment model
        $caseAssignment = CaseAssignment::findOrFail($assignWork->case_id);

        // Update reassignment status
        $assignWork->accident_person_reassign_status = 0;
        $assignWork->updated_at = Carbon::now();
        $assignWork->save();

        // Update executive_id in accident_person_data for this assign work
        AccidentPersonData::where('assign_work_id', $assignWorkId)
            ->update([
                'executive_id' => $executiveId,
                'updated_at' => Carbon::now(),
            ]);

        // Update executive_accident_person in case_assignments
        $caseAssignment->executive_accident_person = $executiveId;
        $caseAssignment->updated_at = Carbon::now();
        $caseAssignment->save();

        DB::commit();

        Log::info('Accident Person reassigned successfully', [
            'assign_work_id' => $assignWorkId,
            'executive_id' => $executiveId,
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->with('success', 'Accident Persons reassigned successfully.');
    } catch (\Exception $e) {
        DB::rollBack();

        Log::error('Accident Person reassignment failed', [
            'assign_work_id' => $assignWorkId ?? null,
            'executive_id' => $executiveId ?? null,
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'timestamp' => Carbon::now()->toDateTimeString(),
        ]);

        return back()->withErrors(['error' => 'Reassignment failed: ' . $e->getMessage()]);
    }
}




public function saveSelected(Request $request)
{
    $request->validate([
        'case_id' => 'required|integer',
        'column_name' => 'required|string',
        'value' => 'required|string',
        'garage_id' => 'required|integer',
        'is_checked' => 'required|boolean',
    ]);

    $caseId = $request->case_id;
    $column = $request->column_name;
    $value = trim($request->value);
    $garageId = $request->garage_id;
    $isChecked = $request->is_checked;

    $mediaExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'mp3', 'wav', 'ogg', 'mp4', 'm4a', 'aac'];
    // $mediaBaseUrl = 'https://insurance.niveosys.org/storage/';

    $mediaBaseUrl = asset('storage') . '/';


    $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
    if (in_array($extension, $mediaExtensions)) {
        if (Str::startsWith($value, $mediaBaseUrl)) {
            $value = Str::replaceFirst($mediaBaseUrl, '', $value);
        }
        $finalValue = json_encode([$value]);
    } else {
        $finalValue = $value;
    }

    $tables = [
        'final_reports_new' =>  FinalReportNew::class,
        'final_reports' =>      FinalReport::class,
    ];

    DB::beginTransaction();

    try {
        foreach ($tables as $tableName => $modelClass) {

            if (!Schema::hasTable($tableName)) {
                Log::warning("Table {$tableName} does not exist.");
                continue;
            }

            if (!Schema::hasColumn($tableName, $column)) {
                Schema::table($tableName, function (Blueprint $table) use ($column) {
                    $table->string($column, 255)->nullable()->after('case_id');
                });
                Log::info("Added column '{$column}' to table '{$tableName}'.");
            }

            // Use Eloquent to find or create
            $record = $modelClass::where('case_id', $caseId)->first();

            // Update case_status in insurance_cases via related case_assignment
            $caseAssignment = CaseAssignment::find($caseId);
            if ($caseAssignment) {
                $insuranceCase = $caseAssignment->insuranceCase; // assuming relation named insuranceCase
                if ($insuranceCase) {
                    $insuranceCase->case_status = 0;
                    $insuranceCase->save();
                }
            }

            if ($record) {
                $record->$column = $finalValue;
                $record->updated_at = Carbon::now();
                $record->save();

                Log::info("Updated {$column} for case_id {$caseId} in table {$tableName}.");
            } else {
                $modelClass::create([
                    'case_id' => $caseId,
                    $column => $finalValue,
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now()
                ]);
                Log::info("Inserted new record for case_id {$caseId} in table {$tableName} with column {$column}.");
            }
        }

        // SelectedGarageAnswer model usage
        if ($isChecked) {
            SelectedGarageAnswer::updateOrCreate(
                [
                    'case_id' => $caseId,
                    'garage_id' => $garageId,
                    'column_name' => $column,
                ],
                [
                    'updated_at' => Carbon::now(),
                    'created_at' => Carbon::now(), // for new record
                ]
            );
            Log::info("Inserted/Updated selected_garage_answers for case_id {$caseId}, garage_id {$garageId}, column {$column}.");
        } else {
           SelectedGarageAnswer::where('case_id', $caseId)
                ->where('garage_id', $garageId)
                ->where('column_name', $column)
                ->delete();
            Log::info("Deleted selected_garage_answers for case_id {$caseId}, garage_id {$garageId}, column {$column}.");
        }

        DB::commit();

        return response()->json([
            'data' => [
                'status' => 200,
                'message' => 'Answer saved successfully in all relevant tables.'
            ]
        ], 200);

    } catch (\Exception $e) {
        DB::rollBack();

        Log::error('Error saving owner selection: ' . $e->getMessage(), [
            'case_id' => $caseId,
            'column_name' => $column,
            'garage_id' => $garageId,
            'is_checked' => $isChecked,
            'trace' => $e->getTraceAsString()
        ]);

        return response()->json([
            'error' => 'Error saving owner selection: ' . $e->getMessage(),
        ], 500);
    }
}


}
