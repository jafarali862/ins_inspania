<?php
namespace App\Http\Controllers;

use PDF;
use Exception;
use App\Models\FinalReport;
use App\Models\Question;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;


class FinalReportController extends Controller
{
    /**
     * Display a listing of the resource.
     */

 


    public function index(Request $request)
    {
    $search = $request->input('search', '');
    $from = $request->input('from_date');
    $to = $request->input('to_date');

    $reports = FinalReport::with([
        'caseAssignment.company',
        'caseAssignment.customer',
        'caseAssignment.driver',
        'caseAssignment.garage',
        'caseAssignment.spot',
        'caseAssignment.meeting',
        'caseAssignment.accidentPerson'
    ])
    ->when($search, function ($query, $search) {
        $query->whereHas('caseAssignment.company', function ($q) use ($search) {
            $q->where('name', 'like', "%{$search}%");
        })->orWhereHas('caseAssignment.customer', function ($q) use ($search) {
            $q->where('name', 'like', "%{$search}%");
        })->orWhereHas('caseAssignment', function ($q) use ($search) {
            $q->where('date', 'like', "%{$search}%")
                ->orWhere('type', 'like', "%{$search}%");
        });
    })
    ->when($from && $to, function ($query) use ($from, $to) {
        try {
            $fromFormatted = Carbon::parse($from)->startOfDay();
            $toFormatted = Carbon::parse($to)->endOfDay();
            $query->whereBetween('updated_at', [$fromFormatted, $toFormatted]);
        } catch (\Exception $e) {
            // Log or handle the exception if needed
        }
    })
    ->orderByDesc('case_id')
    ->paginate(10);

    return view('dashboard.final-report.index', [
        'reports' => $reports,
        'from' => $from,
        'to' => $to
    ]);
    }



    /**
     * Show the form for creating a new resource.
     */
    public function createFinalPdfDownload(Request $request)
    {
        try {


        $reportId = $request->report_id;

        // $finalReport = FinalReport::with([
        // 'caseAssignment.company:id,name,template',
        // 'caseAssignment.company.template:id,company_id,template_logo',
        // 'caseAssignment.driver:id,name',
        // 'caseAssignment.garage:id,name',
        // 'caseAssignment.spot:id,name',
        // 'caseAssignment.meeting:id,name',
        // 'caseAssignment.accidentPerson:id,name',
        // 'caseAssignment.template:id,company_id,template_logo',
        // ])->findOrFail($reportId);


        $finalReport = FinalReport::with([
        'caseAssignment.company:id,name,template',
        'caseAssignment.company.templateRelation:id,company_id,template_logo',
        'caseAssignment.driver:id,name',
        'caseAssignment.garage:id,name',
        'caseAssignment.spot:id,name',
        'caseAssignment.meeting:id,name',
        'caseAssignment.accidentPerson:id,name',
        ])->findOrFail($reportId);

                                      
        $questions12 = Question::all()->keyBy('unique_key');
        $questions   = Question::where('data_category', 'garage_data')->get();
        $questions_2 = Question::where('data_category', 'spot_data')->get();
        $questions_3 = Question::where('data_category', 'driver_data')->get();
        $questions_4 = Question::where('data_category', 'owner_data')->get();
        $questions_5 = Question::where('data_category', 'accident_person_data')->get();


            $validQuestions12 = $questions12->filter(function ($question) 
            {
            return Schema::hasColumn('final_reports', $question->column_name);
            });

            $validQuestions = $questions->filter(function ($question) 
            {
            return Schema::hasColumn('final_reports', $question->column_name);
            });

            $validQuestions_2 = $questions_2->filter(function ($question2) 
            {
            return Schema::hasColumn('final_reports', $question2->column_name);
            });

             $validQuestions_3 = $questions_3->filter(function ($question3) 
            {
            return Schema::hasColumn('final_reports', $question3->column_name);
            });


            $validQuestions_4 = $questions_4->filter(function ($question4) 
            {
            return Schema::hasColumn('final_reports', $question4->column_name);
            });
           
            $validQuestions_5 = $questions_5->filter(function ($question5) 
            {
            return Schema::hasColumn('final_reports', $question5->column_name);
            });

            // $templateNo = $finalReport->template;
            $templateNo = $finalReport->caseAssignment->company->template; 


            switch ($templateNo) 
            {
                case 1:
                    $pdf = PDF::loadView('dashboard.pdf.pdf1', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 2:
                    $pdf = PDF::loadView('dashboard.pdf.pdf2', compact('finalReport', 'validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 3:
                    $pdf = PDF::loadView('dashboard.pdf.pdf3', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 4:
                    $pdf = PDF::loadView('dashboard.pdf.pdf4', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 5:
                    $pdf = PDF::loadView('dashboard.pdf.pdf5', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 6:
                    $pdf = PDF::loadView('dashboard.pdf.pdf6', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 7:
                    $pdf = PDF::loadView('dashboard.pdf.pdf7', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                case 8:
                    $pdf = PDF::loadView('dashboard.pdf.pdf8', compact('finalReport','validQuestions12','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
                    break;
                default:
                    // return response()->json(['error' => 'Invalid template number'], 400);
                    $pdf = PDF::loadView('dashboard.pdf.pdf', compact('finalReport','validQuestions','validQuestions_2','validQuestions_3','validQuestions_4','validQuestions_5'));
            }


            return response()->stream(function () use ($pdf) 
            {
                echo $pdf->output();
            }, 200, [
                "Content-Type" => "application/pdf",
                "Content-Disposition" => "attachment; filename=insurance.pdf",
            ]);
        } 

        catch (Exception $e) 
        {
            Log::error('Error finding in pdf: ' . $e->getMessage());
        }
    }

   
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }


}
