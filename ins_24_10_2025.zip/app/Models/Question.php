<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Question extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'question',
        'input_type',
        'data_category',
        'column_name',
        'unique_key',
        'file_type',
        'case_type',
        'mact_type',
        'group_category'
    
    ];

    public function templates()
    {
    return $this->belongsToMany(Template::class, 'question_template');
    }


}
