<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\InsuranceCustomer;
use Illuminate\Database\Eloquent\SoftDeletes;
class InsuranceCompany extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $fillable = ["company_id","name","contact_person","email","phone","address",'template',
    "status","selected_tabs","questionnaires","create_by","update_by","country_code"];


    protected $casts = ['selected_tabs' => 'array','questionnaires' => 'array'];

    public function customers()
    {
        return $this->hasMany(InsuranceCustomer::class, 'company_id');
    }


    // public function templateModel()
    // {
    // return $this->hasOne(Template::class, 'company_id', 'id');
    // }


     // public function template()
    // {
    //     return $this->hasOne(Template::class, 'company_id');
    // }

   // ✅ Rename this method
   
    public function templateRelation()
    {
    return $this->hasOne(Template::class, 'company_id', 'id');
    }


}
