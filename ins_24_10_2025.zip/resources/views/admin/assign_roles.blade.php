@extends('dashboard.layout.app')
@section('title', 'Create Template')

@section('content')
<div class="container">
    <h1 style="margin-bottom: 20px;">Assign Permissions to Role</h1>

    @if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    {{-- Select Role --}}
    <form action="{{ route('admin.assign_roles') }}" method="GET" style="margin-bottom: 20px;">
       <div class="row">
    <div class="col-md-6">
        <label>Role</label>
        <select name="role_id" onchange="this.form.submit()" class="form-control" style="border-color:#9390908c;">
            <option value="">Select Role</option>
            @foreach($roles as $role)
                <option value="{{ $role->id }}" {{ (isset($selectedRole) && $selectedRole->id == $role->id) ? 'selected' : '' }}>
                    {{ $role->name }}
                </option>
            @endforeach
        </select>
    </div>
</div>

    </form>

    @if(isset($selectedRole))
    <form action="{{ route('admin.assign_roles') }}" method="POST">
        @csrf

        {{-- Hidden role id --}}
        <input type="hidden" name="role_id" value="{{ $selectedRole->id }}">

        {{-- Permissions --}}
        <h3 class="mb-3">Permissions (Menus)</h3>
        <ul style="list-style: none; padding-left: 0;">
            @foreach ($permissions as $permission)
                <li style="margin-bottom: 10px;">
                    {{-- Parent Menu --}}
                    <input type="checkbox" style="border-color:#5c5959;"
                           name="permissions[]"
                           value="{{ $permission->id }}"
                           id="perm_{{ $permission->id }}"
                           class="form-check-input me-2"
                           {{ in_array($permission->id, $assignedPermissions) ? 'checked' : '' }}>
                    <label for="perm_{{ $permission->id }}" class="fw-bold">{{ $permission->name }}</label>

                    {{-- Submenus --}}
                    @if($permission->children->count())
                        <ul style="list-style: none; padding-left: 25px; margin-top: 8px;">
                            @foreach($permission->children as $child)
                                <li style="margin-bottom: 6px;">
                                    <input type="checkbox" style="border-color:#5c5959;"
                                           name="permissions[]"
                                           value="{{ $child->id }}"
                                           id="perm_{{ $child->id }}"
                                           class="form-check-input me-2"
                                           {{ in_array($child->id, $assignedPermissions) ? 'checked' : '' }}>
                                    <label for="perm_{{ $child->id }}">{{ $child->name }}</label>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </li>
            @endforeach
        </ul>

        <button type="submit" class="btn btn-primary">Assign / Update</button>
    </form>
    @endif
</div>
@endsection