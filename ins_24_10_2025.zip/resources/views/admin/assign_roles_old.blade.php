<div class="container">
    <h1>Assign Roles & Permissions</h1>

    @if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    {{-- Select User --}}
    <form action="{{ route('admin.assign_roles') }}" method="GET" style="margin-bottom: 20px;">
        <label>User</label>
        <select name="user_id" onchange="this.form.submit()">
            <option value="">Select User</option>
            @foreach($users as $user)
                <option value="{{ $user->id }}" {{ (isset($selectedUser) && $selectedUser->id == $user->id) ? 'selected' : '' }}>
                    {{ $user->name }}
                </option>
            @endforeach
        </select>
    </form>

    @if(isset($selectedUser))
    <form action="{{ route('admin.assign_roles') }}" method="POST">
        @csrf

        {{-- Hidden user id --}}
        <input type="hidden" name="user_id" value="{{ $selectedUser->id }}">

        {{-- Role selection --}}
        <div>
            <label>Role</label>
            <select name="role_id" id="role_id" required>
                <option value="">Select Role</option>
                @foreach($roles as $role)
                    <option value="{{ $role->id }}" {{ ($assignedRoleId == $role->id) ? 'selected' : '' }}>
                        {{ $role->name }}
                    </option>
                @endforeach
            </select>
        </div>

        {{-- Permissions --}}
        <h3 class="mb-3">Permissions (Menus)</h3>
        <ul style="list-style: none; padding-left: 0;">
            @foreach ($permissions as $permission)
                <li style="margin-bottom: 10px;">
                    {{-- Parent Menu --}}
                    <input type="checkbox"
                           name="permissions[]"
                           value="{{ $permission->id }}"
                           id="perm_{{ $permission->id }}"
                           class="form-check-input me-2"
                           {{ in_array($permission->id, $assignedPermissions) ? 'checked' : '' }}>
                    <label for="perm_{{ $permission->id }}" class="fw-bold">{{ $permission->name }}</label>

                    {{-- Submenus --}}
                    @if($permission->children->count())
                        <ul style="list-style: none; padding-left: 25px; margin-top: 8px;">
                            @foreach($permission->children as $child)
                                <li style="margin-bottom: 6px;">
                                    <input type="checkbox"
                                           name="permissions[]"
                                           value="{{ $child->id }}"
                                           id="perm_{{ $child->id }}"
                                           class="form-check-input me-2"
                                           {{ in_array($child->id, $assignedPermissions) ? 'checked' : '' }}>
                                    <label for="perm_{{ $child->id }}">{{ $child->name }}</label>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </li>
            @endforeach
        </ul>

        <button type="submit">Assign / Update</button>
    </form>
    @endif
</div>
