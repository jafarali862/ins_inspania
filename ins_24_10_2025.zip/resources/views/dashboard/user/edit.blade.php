@extends('dashboard.layout.app')
@section('title', 'Edit User')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-user-edit me-2 text-primary"></i> Edit User
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('user.list') }}">Users</a></li>
                    <li class="breadcrumb-item active">Edit User</li>
                </ol>
            </div>
        </div>

        <!-- User Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-user-edit me-2"></i>
                            <h5 class="mb-0" style="color:#fff;">Edit User</h5>

                             <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
        style="margin-left: 20px;align-items: center;">
        <i class="fa fa-check-circle me-2"></i>
        <span id="successText"></span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
        
                        </div>
                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <a href="{{ route('user.list') }}" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a>
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                        </div>
                    </div>
                    <div class="card-body">

                      

                        <!-- Edit User Form -->
                        <form id="updateUser" action="{{ route('user.update') }}" method="POST" novalidate enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $user->id }}">

                            <!-- Name -->
                            <div class="mb-3">
                                <label for="name" class="form-label fw-bold">Name <span class="text-danger">*</span></label>
                                <input type="text" id="name" name="name" 
                                       class="form-control" 
                                       value="{{ old('name', $user->name) }}" 
                                       placeholder="Enter name" required>
                                <span class="text-danger error" id="name-error"></span>
                            </div>

                            <!-- Phone -->

              
@php
use Illuminate\Support\Facades\Http;

// Fetch countries dynamically with SSL verification disabled
$countries = Http::withOptions([
    'verify' => false
])->get('https://restcountries.com/v3.1/all?fields=name,idd,cca2')->json();
@endphp




                <div class="mb-3">
                <label for="phone" class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                <div class="d-flex align-items-center gap-2">
                <!-- Country Code -->
                <select id="country_code" name="country_code" class="select2 form-select form-select-sm" data-placeholder="Code">
                <option value="">Select Country Code</option>
    @foreach($countries as $country)
        @php
            $dialCode = isset($country['idd']['root'], $country['idd']['suffixes'][0]) 
                ? $country['idd']['root'] . $country['idd']['suffixes'][0] 
                : null;
        @endphp

        @if($dialCode)
            <option value="{{ $dialCode }}"
                {{ $dialCode == '+91' ? 'selected' : '' }}>
                {{ $dialCode }} ({{ $country['name']['common'] }})
            </option>
        @endif
    @endforeach
                </select>

                <!-- Phone Number -->
                <input type="text"   class="form-control" 
                id="phone" 
                name="phone" 
                value="{{ old('phone', $user->phone) }}" 
                placeholder="Enter contact number" 
                required 
                maxlength="15"
                inputmode="numeric"
                oninput="validatePhoneInput(this)">
                </div>
                <div id="phoneError" class="text-danger mt-1" style="display:none;">
                Please enter digits only (0-9).
                </div>
                </div>

                            <!-- Email -->
                            <div class="mb-3">
                                <label for="email" class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                                <input type="email" id="email" name="email" 
                                       class="form-control" 
                                       value="{{ old('email', $user->email) }}" 
                                       placeholder="Enter email" required>
                               <small id="emailError" style="color: red; display: none;"></small>
                        <span class="text-danger error" id="email-error"></span>

                               </div>


                            <!-- Place -->
                        <div class="mb-3">
                        <label for="place" class="form-label fw-bold">Place <span class="text-danger">*</span></label>
                        <input type="text" 
                        class="form-control" 
                        id="place" 
                        name="place" 
                        value="{{ old('place', $user->place) }}"
                        placeholder="Enter place" 
                        required>
                         <span class="text-danger error" id="place-error"></span>
                        </div>


                        <div class="mb-3">
                        <label for="blood" class="form-label fw-bold">Blood Group <span class="text-danger">*</span></label>
                         <select class="form-select"  id="blood" name="blood" required>
                        <option>-- Select Blood Group --</option>
                        <option value="A+" {{ old('blood', $user->blood) == 'A+' ? 'selected' : '' }}>A+</option>
                        <option value="A-" {{ old('blood', $user->blood) == 'A-' ? 'selected' : '' }}>A-</option>
                        <option value="B+" {{ old('blood', $user->blood) == 'B+' ? 'selected' : '' }}>B+</option>
                        <option value="B-" {{ old('blood', $user->blood) == 'B-' ? 'selected' : '' }}>B-</option>
                        <option value="O+" {{ old('blood', $user->blood) == 'O+' ? 'selected' : '' }}>O+</option>
                        <option value="O-" {{ old('blood', $user->blood) == 'O-' ? 'selected' : '' }}>O-</option>
                        <option value="AB+" {{ old('blood', $user->blood) == 'AB+' ? 'selected' : '' }}>AB+</option>
                        <option value="AB-" {{ old('blood', $user->blood) == 'AB-' ? 'selected' : '' }}>AB-</option>
                        </select>
                        <span class="text-danger error" id="blood-error"></span>
                        </div>



                      


<div class="mb-3">
    <label for="date_of_birth" class="form-label fw-bold">
        Date of Birth <span class="text-danger">*</span>
    </label>
 <input type="text"
    class="form-control"
    id="date_of_birth"
    name="date_of_birth"
      value="{{ \Carbon\Carbon::parse($user->date_of_birth)->format('Y-m-d') }}"
    required>


    <span id="date_of_birth-error" class="text-danger error"></span>
</div>

<div class="mb-3">
    <label for="join_date" class="form-label fw-bold">Joining Date 
<span class="text-danger">*</span></label>
    <input type="text"
        class="form-control"
        id="join_date"
        name="join_date"
        value="{{ \Carbon\Carbon::parse($user->join_date)->format('Y-m-d') }}"

        required>
    <span id="join_date-error" class="text-danger error"></span>
</div>




                        <div class="mb-3">
                        <label for="address" class="form-label fw-bold">Address <span class="text-danger">*</span></label>
                        <textarea class="form-control" 
                        id="address" 
                        name="address" 
                        rows="3" 
                        placeholder="Enter full address" 
                        required>{{ old('address', $user->address) }}</textarea>
                        <span class="text-danger error" id="address-error"></span>
                        </div>


                        <div class="mb-3">
                        <label for="profile_picture" class="form-label fw-bold">Profile Picture</label>
                        <input type="file" 
                        class="form-control" 
                        id="profile_picture" 
                        name="profile_picture" 
                        accept="image/*">
                        <span class="text-danger error" id="profile_picture-error"></span>



                        @if($user->profile_image)
                        <div class="mt-2">
                        <img src="{{ asset('storage/' . $user->profile_image) }}" 
                        alt="Profile Picture" 
                        width="100" 
                        class="img-thumbnail">
                        </div>
                        @endif
                        </div>




                            <!-- Role -->
                            <div class="mb-3">
                                <label for="role" class="form-label fw-bold">Role <span class="text-danger">*</span></label>
                                <select id="role" name="role" class="form-select" required>
                                    <option value="2" {{ old('role', $user->role) == 2 ? 'selected' : '' }}>Sub Admin</option>
                                    <option value="3" {{ old('role', $user->role) == 3 ? 'selected' : '' }}>Executive</option>
                                </select>
                            </div>

                            <!-- Status -->
                            <div class="mb-3">
                                <label for="status2" class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                                <select id="status2" name="status2" class="form-select" required>
                                    <option value="1" {{ old('status2', $user->status) == 1 ? 'selected' : '' }}>Active</option>
                                    <option value="0" {{ old('status2', $user->status) == 0 ? 'selected' : '' }}>Inactive</option>
                                </select>
                            </div>

                            <!-- Password -->
                            <div class="mb-3">
                                <label for="password" class="form-label fw-bold">Password</label>
                                <input type="password" id="password" name="password" 
                                       class="form-control" placeholder="Leave blank to keep current password">
                                 <div id="password-strength" class="mt-2"></div>
                            </div>

                            <!-- Buttons -->
                            <div class="d-flex justify-content-between">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-save me-1"></i> Update User
                                </button>
                                <a href="{{ route('user.list') }}" class="btn btn-secondary">
                                    <i class="fa fa-times me-1"></i> Cancel
                                </a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Select2 Bootstrap 4 Theme -->
<link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css" rel="stylesheet" />

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<link rel="stylesheet" href="{{ asset('assets/plugins/daterangepicker/daterangepicker.css')}}" type="text/css">



<style>
    .select2-container
    {
width:281.547px !important;
    }

    .card-header
{
border-bottom: unset;
}



 select2-container--bootstrap4 .select2-results__option 
{
    color: #000 !important;
    }

      .select2-container--bootstrap4 .select2-selection--single .select2-selection__arrow
    {
        visibility: hidden;
    }

    </style>



<script>

  $('#country_code').select2({
        theme: 'bootstrap4',
        width: 'resolve',           // fit the select box container
        placeholder: $('#country_code').data('placeholder'),
        allowClear: true,
        minimumResultsForSearch: 0 // always show search box
    });
$('#role').select2({
        theme: 'bootstrap4',
        width: 'resolve',           // fit the select box container
        placeholder: $('#role').data('placeholder'),
        allowClear: true,
        minimumResultsForSearch: 0 // always show search box
    });

 $('#blood').select2({
        theme: 'bootstrap4',
        width: 'resolve',           // fit the select box container
        placeholder: $('#blood').data('placeholder'),
        allowClear: true,
        minimumResultsForSearch: 0 // always show search box
    });

document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#join_date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("join_date").value // use DB value
    });
});


document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#date_of_birth", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("date_of_birth").value // use DB value
    });
});




       $(function () {
    $('#updateUser').on('submit', function (e) {
        e.preventDefault();

        let formData = new FormData(this); // 👈 Enables file + input support

        $.ajax({
            url: '{{ route('user.update', $user->id) }}', // Include user ID in route
            method: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            cache: false,

            success: function (response) {
                if (response.success) {
                    $('#successMessage')
                        .removeClass('d-none alert-danger')
                        .addClass('alert alert-success')
                        .fadeIn();
                    $('#successText').text(response.success);
                    $('html, body').animate({
                        scrollTop: $("#successMessage").offset().top - 100
                    }, 500);

                    // Reset the form if needed
                    $('.form-control').removeClass('is-invalid');
                    $('.error').text('');

                    setTimeout(function () {
                        window.location.href = response.redirect_url;
                    }, 2500);
                }
            },

            error: function (xhr) {
                if (xhr.status === 422) {
                    var errors = xhr.responseJSON.errors;

                    $('.text-danger').text('');
                    $('.form-control').removeClass('is-invalid');

                    $.each(errors, function (key, val) {
                        $('#' + key).addClass('is-invalid');
                        $('#' + key + '-error').text(val[0]);
                    });
                }
            }
        });
    });
});


  function validatePhoneInput(input) {
    // Remove any non-digit characters
    const cleanedValue = input.value.replace(/[^0-9]/g, '');
    if (input.value !== cleanedValue) {
      // Show error message
      document.getElementById('phoneError').style.display = 'block';
      input.value = cleanedValue;
    } else {
      // Hide error message
      document.getElementById('phoneError').style.display = 'none';
    }
  }

</script>


<script>
  const emailInput = document.getElementById('email');
  const emailError = document.getElementById('emailError');

  // Simple regex for email validation (basic)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  emailInput.addEventListener('input', function() {
    const emailValue = emailInput.value;

    if (emailValue === '') {
      emailError.style.display = 'none'; // Hide error if empty, required will handle on submit
    } else if (!emailRegex.test(emailValue)) {
      emailError.textContent = 'Please enter a valid email address (e.g. user@example.com)';
      emailError.style.display = 'block';
    } else {
      emailError.style.display = 'none'; // Hide error if valid
    }
  });
</script>




<script>
    const passwordInput = document.getElementById('password');
    const strengthDisplay = document.getElementById('password-strength');

    passwordInput.addEventListener('input', function () {
        const password = passwordInput.value;
        let strength = '';
        let strengthClass = '';

        if (password.length === 0) {
            strengthDisplay.textContent = '';
            strengthDisplay.className = '';
            return;
        }

        const strongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?#&])[A-Za-z\d@$!%*?#&]{8,}$/;
        const mediumPassword = /^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*\d))|((?=.*[A-Z])(?=.*\d)))(?=.{6,})/;

        if (strongPassword.test(password)) {
            strength = 'Strong';
            strengthClass = 'text-success';
        } else if (mediumPassword.test(password)) {
            strength = 'Medium';
            strengthClass = 'text-warning';
        } else {
            strength = 'Weak';
            strengthClass = 'text-danger';
        }

        strengthDisplay.textContent = `Password Strength: ${strength}`;
        strengthDisplay.className = `mt-2 fw-bold ${strengthClass}`;
    });
</script>


@endsection
