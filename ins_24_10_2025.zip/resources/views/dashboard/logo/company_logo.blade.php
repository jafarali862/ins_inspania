@extends('dashboard.layout.app')
@section('title', 'Add User')
@section('content')

    @if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    @if($errors->any())
        <div style="color: red;">
            @foreach($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

        <div class="container-fluid">
        <div class="text-right">
            <button class="btn btn-danger mr-2 mb-2" onclick="window.history.back()"><i class="fa fa-arrow-left" aria-hidden="true"></i></button>
            <button class="btn btn-warning mr-2 mb-2" onclick="window.location.reload()"><i class="fa fa-spinner" aria-hidden="true"></i></button>
            {{-- <a href="{{ route('logo.list') }}" class="btn btn-primary mr-2 mb-2">
                <i class="fa fa-users" aria-hidden="true"></i>
            </a>             --}}
        </div>
        <div class="row">
            <div class="col-md-8 offset-md-2 shadow border">


    <form action="{{ route('company.logo.upload') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label for="logo">Select Logo:</label>
        <input type="file" name="logo" id="logo" accept=".png,.jpg,.jpeg,.webp" required>

        <button type="submit">Upload</button>
    </form>

    @if(isset($logoPath))
        <h3>Current Logo:</h3>
        <img src="{{ Storage::url($logoPath) }}" alt="Company Logo"  width="128" height="128">
    @endif
            </div>
        </div>

@endsection
