<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;

        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center; margin-top: 20px;">
    <div style="border: 1px solid; border-radius: 10px; width: 200px; padding: 10px; text-align: center;">
        
        @if($template->template_logo)
            <img src="{{ public_path('storage/' . $template->template_logo) }}" 
                 alt="Company Logo" 
                 style="max-width: 150px; height: auto; margin-bottom: 10px;">
        @endif

      

            

                        <p style="font-size: 20px; margin-top: 10px;text-align:center;display:flex;">
        {{$template->insurance_com_name}}
             </p>
                </div>
            </div>

            <hr>
            <h2 style="text-align: center;"> INVESTIGATION REPORT:</h2>
            <h3>1. INTRODUCTION</h3>

  <table>

                <tr>
                    <td>1.</td>
                    <td>Name of Customer</td>
                    <td>Babu</td>
                </tr>
                 <tr>
            <td>2.</td>
            <td>Contact Details of Customer</td>
            <td>9961242550</td>
        </tr>

          <tr>
            <td>3.</td>
            <td>Permanent Adress</td>
            <td>Adress Here</td>
        </tr>

          <tr>
            <td>4.</td>
            <td>Policy No</td>
            <td>1234456</td>
        </tr>

        
          <tr>
            <td>5.</td>
            <td>Crime Number</td>
            <td>123/2025</td>
        </tr>

          <tr>
            <td>6.</td>
            <td>Police police_station</td>
            <td>Kasargod</td>
        </tr>

          <tr>
            <td>7.</td>
            <td>Case Type</td>
            <td>OD<</td>
        </tr>

          <tr>
            <td>8.</td>
            <td>Investigation Date</td>
            <td>2025-07-08</td>
        </tr>

            </table>

            <h3>II. CASE/CLAIM DETAILS:</h3>

      

                 {{-- Group questions by data_category --}}
        @php
            $groupedQuestions = $questions->groupBy('data_category');
            $counter = 1;
        @endphp

        @foreach($groupedQuestions as $category => $categoryQuestions)
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <tr>
                    <th colspan="3" style="text-align: center; background-color: yellow; padding: 10px;">
                        {{ strtoupper(str_replace('_', ' ', $category)) }}
                    </th>
                </tr>

                @foreach($categoryQuestions as $question)
                    @if($question->file_type !== 'image')
                        <tr>
                            <td style="width: 30px; border: 1px solid #000;">{{ $counter++ }}.</td>
                            <td style="width: 300px; border: 1px solid #000;"><strong>{{ $question->question }}</strong></td>
                            <td style="border: 1px solid #000;">
                                @php
                                    $value = $finalReport->{$question->column_name} ?? null;
                                @endphp

                                @if($question->input_type === 'text')
                                    {{ $value ?? 'Sample text answer' }}
                                @elseif($question->input_type === 'select')
                                    {{ $value == 1 ? 'Yes' : 'No' }}
                                @elseif($question->input_type === 'date')
                                    {{ $value ? \Carbon\Carbon::parse($value)->format('d-m-Y') : '05-08-2025' }}
                                @elseif($question->input_type === 'textarea')
                                    {{ $value ?? 'Sample Text Description' }}
                                @else
                                    N/A
                                @endif
                            </td>
                        </tr>
                    @endif
                @endforeach
            </table>
        @endforeach
         
            <!-- <hr> -->
            <br>
           


       

            <div style="display: flex; justify-content: space-between;">
                 <div>Executive Name:Executive8</div>
        <div>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}

        </div>
            </div>



                 {{-- Image Questions --}}
        @php $imageCounter = 1; @endphp
           @foreach($questions as $question1)
            @if($question1->file_type === 'image')
                <div style="margin-top: 30px; text-align: center;">
                    <p><strong>{{ $imageCounter++ }}. {{ $question1->question }}</strong></p>
                    <img src="{{ public_path('storage/uploads/0sGvZo9McMzP978qZBOdmH0mXM13aS2SYSHrUY3y.jpg') }}"
                         alt="Image">
                </div>
            @endif
        @endforeach

        </div>
        </div>

</body>

</html>