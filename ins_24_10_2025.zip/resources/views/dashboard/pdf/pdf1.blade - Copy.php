<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New india tvm report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            width: 50%;
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center;">
        <div>
            <div style="text-align: end;">
                <img src="image.png">
            </div>


            <table>
                <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                        <p style="font-size: 25;">Investigation Report -{{$finalReport->insurance_com_name}}</p>
                    </th>
                </tr>
                <tr>
                    <td>Name of Customer</td>
                    <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td>Contact Details of Customer</td>
                    <td><br>{{ $finalReport->customer_present_address ?? 'N/A' }}<br/>
                   
                        <br>Phone no:{{ $finalReport->customer_phone ?? 'N/A' }} <br>Email: {{ $finalReport->customer_email ?? 'N/A' }}
                    </td>
                </tr>

                 <tr>
                    <td>Policy Date</td>
                    <td>       
                    {{ $finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A' }} - 

                    {{ $finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A' }}
                    </td>
                </tr>


                 <tr>
                    <td>Policy No</td>
                    <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>Crime Number</td>
                    <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>Police Station</td>
                    <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>Case Type</td>
                    <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>Investigation Date</td>
                    <td>  {{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
                </tr>




            </table>
            <br>


            <table border="1">

                <!-- <tr>
                    <td>Claim No</td>
                    <td>MOT15119272</td>
                </tr>
                <tr>
                    <td>Interaction No.</td>
                    <td>NA</td>
                </tr> -->
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');


    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <!-- <tr> -->
        <!-- <th colspan="2" style="background-color: #d3d3d3; text-transform: uppercase;">
            {{ str_replace('_', ' ', $category) }}
        </th> -->
    <!-- </tr> -->

    @foreach($questions->where('input_type', '!=', 'file') as $question)
        @php
            $answer = $finalReport->{$question->column_name} ?? null;
        @endphp

        @if(!empty($answer))
            <tr>
                <td>{{ $question->question }}</td>
                <td>{{ $answer }}</td>
            </tr>
        @endif
    @endforeach
@endforeach



                
               
              
            </table>


            <br>
           <table>
                <!-- <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                        <p style="font-size: 10;">Findings on Google map timelines – Insured & Driver</p>
                    </th>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center; ">
                        <p style="font-size: 10;">IV RIDER GTL collected and attached with it.</p>
                    </td>
                </tr>
                <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                    </th>
                </tr>
                <tr>
                    <td><img src="picture1.png" alt=""></td>
                    <td><img src="picture2.png" alt=""></td>
                </tr>
                <tr>
                    <td><img src="picture3.png" alt=""></td>
                    <td><img src="picture4.png" alt=""></td>
                </tr> -->

    @php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Filter groups where at least one file question has data in finalReport
    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <tr>
        <th colspan="2" style="background-color: #d3d3d3; text-transform: uppercase;">
            {{ str_replace('_', ' ', $category) }}
        </th>
    </tr>

    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;
            $isImage = false;

            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }
        @endphp

        @if(!empty($filePath))
            <tr>
                <td>{{ $question->question }}</td>
                <td>
                    @if($isImage)
                        <img src="{{ asset('storage/' . $filePath) }}" alt="{{ $question->question }}" style="max-width:150px; max-height:150px;">
                    @else
                        <a href="{{ asset('storage/' . $filePath) }}" target="_blank">View File</a>
                    @endif
                </td>
            </tr>
        @endif
    @endforeach
@endforeach




            </table>
           
           
            <br>
            <br>

            <div style="display: flex; justify-content: space-between;">
                <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}
<br>THIRUVANATHAPURAM</div>
                <div>ANOOP N G <br> <img src="sign.png"> </div>
            </div>

        </div>
    </div>
</body>

</html>