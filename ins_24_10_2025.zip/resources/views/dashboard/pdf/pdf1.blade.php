<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            line-height: 1.6;
            background: #f9f9f9;
            color: #333;
        }
        .report-container {
            background: #fff;
            padding: 25px 40px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0,0,0,0.1);
            max-width: 1000px;
            margin: auto;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .company-box {
            border: 2px solid #222;
            border-radius: 10px;
            padding: 12px;
            width: 200px;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
        }
        h2 {
            text-align: center;
            margin: 30px 0 15px 0;
            text-transform: uppercase;
            border-bottom: 2px solid #555;
            display: inline-block;
            padding-bottom: 5px;
        }
        h3 {
            margin-top: 30px;
            color: #444;
            text-transform: uppercase;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            margin-bottom: 25px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px 12px;
            text-align: left;
        }
        table th {
            background: #f2f2f2;
            font-weight: bold;
            color: #333;
        }
        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            font-weight: bold;
        }
        .images-section {
            margin-top: 40px;
        }
        .images-section h3 {
            margin-bottom: 10px;
            border-left: 5px solid #007bff;
            padding-left: 8px;
            font-size: 18px;
        }
        .image-item {
            margin-bottom: 20px;
        }
        .image-item img {
            max-width: 100%;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-top: 8px;
        }

        .header {
    display: flex;
    justify-content: center;  /* ✅ centers the box itself */
    align-items: center;
}

    </style>
</head>
<body>
    <div class="report-container">

        <!-- HEADER -->
        <div class="header">

        <div>

        @if($finalReport->template_logo)
        <img src="{{ public_path('storage/' . $finalReport->template_logo) }}" 
        alt="Company Logo" 
        style="max-width: 200px; height: auto; margin-top: 10px;">
        @endif
        
        </div>

        <!-- <div class="header">
        <div class="company-box" style="text-align: center;">
        {{ $finalReport->insurance_com_name }}
        </div>
        </div> -->

        </div>

        <!-- TITLE -->
        <h2 style="text-align: center;">Investigation Report- {{ $finalReport->insurance_com_name }}</h2>

        <!-- INTRODUCTION -->
        <h3>I. Introduction</h3>
        <table>
            <tr><th>1</th><td>Name of Customer</td><td>{{ $finalReport->customer_name ?? 'N/A' }}</td></tr>
            <tr><th>2</th><td>Contact Details</td><td>{{ $finalReport->customer_phone ?? 'N/A' }}</td></tr>
            <tr><th>3</th><td>Permanent Address</td><td>{{ $finalReport->customer_present_address ?? 'N/A' }}</td></tr>
            <tr><th>4</th><td>Policy No</td><td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td></tr>
            <tr><th>5</th><td>Crime Number</td><td>{{ $finalReport->crime_number ?? 'N/A' }}</td></tr>
            <tr><th>6</th><td>Police Station</td><td>{{ $finalReport->police_station ?? 'N/A' }}</td></tr>
            <tr><th>7</th><td>Case Type</td><td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td></tr>
            <tr><th>8</th><td>Investigation Date</td><td>{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td></tr>
        </table>

        <!-- CASE DETAILS -->
        <h3>II. Case / Claim Details</h3>
        <table>
            @php
                $groupedQuestions = $validQuestions12->groupBy('data_category');
                $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
                    return $questions->contains(function ($question) use ($finalReport) {
                        return !empty($finalReport->{$question->column_name});
                    });
                });
                $counter = 1;
            @endphp
            @foreach($filteredGroups as $category => $questions)
                @foreach($questions->where('input_type', '!=', 'file') as $question)
                    @php $answer = $finalReport->{$question->column_name} ?? null; @endphp
                    @if(!empty($answer))
                        <tr>
                            <th>{{ $counter++ }}</th>
                            <td>{{ $question->question }}</td>
                            <td>

                            @if($answer === '0' || $answer === 0)
                            No
                            @elseif($answer === '1' || $answer === 1)
                            Yes
                            @else
                            {{ $answer }}
                            @endif

                            </td>
                        </tr>
                    @endif
                @endforeach
            @endforeach
        </table>

        <!-- FOOTER -->
        <div class="footer">
            <div>
                Executive Name: 
                {{ collect([
                    $finalReport->driver_executive,
                    $finalReport->garage_executive,
                    $finalReport->spot_executive,
                    $finalReport->owner_executive,
                    $finalReport->accident_executive
                ])->filter()->unique()->implode(', ') ?: 'N/A' }}
            </div>
            <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}</div>
        </div>

        <!-- IMAGE SECTION -->
        <div class="images-section">
            @php
                $groupedQuestions = $validQuestions12->groupBy('data_category');
                $imageExtensions = ['jpg','jpeg','png','gif','bmp','webp'];
                $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
                    return $questions->contains(function ($question) use ($finalReport) {
                        return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
                    });
                });
            @endphp

            @foreach($filteredGroups as $category => $questions)
                @foreach($questions->where('input_type', 'file') as $question)
                    @php
                        $filePath = $finalReport->{$question->column_name} ?? null;
                        if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                            $decoded = json_decode($filePath, true);
                            if (is_array($decoded) && !empty($decoded)) {
                                $filePath = $decoded[0];
                            }
                        }
                        $isImage = false;
                        if ($filePath) {
                            $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                            $isImage = in_array($ext, $imageExtensions);
                        }
                    @endphp
                    @if($isImage && !empty($filePath))
                        <div class="image-item">
                            <h3>{{ $question->question }}</h3>
                            <img src="{{ storage_path('app/public/' . $filePath) }}" alt="">
                        </div>
                    @endif
                @endforeach
            @endforeach
        </div>
    </div>
</body>
</html>
