<div class="sidenav-menu">
  <button class="button-on-hover">
    <i class="ti ti-menu-4 fs-22 align-middle"></i>
    </button>

            <!-- Full Sidebar Menu Close Button -->
            <button class="button-close-offcanvas">
                <i class="ti ti-x align-middle"></i>
            </button>



            <div class="scrollbar" data-simplebar>
            <!-- User -->

            <!-- <div class="sidenav-user" style="margin-left: 20px;margin-right:20px;margin-top: 10px;margin-bottom: 10px;">
            <div class="d-flex justify-content-center align-items-center text-center">
            <div>
            <a href="{{ route('dashboard') }}" class="link-reset text-center d-block">
            @if($companyLogo && $companyLogo->logo)
            <img src="{{ asset('storage/' . $companyLogo->logo) }}" alt="user-image" class="rounded-circle mb-2 avatar-md d-block mx-auto" style="height: 3.50rem;
                width: 3.50rem;">
            <span class="sidenav-user-name fw-bold d-block">Dashboard</span>
            @endif
            </a>
            </div>
            </div>
            </div> -->

        <div class="sidenav-user my-3 px-3">
        <a href="{{ route('dashboard') }}" class="d-flex align-items-center link-reset text-decoration-none text-dark" style="margin-left: -10px;margin-top: -7px;">

        @if($companyLogo && $companyLogo->logo)
        <img src="{{ asset('storage/' . $companyLogo->logo) }}"
        alt="user-image"
        class="rounded-circle avatar-md me-3" style="height: 3.50rem;
        width: 3.50rem;">
        @endif
        <div class="d-flex flex-column ms-2 me-2">     
        </div>
        </a>

        <div>
        <a href="{{ route('dashboard') }}" class="link-reset">
        <div class="d-flex flex-column flex-grow-1">
        <span class="sidenav-user-name fw-bold"
        style="font-size: 16px; line-height: 1.2;margin-top:5px; white-space: normal; word-break: break-word;">

        {{ $companyLogo->name ?? 'Company Name' }}
        </span>
        </div>

        </a>
        </div>
        </div>

 @php
use App\Models\Role;
use Illuminate\Support\Arr;

// Set the role ID you want to display menus for
// Example: role ID = 2 (you can make this dynamic)
$roleId = session('selected_role_id', 2); // or any method you use to get selected role

// Fetch role with permissions and their children
$role = Role::with('permissions.children')->find($roleId);

$permissions = $role ? $role->permissions : collect();

$icons = [
    'Users' => 'ti ti-users',
    'Insurance Company' => 'ti ti-briefcase',
    'Case Management' => 'ti ti-invoice',
    'Report Management' => 'ti ti-chart-histogram',
    'Final Report' => 'ti ti-chart-histogram',
    'Approvel Request' => 'ti ti-message-dots',
    'Odometer Reading' => 'ti ti-folder',
    'Company Management' => 'ti ti-category',
];

// Top-level permissions
$topLevelPermissions = $permissions->whereNull('parent_id');

// Filter children for each parent
foreach ($topLevelPermissions as $perm) {
    $perm->children = $perm->children->filter(fn($child) => $permissions->contains('id', $child->id));
}
@endphp

<ul class="side-nav">
    {{-- Dashboard --}}
    <a href="{{ route('dashboard') }}">
        <li class="side-nav-title"><i class="ti ti-dashboard me-2"></i>Dashboard</li>
    </a>

    @foreach($topLevelPermissions as $perm)
        @php
            $iconClass = Arr::get($icons, $perm->name, 'ti ti-folder');
        @endphp
        <li class="side-nav-item">
            @if($perm->children->count())
                {{-- Parent menu with children --}}
                <a class="side-nav-link" data-bs-toggle="collapse" href="#menu_{{ $perm->id }}">
                    <span class="menu-icon"><i class="{{ $iconClass }}"></i></span>
                    <span class="menu-text">{{ $perm->name }}</span>
                    <span class="menu-arrow"></span>
                </a>

                <div class="collapse" id="menu_{{ $perm->id }}">
                    <ul class="sub-menu">
                        @foreach($perm->children as $child)
                            @if(Route::has($child->route))
                                <li class="side-nav-item">
                                    <a href="{{ route($child->route) }}" class="side-nav-link">
                                        <span class="menu-icon"></span>
                                        <span class="menu-text">{{ $child->name }}</span>
                                    </a>
                                </li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            @else
                {{-- Direct link for parent without children --}}
                @if(Route::has($perm->route))
                    <a href="{{ route($perm->route) }}" class="side-nav-link">
                        <span class="menu-icon"><i class="{{ $iconClass }}"></i></span>
                        <span class="menu-text">{{ $perm->name }}</span>
                    </a>
                @endif
            @endif
        </li>
    @endforeach
</ul>



            </div>
        </div>
