@extends('dashboard.layout.app')
@section('title', 'Edit Company')

@section('content')
    <div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa fa-question-circle me-2 text-primary"></i> Edit Questionnaire
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('questions.index_question') }}">Questionnaire</a></li>
                    <li class="breadcrumb-item active">Edit Questionnaire</li>
                </ol>
            </div>
        </div>

        <!-- Form Section -->
        <div class="row justify-content-center my-4">
            <div class="col-lg-8 col-md-10">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-question-circle me-2"></i>
                            <h5 class="mb-0" style="color: #fff;">Edit Questionnaire</h5>

                            <!-- Success Message -->
                           <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
style="margin-left: 20px;align-items: center;">
<i class="fa fa-check-circle me-2"></i>
<span id="successText"></span>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex gap-2">
                            <!-- <a href="javascript:location.back()" class="btn btn-danger btn-sm">
                                <i class="fa fa-arrow-left me-1"></i> Back
                            </a> -->

                            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
                            
                            <a href="javascript:location.reload()" class="btn btn-warning btn-sm">
                                <i class="fa fa-sync me-1"></i> Reload
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('questions.update_question', $question->id) }}" method="POST" id="updateQuestionForm" novalidate>
                            @csrf
                            @method('PUT')

                            <!-- Question -->
                            <div class="mb-3">
                                <label for="question" class="form-label fw-bold">Question <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control" 
                                       id="question" 
                                       name="question" 
                                       value="{{ old('question', $question->question) }}" 
                                       placeholder="Enter question" 
                                       required>
                                <span class="text-danger error" id="question-error"></span>
                            </div>

                            <!-- Input Type -->

                        <div class="mb-3">
                        <label for="input_type" class="form-label fw-bold">Input Type <span class="text-danger">*</span></label>

                        <!-- Hidden input to actually submit the value -->
                        <input type="hidden" name="input_type" value="{{ old('input_type', $question->input_type) }}">

                        <!-- Disabled select just for display -->
                        <select class="form-control" id="input_type_display" disabled>
                        @foreach(['text', 'textarea', 'select', 'file', 'date'] as $type)
                        <option value="{{ $type }}" {{ old('input_type', $question->input_type) === $type ? 'selected' : '' }}>
                        {{ ucfirst($type) }}
                        </option>
                        @endforeach
                        </select>

                        @error('input_type')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror
                        </div>


                        <div class="mb-3">
                        <label for="case_type" class="form-label fw-bold">Case Type <span class="text-danger">*</span></label>
                        <select class="form-control" id="case_type" name="case_type" required>
                        <option value="" disabled {{ empty($question->case_type) ? 'selected' : '' }}>Select Type</option>
                        <option value="OD" {{ $question->case_type === 'OD' ? 'selected' : '' }}>OD</option>
                        <option value="MACT" {{ $question->case_type === 'MACT' ? 'selected' : '' }}>MACT</option>
                        </select>
                        <span id="case_type-error" class="text-danger error"></span>
                        </div>

                                    
                    @php
                    $showMactType = $question->case_type === 'MACT' && !empty($question->mact_type);
                    @endphp

                    {{-- MACT Type Dropdown --}}
                    <div class="mb-3" id="mact_type_container" style="{{ $showMactType ? '' : 'display: none;' }}">
                    <label for="mact_type" class="form-label fw-bold">MACT Type </label>
                    <select class="form-control" id="mact_type" name="mact_type">
                    <option value="" disabled {{ empty($question->mact_type) ? 'selected' : '' }}>Select MACT Type</option>
                    <option value="TPPD" {{ $question->mact_type === 'TPPD' ? 'selected' : '' }}>TPPD</option>
                    <option value="Death" {{ $question->mact_type === 'Death' ? 'selected' : '' }}>Death</option>
                    <option value="Injury" {{ $question->mact_type === 'Injury' ? 'selected' : '' }}>Injury</option>
                    </select>
                    </div>



                            <!-- Data Category -->
                            <div class="mb-3">
                                <label for="data_category" class="form-label fw-bold">Data Category <span class="text-danger">*</span></label>
                                <select class="form-control" id="data_category" name="data_category" required>
                                    @foreach(['garage_data', 'spot_data', 'owner_data', 'driver_data', 'accident_person_data'] as $cat)
                                        <option value="{{ $cat }}" {{ old('data_category', $question->data_category) == $cat ? 'selected' : '' }}>
                                            {{ ucfirst(str_replace('_', ' ', $cat)) }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="text-danger error" id="data_category-error"></span>
                            </div>




                    <div class="mb-3">
                    <label for="group_category" class="form-label fw-bold">Group Category </label>
                    <select class="form-control" id="group_category" name="group_category" required>
                    <!-- <option value="" disabled selected>Select Group Category</option> -->
                    <option value="introduction" {{ $question->group_category === 'introduction' ? 'selected' : '' }}>Introduction</option>
                    <option value="case_details" {{ $question->group_category === 'case_details' ? 'selected' : '' }}>CASE/CLAIM DETAILS</option>
                    <option value="accident_details" {{ $question->group_category === 'accident_details' ? 'selected' : '' }}>ACCIDENT DETAILS</option>
                    <option value="insured_details" {{ $question->group_category === 'insured_details' ? 'selected' : '' }}>INSURED VEHICLE DETAILS</option>
                    <option value="financial" {{ $question->group_category === 'financial' ? 'selected' : '' }}>FINANCIAL INVESTIGATION ON INSURED</option>
                    <option value="driver_details" {{ $question->group_category === 'driver_details' ? 'selected' : '' }}>DETAILS OF DRIVER OF INSURED VEHICLE</option>
                    <option value="injury_details" {{ $question->group_category === 'injury_details' ? 'selected' : '' }}> DETAILS OF THE INJURED</option>
                    <option value="pet_details" {{ $question->group_category === 'pet_details' ? 'selected' : '' }}>PETITIONER ADVOCATE DETAILS</option>
                    <option value="fir_details" {{ $question->group_category === 'fir_details' ? 'selected' : '' }}>FIR DETAILS</option>
                    <option value="charge_deatils" {{ $question->group_category === 'charge_deatils' ? 'selected' : '' }}>CHARGE-SHEET/CHALLAN DETAILS </option>
                    <option value="invst_deatils"  {{ $question->group_category === 'invst_deatils' ? 'selected' : '' }}>INVESTIGATION DETAILS </option>
                    </select>
                    <span id="group_category-error" class="text-danger error"></span>
                    </div>

                            <!-- Buttons -->
                            <button type="submit" class="btn btn-success">
                                <i class="fa fa-save me-1"></i> Update
                            </button>
                            <a href="{{ route('questions.index_question') }}" class="btn btn-secondary">
                                <i class="fa fa-times me-1"></i> Cancel
                            </a>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

    
$(document).ready(function() {
    $('#updateQuestionForm').on('submit', function(e) {
        e.preventDefault();
        $('.text-danger').text('');
        $('#successText').text('');
        $('#successMessage').addClass('d-none');

        const form = $(this);
        const actionUrl = form.attr('action');

        $.ajax({
            url: actionUrl,
            type: 'POST',
            data: form.serialize(),
            success: function(response) {
                if (response.success) {
                    $('#successText').text(response.success);
                    $('#successMessage')
                        .removeClass('d-none alert-danger')
                        .addClass('alert alert-success')
                        .fadeIn();

                    $('html, body').animate({
                        scrollTop: $("#successMessage").offset().top - 100
                    }, 500);

                    // Reset form
                    $('#updateQuestionForm')[0].reset();
                    $('.form-control').removeClass('is-invalid');
                    $('.error').text('');

                    setTimeout(function () {
                        window.location.href = response.redirect_url;
                    }, 2500);
                }
            },

            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(field, messages) {
                        $('#' + field + '-error').text(messages[0]);
                    });
                } else {
                    alert('An unexpected error occurred.');
                }
            }
        });
    });
});



    document.addEventListener('DOMContentLoaded', function () {
        const caseTypeSelect = document.getElementById('case_type');
        const mactTypeContainer = document.getElementById('mact_type_container');
        const mactTypeSelect = document.getElementById('mact_type');

        function toggleMactType() {
            const caseTypeValue = caseTypeSelect.value;
            const mactTypeValue = mactTypeSelect.value;

            if (caseTypeValue === 'MACT' && mactTypeValue !== '') {
                mactTypeContainer.style.display = 'block';
                mactTypeSelect.setAttribute('required', 'required');
            } else {
                mactTypeContainer.style.display = 'none';
                mactTypeSelect.removeAttribute('required');
                mactTypeSelect.selectedIndex = 0;
            }
        }

        // Initial check on page load
        toggleMactType();

        // Update on change
        caseTypeSelect.addEventListener('change', function () {
            // If changed to MACT, we show dropdown even if mact_type is empty,
            // so users can choose it
            if (caseTypeSelect.value === 'MACT') {
                mactTypeContainer.style.display = 'block';
                mactTypeSelect.setAttribute('required', 'required');
            } else {
                mactTypeContainer.style.display = 'none';
                mactTypeSelect.removeAttribute('required');
                mactTypeSelect.selectedIndex = 0;
            }
        });
    });

</script>

@endsection
