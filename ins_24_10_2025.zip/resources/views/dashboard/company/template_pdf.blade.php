@php
    use Illuminate\Support\Str;
    $grouped = $template->questions->groupBy('data_category');
@endphp

<h3 style="font-size: 18px;">Template ID: {{ $template->template_id }}</h3>
<hr>

@foreach($grouped as $category => $questions)
    <h5 style="margin-top: 15px; font-size: 14px;">
        {{ Str::title(str_replace('_', ' ', $category)) }}
    </h5>
    <ul>
        @foreach($questions as $question)
            <li style="margin-bottom: 5px;">{{ $question->question }}</li>
        @endforeach
    </ul>
@endforeach

@if($grouped->isEmpty())
    <p style="color: #888;">No questions found</p>
@endif
