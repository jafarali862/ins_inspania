@extends('dashboard.layout.app')
@section('title', 'Case List')

@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-building me-2 text-primary"></i> Case List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Case List</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('insurance.create') }}" class="btn btn-primary">
                <i class="fa-solid fa-building-circle-plus me-1"></i> Add Case
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0" style="color:#fff;">Case List</h5>
             
            </div>

            <div class="card-body">

                <!-- Status Filter -->
                <div class="mb-3">
                    <label for="statusFilter"><strong>Filter by Status:</strong></label>
                    <select id="statusFilter" class="form-select" style="width:200px; display:inline-block;">
                        <option value="">All</option>
                        <option value="Pending">Pending</option>
                        <option value="Complete">Complete</option>
                        <option value="Assigned">Assigned</option>
                    </select>
                </div>

                <table id="casesTable" class="table table-striped table-bordered nowrap mb-0">
                     <thead class="thead-dark text-start">
                        <tr>
                            <th>Sl No</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Case Type</th>
                            <th>Crime Number</th>
                            <th>Police Station</th>
                            <th>Assign Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php use Carbon\Carbon; @endphp
                        @php $i = 1; @endphp
                        @foreach ($customers as $customer)
                            @php
                                $statusText = 'Unknown';
                                if ($customer->case_status == 1) $statusText = 'Pending';
                                elseif ($customer->case_status == 0) $statusText = 'Complete';
                                elseif ($customer->case_status == 2) $statusText = 'Assigned';

                                // Bootstrap 5 badge classes use bg-* instead of badge-*
                                $badgeClass = match($statusText) {
                                    'Pending' => 'bg-danger',
                                    'Complete' => 'bg-success',
                                    'Assigned' => 'bg-warning',
                                    default => 'bg-secondary',
                                };
                            @endphp
                            <tr>
                                <td class="text-start">{{ $i++ }}</td>
                                <td class="text-start">
                                    {{ $customer->name }}<br>
                                    <small class="text-muted">{{ $customer->phone }}</small><br/>
                                    <span class="badge {{ $badgeClass }}">
                                        {{ $statusText }}
                                    </span>
                                    <span class="d-none status-text">{{ $statusText }}</span>
                                </td>
                                <td class="text-start">{{ $customer->company->name ?? 'N/A' }}</td>
                                <td class="text-start">{{ $customer->insurance_type }}</td>
                                <td class="text-start">{{ $customer->crime_number }}</td>
                                <td class="text-start">{{ $customer->police_station }}</td>
                                <td class="text-start">{{ Carbon::parse($customer->created_at)->format('d-m-Y') }}</td>
                               <td class="text-start">
    <div class="d-flex flex-wrap gap-1 justify-content-center">
        <button class="btn btn-primary btn-sm open-assign-modal" 
                data-url="{{ route('assign.case', $customer->id) }}" 
                title="Assign Executive">
            <i class="fas fa-user-plus"></i>
        </button>

        <a href="{{ route('case.edit', $customer->id) }}" 
           class="btn btn-info btn-sm" 
           title="Edit Case">
            <i class="fas fa-edit"></i>
        </a>

        <button class="btn btn-secondary btn-sm open-view-modal" 
                data-url="{{ route('view.case', $customer->id) }}" 
                title="View Details">
            <i class="fas fa-eye"></i>
        </button>

        @if ($customer->intimation_report)
            <a href="{{ asset('storage/' . $customer->intimation_report) }}" 
               class="btn btn-success btn-sm" 
               download title="Download Intimation Report">
                <i class="fas fa-download"></i>
            </a>
        @endif
    </div>
</td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>

            </div> <!-- card-body -->
        </div> <!-- card -->

    </div> <!-- container-fluid -->
</div> <!-- content-page -->

{{-- Assign Modal --}}
<!-- Assign Executive Modal -->
<div class="modal fade" id="assignModal" tabindex="-1" aria-labelledby="assignModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="assignModalLabel">
                    <i class="fas fa-user-plus me-2"></i> Assign Executive
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body" id="assignModalBody">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3 text-muted">Loading content, please wait...</p>
                </div>
            </div>
        </div>
    </div>
</div>


{{-- View Modal --}}
<!-- View Case Details Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title" id="viewModalLabel">
                    <i class="fas fa-eye me-2"></i> Case Details
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body" id="viewModalBody">
                <!-- Content will be loaded dynamically here -->
                <div class="text-center py-5">
                    <div class="spinner-border text-info" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3 text-muted">Loading case details, please wait...</p>
                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">


<style>
   .card-header
{
border-bottom: unset;
}
</style>

<style>
@media (max-width: 576px) {
    /* Hide only the Action column header */
    #casesTable th:nth-child(8) {
        display: none !important;
    }

    /* Hide only the "Action" title in responsive child rows, keep the data visible */
    li[data-dtr-index="7"] > span.dtr-title {
        display: none !important;
    }
}



</style>
<script>
$(document).ready(function() {

//    $('#casesTable').DataTable({
//         paging: true,
//         lengthChange: true,
//         searching: true,
//         ordering: true,
//         info: true,
//         autoWidth: false,
//         pageLength: 10,
//         lengthMenu: [5, 10, 25, 50],
//         columnDefs: [
//             { orderable: false, targets: 7 }
//         ]
//     });



 
   
$(document).ready(function () {
    const table = $('#casesTable').DataTable({
        paging: true,
        lengthChange: true,
        searching: true,
        ordering: true,
        info: true,
        responsive: true,
        pageLength: 10,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search cases..."
        },
        columnDefs: [
            { orderable: false, targets: [7] } // Disable sorting on Actions column
        ],
        dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
    });

    // Step 1: Read URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const statusFromUrl = urlParams.get('status');

    // Step 2: If status is in URL, set the dropdown and filter table
    if (statusFromUrl) {
        $('#statusFilter').val(statusFromUrl);
        table.column(1).search(statusFromUrl, true, false).draw();
    }

    // Step 3: Filter when dropdown changes
    $('#statusFilter').on('change', function () {
        const selected = $(this).val();
        if (selected) {
            table.column(1).search(selected, true, false).draw();
        } else {
            table.column(1).search('').draw(); // Reset
        }
    });
});



    

    // Delegate click for assign modal buttons
    $('#casesTable').on('click', '.open-assign-modal', function() {
        var url = $(this).data('url');
        var $modal = $('#assignModal');
        var $modalBody = $('#assignModalBody');

        $modalBody.html(`
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status"></div>
            </div>
        `);

        $modal.modal('show');

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error('Network response was not OK');
                return response.text();
            })
            .then(html => {
                $modalBody.html(html);
                // Execute scripts in loaded content
                $modalBody.find('script').each(function() {
                    $.globalEval(this.text || this.textContent || this.innerHTML || '');
                });
            })
            .catch(() => {
                $modalBody.html('<div class="alert alert-danger">Failed to load form. Please try again later.</div>');
            });
    });

    // Delegate click for view modal buttons
    $('#casesTable').on('click', '.open-view-modal', function() {
        var url = $(this).data('url');
        var $modal = $('#viewModal');
        var $modalBody = $('#viewModalBody');

        $modalBody.html(`
            <div class="text-center py-5">
                <div class="spinner-border text-info" role="status"></div>
            </div>
        `);

        $modal.modal('show');

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error('Failed to load');
                return response.text();
            })
            .then(html => {
                $modalBody.html(html);
            })
            .catch(() => {
                $modalBody.html('<div class="alert alert-danger">Error loading details. Try again.</div>');
            });
    });
});

// Your exe1 function (optional, depends on your use case)
function exe1() {
    const insPerson = window.insuranceCustomer || {};
    const exe1Val = $('#executive_1').val();
    const exe2 = $('#executive_2');
    const exe3 = $('#executive_3');
    const exe4 = $('#executive_4');
    const exe5 = $('#executive_5');
    const exe6 = $('#executive_6');
    const accident = $('#accident');

    if (exe1Val !== '') {
        $('#sub-executive-group').show();
        exe2.val(exe1Val);
        exe3.val(exe1Val);
        exe4.val(exe1Val);
        exe5.val(exe1Val);

        if (insPerson.insurance_type === 'MACT') {
            accident.show();
            exe6.val(exe1Val);
        } else {
            accident.hide();
            exe6.val('');
        }
    } else {
        $('#sub-executive-group').hide();
    }
}
</script>

@endsection

