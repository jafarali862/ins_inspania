<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Case Report -  {{ $executive->name }}</title>

    <!-- ✅ Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Optional: Google Fonts / Custom Styling -->
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
        }
        .nav-tabs .nav-link.active {
            font-weight: bold;
            border-bottom: 3px solid #0d6efd;
        }
        .fs-3 {
            font-size: 1.75rem;
        }
        h2 {
            margin-top: 20px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2 class="text-center">Case Report for Executive - {{ $executive->name }}</h2>

        {{-- Tabs --}}
        @php
            $periods = ['daily', 'weekly', 'monthly'];
        @endphp

       
        {{-- Report summary --}}
       <table class="table table-bordered table-striped">
        <thead class="table-success">
            <tr>
                <th>#</th>
                <th>check in</th>
                <th>check out</th>
                <th>Work Done</th>
            </tr>
        </thead>
        <tbody>
            @forelse($odometerReadings as $index => $reading)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>
                        Km :{{ $reading->check_in_km ?? '—' }}<br/>

                          Time :{{ $reading->check_in_time ?? '—' }}<br/>

                            Date :{{ $reading->check_in_date ?? '—' }}<br/>
                    </td>
                    <td>
                              Km :{{ $reading->check_out_km ?? '—' }}<br/>

                          Time :{{ $reading->check_out_time ?? '—' }}<br/>

                            Date :{{ $reading->check_out_date ?? '—' }}<br/>
                    </td>

                    @php
    $checkOutKm = $reading->check_out_km;
    $checkInKm = $reading->check_in_km;
    $kmDriven = ($checkOutKm !== null && $checkInKm !== null) ? ($checkOutKm - $checkInKm) : '—';
@endphp

                    <td>{{ $kmDriven }} </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="text-center text-muted">No odometer readings found for this period.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

            

        </div>



    </div>

    <!-- ✅ Bootstrap JS Bundle (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
