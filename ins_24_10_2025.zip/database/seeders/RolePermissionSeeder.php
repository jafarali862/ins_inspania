<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    public function run()
    {
        // Create Permissions (menus)
        $dashboard = Permission::create(['name' => 'Dashboard', 'route' => 'dashboard', 'parent_id' => null]);
        $userManagement = Permission::create(['name' => 'User Management', 'route' => 'user.list', 'parent_id' => null]);
        $addUser = Permission::create(['name' => 'Add User', 'route' => 'user.create', 'parent_id' => $userManagement->id]);
        $companyManagement = Permission::create(['name' => 'Company Managementc', 'route' => 'company.list', 'parent_id' => null]);
        // add more as needed...

        // Create roles
        $admin = Role::create(['name' => 'Admin']);
        $user = Role::create(['name' => 'User']);

        // Assign permissions to roles
        $admin->permissions()->attach([$dashboard->id, $userManagement->id, $addUser->id, $companyManagement->id]);
        $user->permissions()->attach([$dashboard->id]);
    }
}
