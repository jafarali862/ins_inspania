<h1>Roles</h1>
<a href="{{ route('roles.create') }}">Create New Role</a>

@if(session('success'))
    <div>{{ session('success') }}</div>
@endif

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>Name</th>
            <th>Permissions</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($roles as $role)
        <tr>
            <td>{{ $role->name }}</td>
            <td>{{ implode(', ', $role->permissions->pluck('name')->toArray()) }}</td>
            <td>
                <a href="{{ route('roles.edit', $role->id) }}">Edit</a>
                <form action="{{ route('roles.destroy', $role->id) }}" method="POST" style="display:inline-block;">
                    @csrf @method('DELETE')
                    <button type="submit" onclick="return confirm('Delete role?')">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

