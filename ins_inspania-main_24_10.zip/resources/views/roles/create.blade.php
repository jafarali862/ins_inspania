<h1>Create Role</h1>

@if ($errors->any())
    <div>
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form method="POST" action="{{ route('roles.store') }}">
    @csrf

    <label>Role Name</label>
    <input type="text" name="name" value="{{ old('name') }}" required>

    <h3>Assign Permissions</h3>

    @foreach($permissions as $permission)
    <div>
        <input type="checkbox" name="permissions[]" id="perm_{{ $permission->id }}" value="{{ $permission->name }}">
        <label for="perm_{{ $permission->id }}">{{ $permission->name }}</label>
    </div>
    @endforeach

    <button type="submit">Save</button>
</form>
