
      <div class="sidenav-menu">
       <!-- <a href="{{ route('dashboard') }}" class="logo">
                <span class="logo logo-light">
               <span class="logo-lg">

                 @if($companyLogo && $companyLogo->logo)
         

  <img src="{{ asset('storage/' . $companyLogo->logo) }}" alt="logo" style="width: 100%;height: 60px;">
  @endif
</span>

                    <span class="logo-sm"><img src="{{ asset('storage/logos/zhjn6hCrav3vQOY6LitVLVh9f4B358SifFpX4Vum.png') }}" alt="small logo"></span>
                </span>

                <span class="logo logo-dark">
                    <span class="logo-lg"><img src="assets/images/logo-black.png" alt="dark logo"></span>
                    <span class="logo-sm"><img src="assets/images/logo-sm.png" alt="small logo"></span>
                </span>
            </a> -->

            <!-- Sidebar Hover Menu Toggle Button -->
            <button class="button-on-hover">
                <i class="ti ti-menu-4 fs-22 align-middle"></i>
            </button>

            <!-- Full Sidebar Menu Close Button -->
            <button class="button-close-offcanvas">
                <i class="ti ti-x align-middle"></i>
            </button>



            <div class="scrollbar" data-simplebar>
            <!-- User -->

            <div class="sidenav-user">
            <div class="d-flex justify-content-center align-items-center text-center">
            <div>
            <a href="{{ route('dashboard') }}" class="link-reset text-center d-block">
            @if($companyLogo && $companyLogo->logo)
            <img src="{{ asset('storage/' . $companyLogo->logo) }}" alt="user-image" class="rounded-circle mb-2 avatar-md d-block mx-auto" style="width:5.25rem;height:2.25rem;">
            <span class="sidenav-user-name fw-bold d-block">Dashboard</span>
            @endif
            </a>
            </div>
            </div>
            </div>

            

            <ul class="side-nav">
            <!-- <li class="side-nav-title" data-lang="menu-title">Dashboard</li> -->

            <!-- <li class="side-nav-title" data-lang="apps-title">Apps</li> -->


        

   



<li class="side-nav-item {{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? 'active' : '' }}">
    <a data-bs-toggle="collapse"
       href="#sidebarInvoice"
       aria-expanded="{{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? 'true' : 'false' }}"
       aria-controls="sidebarInvoice"
       class="side-nav-link {{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? '' : 'collapsed' }}">
       
        <span class="menu-icon"><i class="ti ti-invoice"></i></span>
        <span class="menu-text">Case Management</span>
        <span class="menu-arrow"></span>
    </a>

    <div class="collapse {{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? 'show' : '' }}" id="sidebarInvoice">
        <ul class="sub-menu">
            
            <li class="side-nav-item">
                <a href="{{ route('case.index') }}"
                   class="side-nav-link {{ Request::is('case-list') || Request::is('case-edit/*') ? 'active' : '' }}">
                    <span class="menu-text">Case List</span>
                </a>
            </li>
            <li class="side-nav-item">
                <a href="{{ route('assigned.case') }}"
                   class="side-nav-link {{ Request::is('assigned-case') ? 'active' : '' }}">
                    <span class="menu-text">Assigned Case</span>
                </a>
            </li>
        </ul>
    </div>
</li>




            <li class="side-nav-item">
            <a href="{{ route('request.report') }}" class="side-nav-link">
            <span class="menu-icon"><i class="ti ti-chart-histogram"></i></span>
            <span class="menu-text" data-lang="metrics"> Report Management </span>
            </a>
            </li>


          

          
            </ul>

  </div>
        </div>
