@extends('dashboard.layout.app')
@section('title', 'Report Request Detail')
@section('content')


<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center justify-content-between mb-4">
            <h4 class="fs-sm text-uppercase fw-bold m-0">
                <i class="fa-solid fa-building me-2 text-primary"></i> Report Details
            </h4>
            <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active">Report Details</li>
            </ol>
        </div>

        <!-- Report Customer Heading -->
       <div class="row align-items-center mb-3">
    <div class="col-md-6">
        <h3 class="mb-0">
            <strong>
                <span class="text-primary fw-bold fs-5" style="font-size: 17px !important;">Report Details for</span>
                <span class="text-success fw-bold fs-5" style="font-size: 17px !important;">{{ $report->customer_name }}</span>
            </strong>
        </h3>
    </div>

    <!-- Action Buttons -->
    <div class="col-md-6 text-end">
        <div class="btn-group gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
        </div>
    </div>
</div>

<!-- General Info Card -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0 fw-bold"    style="font-weight: 700 !important;font-size: 17px !important;">General Information</h5>
    </div>
    <div class="card-body">
        <p class="fw-bold fs-6"    style="font-size: 15px !important;"><strong>Company Name:</strong> {{ $report->company_name }}</p>
        <p class="fw-bold  fs-6"   style="font-size: 15px !important;"><strong>Investigation Date:</strong> {{ \Carbon\Carbon::parse($report->date)->format('d-m-Y') }}</p>
        <p class="fw-bold  fs-6"   style="font-size: 15px !important;"><strong>Type:</strong> {{ $report->type }}</p>
    </div>
</div>

<!-- Fake Report Badge or Button -->
        <div class="mb-4 d-flex justify-content-between align-items-center" style="float: right;">
            @if ($report->is_fake == 1)
            <span class="badge bg-danger px-3 py-2 fw-bold fs-6">Fake</span>
            @else
            <!-- <button type="button" class="btn btn-secondary fw-bold" onclick="confirmFakeData()">Mark as Fake Data</button>
            <form id="fakeDataForm" method="POST" action="{{ route('insurance.fake.data') }}" class="d-none">
            @csrf
            <input type="hidden" name="case_id" value="{{ $report->case_id }}">
            </form> -->

            <button type="button" class="btn btn-secondary fw-bold" data-bs-toggle="modal" data-bs-target="#fakeDataModal">
            Mark as Fake Data
            </button>

            <!-- Hidden form -->
            <form id="fakeDataForm" method="POST" action="{{ route('insurance.fake.data') }}" class="d-none">
            @csrf
            <input type="hidden" name="case_id" value="{{ $report->case_id }}">
        </form>


<div class="modal fade" id="fakeDataModal" tabindex="-1" aria-labelledby="fakeDataModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-light">
        <h5 class="modal-title" id="fakeDataModalLabel">Confirm Action</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to mark this section as fake data?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary fw-bold" onclick="submitFakeDataForm()">Yes, Mark as Fake</button>
      </div>
    </div>
  </div>
</div>
    @endif
</div>

<!-- Flash Messages -->
@if (session('success'))
    <div id="successAlert" class="alert alert-success fw-bold">
        {{ session('success') }}
    </div>

    <script>
        setTimeout(() => {
            const alertBox = document.getElementById('successAlert');
            if (alertBox) {
                alertBox.style.transition = 'opacity 0.5s ease';
                alertBox.style.opacity = '0';
                setTimeout(() => alertBox.remove(), 500); // remove after fade-out
            }
        }, 5000); // hide after 5 seconds
    </script>
@endif

@if (session('error'))
    <div class="alert alert-danger fw-bold">{{ session('error') }}</div>
@endif

<!-- Navigation Tabs -->
<ul class="nav nav-tabs mt-4 fw-bold fs-6" id="dataTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active text-primary" id="garage-tab" data-bs-toggle="tab" data-bs-target="#garageData"
            type="button" role="tab" aria-controls="garageData" aria-selected="true" style="font-size:16px;">Garage Data</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link text-info" id="driver-tab" data-bs-toggle="tab" data-bs-target="#driverData"
            type="button" role="tab" aria-controls="driverData" aria-selected="false" style="font-size:16px;">Driver Data</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link text-warning" id="spot-tab" data-bs-toggle="tab" data-bs-target="#spotData"
            type="button" role="tab" aria-controls="spotData" aria-selected="false" style="font-size:16px;">Spot Data</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link text-success" id="owner-tab" data-bs-toggle="tab" data-bs-target="#ownerData"
            type="button" role="tab" aria-controls="ownerData" aria-selected="false" style="font-size:16px;">Owner Data</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link text-danger" id="accident-tab" data-bs-toggle="tab" data-bs-target="#accidentData"
            type="button" role="tab" aria-controls="accidentData" aria-selected="false" style="font-size:16px;">Accident Person Data</button>
    </li>
</ul>


<!-- Tab Content Wrapper -->
<div class="tab-content" id="dataTabsContent">

    <!--  Garage Data Tab -->
    <div class="tab-pane fade show active" id="garageData" role="tabpanel" aria-labelledby="garage-tab">
        <h5 class="mt-4" style="font-size:15px;">Garage Data</h5>

        @if ($report->garage_reassign_status == 1)
    
    
                <button type="button" style="margin-bottom:10px;" class="btn btn-danger" data-bs-toggle="modal"  data-bs-target="#reassignModal"  data-report-id="{{ $report->id }}">
                Re-Assign
                </button>

        
                <div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                
                <form action="{{ route('garage.re.assign') }}" method="POST" id="reassignForm">
                @csrf
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                @foreach ($users as $user)
                <option value="{{ $user->id }}">
                {{ $user->name }} ({{ $user->place }})
                </option>
                @endforeach
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>

                </div>
                </div>


        @endif

        @if ($report->garage_reassign_status == 0)

        <span class="badge bg-warning text-dark">Pending</span>

        @endif

        <div class="card p-3 mb-4">

        
            <form method="POST" action="{{ route('garage.text.update_new') }}" enctype="multipart/form-data">
                @csrf
                @foreach ($garageQuestions as $qIndex => $question)
                    @php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;

                
      $sortedGarageData = collect($garageData)->sortBy(function ($garage) use ($columnName) {
            $value = strtolower(trim($garage->$columnName ?? ''));
            return ($value === 'n/a' || $value === '') ? 1 : 0;
        })->values();

                    @endphp

                    <input type="hidden" name="tab" value="garageData">


                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2" style="font-size: 14px;font-weight: 650;">{{ $question->question }}</strong>


                        
                        <div class="row">
                            @foreach ($sortedGarageData  as $garage)
                                @php
                                    $value = $garage->$columnName ?? 'N/A';
                                    $radioId = "garage_radio_{$columnName}_{$garage->id}";
                                    $wrapperId = "garage_fieldWrapper_{$columnName}_{$garage->id}";

                                    $isChecked = $selectedGarageAnswers->contains(function ($item) use ($garage, $columnName) {
                                    return $item->garage_id === $garage->id && $item->column_name === $columnName;
                                    });

                                @endphp

                    <div class="col-md-4 mb-2 custom-desktop-width">



@if (!empty($value) && strtolower(trim($value)) !== 'n/a')
    <div class="form-check mb-1">
        <input type="checkbox"
            class="form-check-input select-answer-checkbox-garage"
            name="selected_field[{{ $columnName }}][]"
            value="{{ $garage->id }}"
            data-column="{{ $columnName }}"
            data-value="{{ $value }}"
            data-case="{{ $report->case_id }}"
            data-garage-id="{{ $garage->id }}"
            id="{{ $radioId }}"
            style="border: 2px solid #4eab3c; width: 18px; height: 18px; accent-color: #4eab3c;"
           {{ $isChecked ? 'checked' : '' }}>
        <label class="form-check-label" for="{{ $radioId }}">Select this garage</label>
    </div>
@endif


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="{{ $columnName }}:{{ $garage->id }}"
            id="{{ $radioId }}"
            data-target="#{{ $wrapperId }}">
                                     
            <!-- <label class="form-check-label" for="{{ $radioId }}"> -->

    @php
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
    $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));

    if (filter_var($value, FILTER_VALIDATE_URL)) 
    {
        $filePath = $value;  // full URL already, use directly
    } 
    else 
    {
        $filePath = asset('storage/' . ltrim($value, '/'));  // relative path, build URL
    }
@endphp

@if (in_array($extension, $imageExtensions))
<img src="{{ $filePath }}" 
     alt="Image" 
     class="img-thumbnail"
     style=" width: 70px;        
    height: 70px;         
    border: 1px solid #ccc; 
    border-radius: 6px;    
    object-fit: cover;     
    cursor: pointer;  
    margin-bottom: 5px;  
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);" 
     data-bs-toggle="modal" 
     data-bs-target="#imageModal"
     onclick="showImageModal('{{ $filePath }}', '{{ $radioId }}')">




    <br/>

@elseif (in_array($extension, $audioExtensions))
    <audio controls style="display: block; margin-bottom: 5px;">
        <source src="{{ $filePath }}" type="audio/{{ $extension }}">
        Your browser does not support the audio element.
    </audio>

            @else
            <p>
            @if ($inputType === 'select')
            @if ($value == 1)
            Yes
            @elseif ($value == 0)
            No
            @else
            {{ $value }}
            @endif
            @else
            {{ $value }}
            @endif
            </p>
            @endif

            <small>
              @if ($value !== null && $value !== '' && $value !== 'N/A')
            <span style="color: #007bff; font-weight: bold;font-size: 14px;">
            <i class="fas fa-user-tie me-1"></i> {{-- Font Awesome icon --}}
          {{ $garage->executive->name ?? 'N/A' }}

            </span>
            @endif
            </small>
            <br/>

               @if ($value !== null && $value !== ''  && $value !== 'N/A')
            <label>{{ \Carbon\Carbon::parse($garage->updated_at)->format('d-m-Y h:i:s A') }} </label>
            @endif
            </label>
        </div>

        <div class="d-none field-wrapper mt-2" id="{{ $wrapperId }}">
        @if ($inputType === 'textarea')
        <textarea name="field_value[{{ $garage->id }}][{{ $columnName }}]" class="form-control">{{ $value }}</textarea>
        @elseif ($inputType === 'file')
        @if ($value)
            <!-- <p><img src="{{ asset('storage/' . $value) }}" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        @endif
        <input type="file" name="field_value[{{ $garage->id }}][{{ $columnName }}]" class="form-control">
        @elseif ($inputType === 'select')
    @php
        $otherSelected = $value === 'Other';
    @endphp

    <select name="field_value[{{ $garage->id }}][{{ $columnName }}]"
            class="form-control select-trigger"
            data-id="{{ $garage->id }}"
            data-column="{{ $columnName }}">
        <option value="Yes" {{ $value == 'Yes' ? 'selected' : '' }}>Yes</option>
        <option value="No" {{ $value == 'No' ? 'selected' : '' }}>No</option>
        <option value="Other" {{ $value == 'Other' ? 'selected' : '' }}>Other</option>
    </select>

       <input type="text" 
       name="other_value[{{ $garage->id }}][{{ $columnName }}]"
       class="form-control mt-2 other-input"
       id="other_input_{{ $garage->id }}_{{ $columnName }}"
       placeholder="Please specify"
       value="{{ old("other_value.$garage->id.$columnName") }}"
       style="{{ $value == 'Other' ? '' : 'display:none;' }}; width:850px;">


        @else
        <input type="{{ $inputType }}" name="field_value[{{ $garage->id }}][{{ $columnName }}]" value="{{ $value }}" class="form-control">
        @endif

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        @endforeach
        </div>
        </div>
        @endforeach
        </form>
        </div>
        </div>


<!-- Bootstrap Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-dark text-white p-3">
      <div class="modal-body text-center">
        
        <!-- Image Preview -->
        <img id="modalImage" src="" alt="Preview" class="img-fluid rounded mb-3">

        <!-- Checkbox BELOW image -->
        <div class="form-check d-flex align-items-center justify-content-center mb-2">
          <input type="checkbox" 
                 id="modalCheckbox" 
                 class="form-check-input me-2" 
                 style="margin-top: 0.1rem;">
          <label class="form-check-label text-white fw-semibold" for="modalCheckbox" id="modalCheckboxLabel">
            Select this garage
          </label>
        </div>

      </div>

      <!-- Modal Footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="imageModal2" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-dark text-white p-3">
      <div class="modal-body text-center">
        
        <!-- Image Preview -->
        <img id="modalImage2" src="" alt="Preview" class="img-fluid rounded mb-3">

        <!-- Checkbox BELOW image -->
        <div class="form-check d-flex align-items-center justify-content-center mb-2">
          <input type="checkbox" 
                 id="modalCheckbox2" 
                 class="form-check-input me-2" 
                 style="margin-top: 0.1rem;">
          <label class="form-check-label text-white fw-semibold" for="modalCheckbox2" id="modalCheckboxLabel2">
            Select this driver
          </label>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="imageModal3" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-dark text-white p-3">
      <div class="modal-body text-center">
        
        <!-- Image Preview -->
        <img id="modalImage3" src="" alt="Preview" class="img-fluid rounded mb-3">

        <!-- Checkbox BELOW image -->
        <div class="form-check d-flex align-items-center justify-content-center mb-2">
          <input type="checkbox" 
                 id="modalCheckbox3" 
                 class="form-check-input me-2" 
                 style="margin-top: 0.1rem;">
          <label class="form-check-label text-white fw-semibold" for="modalCheckbox3" id="modalCheckboxLabel3">
            Select this spot
          </label>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>





<div class="modal fade" id="imageModal4" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-dark text-white p-3">
      <div class="modal-body text-center">
        
        <!-- Image Preview -->
        <img id="modalImage4" src="" alt="Preview" class="img-fluid rounded mb-3">

        <!-- Checkbox BELOW image -->
        <div class="form-check d-flex align-items-center justify-content-center mb-2">
          <input type="checkbox" 
                 id="modalCheckbox4" 
                 class="form-check-input me-2" 
                 style="margin-top: 0.1rem;">
          <label class="form-check-label text-white fw-semibold" for="modalCheckbox4" id="modalCheckboxLabel4">
            Select this owner
          </label>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>






<div class="modal fade" id="imageModal5" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-dark text-white p-3">
      <div class="modal-body text-center">
        
        <!-- Image Preview -->
        <img id="modalImage5" src="" alt="Preview" class="img-fluid rounded mb-3">

        <!-- Checkbox BELOW image -->
        <div class="form-check d-flex align-items-center justify-content-center mb-2">
          <input type="checkbox" 
                 id="modalCheckbox5" 
                 class="form-check-input me-2" 
                 style="margin-top: 0.1rem;">
          <label class="form-check-label text-white fw-semibold" for="modalCheckbox5" id="modalCheckboxLabel5">
            Select this accident
          </label>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



    <!-- 🧍 Driver Data Tab -->
        <div class="tab-pane fade" id="driverData" role="tabpanel" aria-labelledby="driver-tab">
        <h5 class="mt-4" style="font-size:15px;">Driver Data</h5>

        @if ($report->driver_reassign_status == 1)
    
         <button type="button" class="btn btn-danger" style="margin-bottom:10px;" data-bs-toggle="modal"  data-bs-target="#reassignModal2"  data-report-id="{{ $report->id }}">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal2" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="{{ route('driver.re.assign') }}" method="POST" id="reassignForm">
                @csrf
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                @foreach ($users as $user)
                <option value="{{ $user->id }}">
                {{ $user->name }} ({{ $user->place }})
                </option>
                @endforeach
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>

        @endif

        @if ($report->driver_reassign_status == 0)
        <span class="badge bg-warning text-dark">Pending</span>
        @endif

        <div class="card p-3 mb-4">



          <form method="POST" action="{{ route('driver.text.update_new') }}" enctype="multipart/form-data">
                @csrf
                @foreach ($driverQuestions as $qIndex => $question)
                    @php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    @endphp

                <input type="hidden" name="tab" value="driverData">

                    
                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2" style="font-size: 14px;font-weight: 650;">{{ $question->question }}</strong>
       
                        
                    <div class="row g-3">

                @foreach ($driverData as $driver)
                @php
                $value = $driver->$columnName ?? 'N/A';
                $radioId = "driver_radio_{$columnName}_{$driver->id}";
                $wrapperId = "driver_fieldWrapper_{$columnName}_{$driver->id}";

                $isChecked = $selectedGarageAnswers->contains(function ($item) use ($driver, $columnName) {
                return $item->garage_id === $driver->id && $item->column_name === $columnName;
                });

                @endphp

         <div class="col-md-4 mb-2 custom-desktop-width">
   
            @if (!empty($value) && strtolower(trim($value)) !== 'n/a')
            <div class="form-check mb-1">
            <input type="checkbox"
            class="form-check-input select-answer-checkbox-driver"
            name="selected_field[{{ $columnName }}][]"
            value="{{ $driver->id }}"
            data-column="{{ $columnName }}"
            data-value="{{ $value }}"
            data-case="{{ $report->case_id }}"
            data-driver-id="{{ $driver->id }}"
            id="{{ $radioId }}"
            style="border: 2px solid #4eab3c; width: 18px; height: 18px; accent-color: #4eab3c;"
            {{ $isChecked ? 'checked' : '' }}>
            <label class="form-check-label" for="{{ $radioId }}">Select this driver</label>
            </div>
            @endif




            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="{{ $columnName }}:{{ $driver->id }}"
            id="{{ $radioId }}"
            data-target="#{{ $wrapperId }}">
                                     
            <!-- <label class="form-check-label" for="{{ $radioId }}"> -->

                @php
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
    $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));

    // Check if $value is a full URL or a relative path
    if (filter_var($value, FILTER_VALIDATE_URL)) {
        $filePath = $value;  // full URL already, use directly
    } else {
        $filePath = asset('storage/' . ltrim($value, '/'));  // relative path, build URL
    }
@endphp

@if (in_array($extension, $imageExtensions))
  <img src="{{ $filePath }}" 
     alt="Image" 
     class="img-thumbnail"
     style="width: 70px;        
    height: 70px;         
    border: 1px solid #ccc; 
    border-radius: 6px;    
    object-fit: cover;     
    cursor: pointer;  
    margin-bottom: 5px;  
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
     data-bs-toggle="modal" 
     data-bs-target="#imageModal2"
     onclick="showImageModal2('{{ $filePath }}', '{{ $radioId }}')">
    <br/>

@elseif (in_array($extension, $audioExtensions))
    <audio controls style="display: block; margin-bottom: 5px;">
        <source src="{{ $filePath }}" type="audio/{{ $extension }}">
        Your browser does not support the audio element.
    </audio>

             @else
            <p>
            @if ($inputType === 'select')
            @if ($value == 1)
            Yes
            @elseif ($value == 0)
            No
            @else
            {{ $value }}
            @endif
            @else
            {{ $value }}
            @endif
            </p>
            @endif

            <br>
           <small>
               @if ($value !== null && $value !== '' && $value !== 'N/A')
            <span style="color: #007bff; font-weight: bold;font-size: 14px;">
            <i class="fas fa-user-tie me-1"></i> {{-- Font Awesome icon --}}
             {{ $driver->executive->name ?? 'N/A' }}
            </span>
            @endif
            </small><br/>
                   @if ($value !== null && $value !== '' && $value !== 'N/A')
            {{ \Carbon\Carbon::parse($driver->updated_at)->format('d-m-Y h:i:s A') }}
            @endif
            </label>

        </div>

        <div class="d-none field-wrapper mt-2" id="{{ $wrapperId }}">
        @if ($inputType === 'textarea')
        <textarea name="field_value[{{ $driver->id }}][{{ $columnName }}]" class="form-control">{{ $value }}</textarea>
        @elseif ($inputType === 'file')
        @if ($value)
            <!-- <p><img src="{{ asset('storage/' . $value) }}" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        @endif
        <input type="file" name="field_value[{{ $driver->id }}][{{ $columnName }}]" class="form-control">
        @elseif ($inputType === 'select')
    @php
        $otherSelected = $value === 'Other';
    @endphp

    <select name="field_value[{{ $driver->id }}][{{ $columnName }}]"
            class="form-control select-trigger"
            data-id="{{ $driver->id }}"
            data-column="{{ $columnName }}">
        <option value="Yes" {{ $value == 'Yes' ? 'selected' : '' }}>Yes</option>
        <option value="No" {{ $value == 'No' ? 'selected' : '' }}>No</option>
        <option value="Other" {{ $value == 'Other' ? 'selected' : '' }}>Other</option>
    </select>

       <input type="text" 
       name="other_value[{{ $driver->id }}][{{ $columnName }}]"
       class="form-control mt-2 other-input"
       id="other_input_{{ $driver->id }}_{{ $columnName }}"
       placeholder="Please specify"
       value="{{ old("other_value.$driver->id.$columnName") }}"
       style="{{ $value == 'Other' ? '' : 'display:none;' }}; width:850px;">


        @else
        <input type="{{ $inputType }}" name="field_value[{{ $driver->id }}][{{ $columnName }}]" value="{{ $value }}" class="form-control">
        @endif

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        @endforeach
        </div>
        </div>
        @endforeach
        </form>


        </div>
        </div>




         <!-- 🧍 Spot Data Tab -->
        <div class="tab-pane fade" id="spotData" role="tabpanel" aria-labelledby="spot-tab">
        <h5 class="mt-4" style="font-size:15px;">Spot Data</h5>

        @if ($report->spot_reassign_status == 1)


        <!-- <form action="{{ route('spot.re.assign') }}" method="POST" class="ajax-form">
        @csrf
        <input type="hidden" name="id" value="{{ $report->id }}">
        <button type="submit" class="btn btn-danger">Re-Assign</button>
        </form> -->

          <button type="button" class="btn btn-danger" style="margin-bottom:10px;" data-bs-toggle="modal"  data-bs-target="#reassignModal3"  data-report-id="{{ $report->id }}">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal3" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="{{ route('spot.re.assign') }}" method="POST" id="reassignForm">
                @csrf
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                @foreach ($users as $user)
                <option value="{{ $user->id }}">
                {{ $user->name }} ({{ $user->place }})
                </option>
                @endforeach
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>



        @endif

        @if ($report->spot_reassign_status == 0)
        <span class="badge bg-warning text-dark">Pending</span>
        @endif

        <div class="card p-3 mb-4">


           <form method="POST" action="{{ route('spot.text.update_new') }}" enctype="multipart/form-data">
                @csrf
                @foreach ($spotQuestions as $qIndex => $question)
                    @php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    @endphp

                <input type="hidden" name="tab" value="spotData">

                <div class="mb-4 border-bottom pb-2">
                <strong class="d-block mb-2" style="font-size: 14px;font-weight: 650;">{{ $question->question }}</strong>

                <div class="row">
                @foreach ($spotData as $spot)
                @php
                $value = $spot->$columnName ?? 'N/A';
                $radioId = "spot_radio_{$columnName}_{$spot->id}";
                $wrapperId = "spot_fieldWrapper_{$columnName}_{$spot->id}";

                $isChecked = $selectedGarageAnswers->contains(function ($item) use ($spot, $columnName) {
                return $item->garage_id === $spot->id && $item->column_name === $columnName;
                });

                @endphp

                <div class="col-md-4 mb-2 custom-desktop-width">

                @if (!empty($value) && strtolower(trim($value)) !== 'n/a')
                <div class="form-check mb-1">
                <input type="checkbox"
                class="form-check-input select-answer-checkbox-spot"
                name="selected_field[{{ $columnName }}][]"
                value="{{ $spot->id }}"
                data-column="{{ $columnName }}"
                data-value="{{ $value }}"
                data-case="{{ $report->case_id }}"
                data-spot-id="{{ $spot->id }}"
                id="{{ $radioId }}"
                style="border: 2px solid #4eab3c; width: 18px; height: 18px; accent-color: #4eab3c;"
                {{ $isChecked ? 'checked' : '' }}>
                <label class="form-check-label" for="{{ $radioId }}">Select this spot</label>
                </div>
                @endif


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="{{ $columnName }}:{{ $spot->id }}"
            id="{{ $radioId }}"
            data-target="#{{ $wrapperId }}">
                                     
            <!-- <label class="form-check-label" for="{{ $radioId }}"> -->

              @php
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
    $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));

    // Check if $value is a full URL or a relative path
    if (filter_var($value, FILTER_VALIDATE_URL)) {
        $filePath = $value;  // full URL already, use directly
    } else {
        $filePath = asset('storage/' . ltrim($value, '/'));  // relative path, build URL
    }
@endphp

@if (in_array($extension, $imageExtensions))




    <img src="{{ $filePath }}" 
     alt="Image" 
     class="img-thumbnail"
     style="width: 70px;        
    height: 70px;         
    border: 1px solid #ccc; 
    border-radius: 6px;    
    object-fit: cover;     
    cursor: pointer;  
    margin-bottom: 5px;  
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
     data-bs-toggle="modal" 
     data-bs-target="#imageModal3"
     onclick="showImageModal3('{{ $filePath }}', '{{ $radioId }}')">

    <br/>

@elseif (in_array($extension, $audioExtensions))
    <audio controls style="display: block; margin-bottom: 5px;">
        <source src="{{ $filePath }}" type="audio/{{ $extension }}">
        Your browser does not support the audio element.
    </audio>


            @else
            <p>
            @if ($inputType === 'select')
            @if ($value == 1)
            Yes
            @elseif ($value == 0)
            No
            @else
            {{ $value }}
            @endif
            @else
            {{ $value }}
            @endif
            </p>
            @endif


         
             <small>
              @if ($value !== null && $value !== '' && $value !== 'N/A')
            <span style="color: #007bff; font-weight: bold;font-size: 14px;">
            <i class="fas fa-user-tie me-1"></i> {{-- Font Awesome icon --}}
           {{ $spot->executive->name ?? 'N/A' }}
            </span>
            @endif
            </small>
            <br/>
                   @if ($value !== null && $value !== '' && $value !== 'N/A')
            {{ \Carbon\Carbon::parse($spot->updated_at)->format('d-m-Y h:i:s A') }}
             @endif
            </label>



        </div>

        <div class="d-none field-wrapper mt-2" id="{{ $wrapperId }}">
        @if ($inputType === 'textarea')
        <textarea name="field_value[{{ $spot->id }}][{{ $columnName }}]" class="form-control">{{ $value }}</textarea>
        @elseif ($inputType === 'file')
        @if ($value)
            <!-- <p><img src="{{ asset('storage/' . $value) }}" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        @endif
        <input type="file" name="field_value[{{ $spot->id }}][{{ $columnName }}]" class="form-control">
        @elseif ($inputType === 'select')
    @php
        $otherSelected = $value === 'Other';
    @endphp

    <select name="field_value[{{ $spot->id }}][{{ $columnName }}]"
            class="form-control select-trigger"
            data-id="{{ $spot->id }}"
            data-column="{{ $columnName }}">
        <option value="Yes" {{ $value == 'Yes' ? 'selected' : '' }}>Yes</option>
        <option value="No" {{ $value == 'No' ? 'selected' : '' }}>No</option>
        <option value="Other" {{ $value == 'Other' ? 'selected' : '' }}>Other</option>
    </select>

       <input type="text" 
       name="other_value[{{ $spot->id }}][{{ $columnName }}]"
       class="form-control mt-2 other-input"
       id="other_input_{{ $spot->id }}_{{ $columnName }}"
       placeholder="Please specify"
       value="{{ old("other_value.$spot->id.$columnName") }}"
       style="{{ $value == 'Other' ? '' : 'display:none;' }}; width:850px;">

        @else
        <input type="{{ $inputType }}" name="field_value[{{ $spot->id }}][{{ $columnName }}]" value="{{ $value }}" class="form-control">
        @endif

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        @endforeach
        </div>
        </div>
        @endforeach
        </form>

        
        </div>
        </div>



        <!-- 🧍 Owner Data Tab -->
        <div class="tab-pane fade" id="ownerData" role="tabpanel" aria-labelledby="owner-tab">
        <h5 class="mt-4" style="font-size:15px;">Owner Data</h5>

        @if ($report->owner_reassign_status == 1)

        <!-- <form action="{{ route('owner.re.assign') }}" method="POST" class="ajax-form">
        @csrf
        <input type="hidden" name="id" value="{{ $report->id }}">
        <button type="submit" class="btn btn-danger">Re-Assign</button>
        </form> -->

                <button type="button" class="btn btn-danger" style="margin-bottom:10px;" data-bs-toggle="modal"  data-bs-target="#reassignModal4"  data-report-id="{{ $report->id }}">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal4" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="{{ route('owner.re.assign') }}" method="POST" id="reassignForm">
                @csrf
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                @foreach ($users as $user)
                <option value="{{ $user->id }}">
                {{ $user->name }} ({{ $user->place }})
                </option>
                @endforeach
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>

        @endif

        @if ($report->owner_reassign_status == 0)
        <span class="badge bg-warning text-dark">Pending</span>
        @endif

        <div class="card p-3 mb-4">



           <form method="POST" action="{{route('owner.text.update_new')}}" enctype="multipart/form-data">
                @csrf
                @foreach ($ownerQuestions as $qIndex => $question)
                    @php
                        $columnName = $question->column_name;
                        $inputType = $question->input_type;
                    @endphp

                            <input type="hidden" name="tab" value="ownerData">

                    <div class="mb-4 border-bottom pb-2">
                        <strong class="d-block mb-2" style="font-size: 14px;font-weight: 650;">{{ $question->question }}</strong>

                        <div class="row">
                            @foreach ($ownerData as $owner)
                                @php
                                    $value = $owner->$columnName ?? 'N/A';
                                    $radioId = "owner_radio_{$columnName}_{$owner->id}";
                                    $wrapperId = "owner_fieldWrapper_{$columnName}_{$owner->id}";
                                   
                                    $isChecked = $selectedGarageAnswers->contains(function ($item) use ($owner, $columnName) {
                                    return $item->garage_id === $owner->id && $item->column_name === $columnName;
                                    });
                                    
                                @endphp

                <div class="col-md-4 mb-2 custom-desktop-width">

                @if (!empty($value) && strtolower(trim($value)) !== 'n/a')
                <div class="form-check mb-1">
                <input type="checkbox"
                class="form-check-input select-answer-checkbox-owner"
                name="selected_field[{{ $columnName }}][]"
                value="{{ $owner->id }}"
                data-column="{{ $columnName }}"
                data-value="{{ $value }}"
                data-case="{{ $report->case_id }}"
                data-owner-id="{{ $owner->id }}"
                id="{{ $radioId }}"
                style="border: 2px solid #4eab3c; width: 18px; height: 18px; accent-color: #4eab3c;"
                {{ $isChecked ? 'checked' : '' }}>
                <label class="form-check-label" for="{{ $radioId }}">Select this owner</label>
                </div>
                @endif


            <div class="form-check mb-1">
            <input type="radio" class="form-check-input toggle-edit"
            name="selected_field"
            value="{{ $columnName }}:{{ $owner->id }}"
            id="{{ $radioId }}"
            data-target="#{{ $wrapperId }}">
                                     
            <!-- <label class="form-check-label" for="{{ $radioId }}"> -->

               @php
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
    $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));

    // Check if $value is a full URL or a relative path
    if (filter_var($value, FILTER_VALIDATE_URL)) {
        $filePath = $value;  // full URL already, use directly
    } else {
        $filePath = asset('storage/' . ltrim($value, '/'));  // relative path, build URL
    }
@endphp

@if (in_array($extension, $imageExtensions))
    <img src="{{ $filePath }}" 
     alt="Image" 
     class="img-thumbnail"
     style="width: 70px;        
    height: 70px;         
    border: 1px solid #ccc; 
    border-radius: 6px;    
    object-fit: cover;     
    cursor: pointer;  
    margin-bottom: 5px;  
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
     data-bs-toggle="modal" 
     data-bs-target="#imageModal4"
     onclick="showImageModal4('{{ $filePath }}', '{{ $radioId }}')">
    <br/>

@elseif (in_array($extension, $audioExtensions))
    <audio controls style="display: block; margin-bottom: 5px;">
        <source src="{{ $filePath }}" type="audio/{{ $extension }}">
        Your browser does not support the audio element.
    </audio>

            @else
            <p>
            @if ($inputType === 'select')
            @if ($value == 1)
            Yes
            @elseif ($value == 0)
            No
            @else
            {{ $value }}
            @endif
            @else
            {{ $value }}
            @endif
            </p>
            @endif

            </p>

     
            <small>
          @if ($value !== null && $value !== '' && $value !== 'N/A')
            <span style="color: #007bff; font-weight: bold;font-size: 14px;">
            <i class="fas fa-user-tie me-1"></i> {{-- Font Awesome icon --}}
         {{ $owner->executive->name ?? 'N/A' }}
            </span>
            @endif
            </small>
            <br/>
             @if ($value !== null && $value !== '' && $value !== 'N/A')
            {{ \Carbon\Carbon::parse($owner->updated_at)->format('d-m-Y h:i:s A') }}
                @endif
            </label>



        </div>

      

<div class="field-wrapper mt-2" id="{{ $wrapperId }}" style="display: none;">

        @if ($inputType === 'textarea')
        <textarea name="field_value[{{ $owner->id }}][{{ $columnName }}]" class="form-control">{{ $value }}</textarea>
        @elseif ($inputType === 'file')

        
        @if ($value)
            <!-- <p><img src="{{ asset('storage/' . $value) }}" alt="Garage" style="max-width: 300px; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"></p> -->
        @endif
        <input type="file" name="field_value[{{ $owner->id }}][{{ $columnName }}]" class="form-control fa">
        @elseif ($inputType === 'select')
    @php
        $otherSelected = $value === 'Other';
    @endphp

    <select name="field_value[{{ $owner->id }}][{{ $columnName }}]"
            class="form-control select-trigger"
            data-id="{{ $owner->id }}"
            data-column="{{ $columnName }}">
        <option value="Yes" {{ $value == 'Yes' ? 'selected' : '' }}>Yes</option>
        <option value="No" {{ $value == 'No' ? 'selected' : '' }}>No</option>
        <option value="Other" {{ $value == 'Other' ? 'selected' : '' }}>Other</option>
    </select>

       <input type="text" 
       name="other_value[{{ $owner->id }}][{{ $columnName }}]"
       class="form-control mt-2 other-input"
       id="other_input_{{ $owner->id }}_{{ $columnName }}"
       placeholder="Please specify"
       value="{{ old("other_value.$owner->id.$columnName") }}"
       style="{{ $value == 'Other' ? '' : 'display:none;' }}; width:850px;">

        @else
        <input type="{{ $inputType }}" name="field_value[{{ $owner->id }}][{{ $columnName }}]" value="{{ $value }}" class="form-control">
        @endif

          
        <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
        </div>
        </div>
        @endforeach
        </div>
        </div>
        @endforeach
        </form>

        </div>
        </div>






         <!-- 🧍 Accident Person Data Tab -->
        <div class="tab-pane fade" id="accidentData" role="tabpanel" aria-labelledby="accident-tab">
        <h5 class="mt-4" style="font-size:15px;">Accident Person Data</h5>

        @if ($report->accident_person_reassign_status == 1)


        <!-- <form action="{{ route('accident.person.re.assign') }}" method="POST" class="ajax-form">
        @csrf
        <input type="hidden" name="id" value="{{ $report->id }}">
        <button type="submit" class="btn btn-danger">Re-Assign</button>
        </form> -->

           <button type="button" class="btn btn-danger" style="margin-bottom:10px;" data-bs-toggle="modal"  data-bs-target="#reassignModal5"  data-report-id="{{ $report->id }}">
                Re-Assign
                </button>

                <!-- Re-Assign Modal -->
                <div class="modal fade" id="reassignModal5" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <form action="{{ route('accident.person.re.assign') }}" method="POST" id="reassignForm">
                @
                
                <input type="hidden" name="id" id="modalReportId">

                <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="reassignModalLabel">Re-Assign Executive</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                <div class="mb-3">
                <label for="executive_id" class="form-label">Select Executive</label>
                <select class="form-select" name="executive_id" required>
                <option disabled selected>Select the executive</option>
                @foreach ($users as $user)
                <option value="{{ $user->id }}">
                {{ $user->name }} ({{ $user->place }})
                </option>
                @endforeach
                </select>
                </div>
                </div>

                <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Confirm Re-Assign</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </div>
                </form>
                </div>
                </div>

        @endif

        @if ($report->accident_person_reassign_status == 0)
        <span class="badge bg-warning text-dark">Pending</span>
        @endif

        <div class="card p-3 mb-4">




       <form method="POST" action="{{ route('accident.text.update_new') }}" enctype="multipart/form-data">
    @csrf

    @foreach ($accidentQuestions as $question)
        @php
            $columnName = $question->column_name;
            $inputType = $question->input_type;
        @endphp


                                    <input type="hidden" name="tab" value="accidentData">


        <div class="mb-4 border-bottom pb-2">
            <strong class="d-block mb-2" style="font-size: 14px; font-weight: 650;">
                {{ $question->question }}
            </strong>

            <div class="row">
                @foreach ($accidentPersonData as $accident)
                    @php
                        $value = $accident->$columnName ?? 'N/A';
                        $radioId = "accident_radio_{$columnName}_{$accident->id}";
                        $wrapperId = "accident_fieldWrapper_{$columnName}_{$accident->id}";

                        $isChecked = $selectedGarageAnswers->contains(function ($item) use ($accident, $columnName) {
                        return $item->garage_id === $accident->id && $item->column_name === $columnName;
                        });


                        $extension = strtolower(pathinfo($value, PATHINFO_EXTENSION));
                        $filePath = asset('storage/' . $value);
                        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
                        $audioExtensions = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a', 'wma', 'aiff', 'alac', 'opus'];
                     if (filter_var($value, FILTER_VALIDATE_URL)) {
        $filePath = $value;  // full URL already, use directly
    } else {
        $filePath = asset('storage/' . ltrim($value, '/'));  // relative path, build URL
    }

                        @endphp

                    @if (!empty($value) && strtolower(trim($value)) !== 'n/a')
                        <div class="col-md-4 mb-3 custom-desktop-width">
                            
                       
                            
                    <div class="form-check mb-1">            
                    <input type="checkbox" class="form-check-input select-answer-checkbox-accident"
                    name="selected_field[{{ $columnName }}]"
                    value="{{ $accident->id }}"
                    data-column="{{ $columnName }}"
                    data-value="{{ $value }}"
                    data-case="{{ $report->case_id }}"
                        data-accident-id="{{ $accident->id }}"
                    id="{{ $radioId }}"  style="border: 2px solid #4eab3c; width: 18px; height: 18px; accent-color: #4eab3c;" {{ $isChecked ? 'checked' : '' }}>

                    <label class="form-check-label" for="checkbox_{{ $radioId }}">
                    Select this accident
                    </label>

                    </div> 




                    
                            
                            
                            
                

                            <!-- ✅ Radio: select for editing -->
                            <div class="form-check mb-1">
                                <input
                                    type="radio"
                                    class="form-check-input toggle-edit"
                                    name="selected_field"
                                    value="{{ $columnName }}:{{ $accident->id }}"
                                    id="{{ $radioId }}"
                                    data-target="#{{ $wrapperId }}"
                                    style="border: 2px solid #0a0a0a; width: 18px; height: 18px; accent-color: #0a0a0a;"
                                >
                                <label class="form-check-label" for="{{ $radioId }}">
                                   
                                </label>
                            </div>

                                @if (in_array($extension, $imageExtensions))
                            
                        <!-- <img src="{{ $filePath }}" alt="Image" style="max-width: 100%; height: auto; border: 1px solid #ccc; margin-bottom: 5px;"><br/> -->
                                

    <img src="{{ $filePath }}" 
     alt="Image" 
     class="img-thumbnail"
     style="width: 70px;        
    height: 70px;         
    border: 1px solid #ccc; 
    border-radius: 6px;    
    object-fit: cover;     
    cursor: pointer;  
    margin-bottom: 5px;  
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
     data-bs-toggle="modal" 
     data-bs-target="#imageModal5"
     onclick="showImageModal5('{{ $filePath }}', '{{ $radioId }}')">
                                
                                    @elseif (in_array($extension, $audioExtensions))
                                    <audio controls style="width: 100%; margin-bottom: 5px;">
                                        <source src="{{ $filePath }}" type="audio/{{ $extension }}">
                                        Your browser does not support the audio element.
                                    </audio>
                                @else
                                    <p style="margin-bottom: 5px;">
                                        @if ($inputType === 'select')
                                            @if ($value == 1 || strtolower($value) == 'yes')
                                                Yes
                                            @elseif ($value == 0 || strtolower($value) == 'no')
                                                No
                                            @else
                                                {{ $value }}
                                            @endif
                                        @else
                                            {{ $value }}
                                        @endif
                                    </p>
                                @endif
<br/>
       <div class="form-check mb-1">
                                <!-- ✅ Executive name -->
                                @if (!empty($accident->executive->name))
                                    <small style="color: #007bff; font-weight: bold; font-size: 14px;">
                                        <i class="fas fa-user-tie me-1"></i>   {{ $accident->executive->name ?? 'N/A' }}
                                    </small>
                                @endif

                                <!-- ✅ Last update -->
                                @if ($accident->updated_at)
                                    <br>
                                    <small style="font-size: 13px;">{{ \Carbon\Carbon::parse($accident->updated_at)->format('d-m-Y h:i:s A') }}</small>
                                @endif
                            </label>
       </div>

                            <!-- ✅ Edit Field (shown when radio selected) -->
                            <div class="field-wrapper mt-2 d-none" id="{{ $wrapperId }}">
                                @if ($inputType === 'textarea')
                                    <textarea
                                        name="field_value[{{ $accident->id }}][{{ $columnName }}]"
                                        class="form-control"
                                    >{{ old("field_value.{$accident->id}.{$columnName}", $value) }}</textarea>

                                @elseif ($inputType === 'file')
                                    <input
                                        type="file"
                                        name="field_value[{{ $accident->id }}][{{ $columnName }}]"
                                        class="form-control"
                                    >

                                @elseif ($inputType === 'select')
                                    @php $otherSelected = ($value === 'Other'); @endphp

                                    <select
                                        name="field_value[{{ $accident->id }}][{{ $columnName }}]"
                                        class="form-control select-trigger"
                                        data-id="{{ $accident->id }}"
                                        data-column="{{ $columnName }}"
                                    >
                                        <option value="Yes" {{ $value == 'Yes' ? 'selected' : '' }}>Yes</option>
                                        <option value="No" {{ $value == 'No' ? 'selected' : '' }}>No</option>
                                        <option value="Other" {{ $value == 'Other' ? 'selected' : '' }}>Other</option>
                                    </select>

                                    <input
                                        type="text"
                                        name="other_value[{{ $accident->id }}][{{ $columnName }}]"
                                        class="form-control mt-2 other-input"
                                        id="other_input_{{ $accident->id }}_{{ $columnName }}"
                                        placeholder="Please specify"
                                        value="{{ old("other_value.{$accident->id}.{$columnName}") }}"
                                        style="{{ $otherSelected ? '' : 'display:none;' }}; width: 100%;"
                                    >

                                @else
                                    <input
                                        type="{{ $inputType }}"
                                        name="field_value[{{ $accident->id }}][{{ $columnName }}]"
                                        value="{{ old("field_value.{$accident->id}.{$columnName}", $value) }}"
                                        class="form-control"
                                    >
                                @endif

                                <button type="submit" class="btn btn-sm btn-primary mt-2">Update</button>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    @endforeach
</form>


        </div>
        </div>


</div>


    <hr>

    </div>
    </div>

    </div>


<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<style>
.form-check-input[type=radio] 
{
    border-color: black;
}




    #garage-tab.nav-link.active {
        color: #0d6efd !important; /* Bootstrap primary */
        border-bottom: 3px solid #0d6efd;
        background-color: transparent;
    }

    #driver-tab.nav-link.active {
        color: #0dcaf0 !important; /* Bootstrap info */
        border-bottom: 3px solid #0dcaf0;
        background-color: transparent;
    }

    #spot-tab.nav-link.active {
        color: #ffc107 !important; /* Bootstrap warning */
        border-bottom: 3px solid #ffc107;
        background-color: transparent;
    }

    #owner-tab.nav-link.active {
        color: #198754 !important; /* Bootstrap success */
        border-bottom: 3px solid #198754;
        background-color: transparent;
    }

    #accident-tab.nav-link.active {
        color: #dc3545 !important; /* Bootstrap danger */
        border-bottom: 3px solid #dc3545;
        background-color: transparent;
    }


   /* ✅ Mobile-first default (applies to all screens by default) */
.custom-desktop-width {
   width: 32%;
    border: 1px solid #ccc; 
    padding: 10px;
     border-radius: 5px; 
     margin-right: 1%;
}

/* ✅ Tablet and above (min-width: 768px) */
@media only screen and (max-width: 768px) {
    .custom-desktop-width {
        width: 100%;
        margin-right: 2%;
    }
}


</style>



<script>
function showImageModal(filePath, checkboxId) {
    // Set full-size image
    document.getElementById('modalImage').src = filePath;

    // Copy the state & data of original checkbox
    const originalCheckbox = document.getElementById(checkboxId);
    const modalCheckbox = document.getElementById('modalCheckbox');
    const modalLabel = document.getElementById('modalCheckboxLabel');

    modalCheckbox.checked = originalCheckbox.checked;
    modalCheckbox.dataset.column = originalCheckbox.dataset.column;
    modalCheckbox.dataset.value = originalCheckbox.dataset.value;
    modalCheckbox.dataset.case = originalCheckbox.dataset.case;
    modalLabel.innerText = "Select this garage";

    // When modal checkbox changes, update original checkbox + trigger AJAX
    modalCheckbox.onchange = function() {
        originalCheckbox.checked = this.checked;
        $(originalCheckbox).trigger('change'); // fires your existing AJAX code
    };
}

function showImageModal2(filePath, checkboxId) {
    // Set full-size image
    document.getElementById('modalImage2').src = filePath;

    // Copy the state & data of original checkbox
    const originalCheckbox = document.getElementById(checkboxId);
    const modalCheckbox = document.getElementById('modalCheckbox2');
    const modalLabel = document.getElementById('modalCheckboxLabel2');

    modalCheckbox.checked = originalCheckbox.checked;
    modalCheckbox.dataset.column = originalCheckbox.dataset.column;
    modalCheckbox.dataset.value = originalCheckbox.dataset.value;
    modalCheckbox.dataset.case = originalCheckbox.dataset.case;
    modalLabel.innerText = "Select this driver";

    // When modal checkbox changes, update original checkbox + trigger AJAX
    modalCheckbox.onchange = function() {
        originalCheckbox.checked = this.checked;
        $(originalCheckbox).trigger('change'); // fires your existing AJAX code
    };
}



function showImageModal3(filePath, checkboxId) {
    // Set full-size image
    document.getElementById('modalImage3').src = filePath;

    // Copy the state & data of original checkbox
    const originalCheckbox = document.getElementById(checkboxId);
    const modalCheckbox = document.getElementById('modalCheckbox3');
    const modalLabel = document.getElementById('modalCheckboxLabel3');

    modalCheckbox.checked = originalCheckbox.checked;
    modalCheckbox.dataset.column = originalCheckbox.dataset.column;
    modalCheckbox.dataset.value = originalCheckbox.dataset.value;
    modalCheckbox.dataset.case = originalCheckbox.dataset.case;
    modalLabel.innerText = "Select this spot";

    // When modal checkbox changes, update original checkbox + trigger AJAX
    modalCheckbox.onchange = function() {
        originalCheckbox.checked = this.checked;
        $(originalCheckbox).trigger('change'); // fires your existing AJAX code
    };
}


function showImageModal4(filePath, checkboxId) {
    // Set full-size image
    document.getElementById('modalImage4').src = filePath;

    // Copy the state & data of original checkbox
    const originalCheckbox = document.getElementById(checkboxId);
    const modalCheckbox = document.getElementById('modalCheckbox4');
    const modalLabel = document.getElementById('modalCheckboxLabel4');

    modalCheckbox.checked = originalCheckbox.checked;
    modalCheckbox.dataset.column = originalCheckbox.dataset.column;
    modalCheckbox.dataset.value = originalCheckbox.dataset.value;
    modalCheckbox.dataset.case = originalCheckbox.dataset.case;
    modalLabel.innerText = "Select this owner";

    // When modal checkbox changes, update original checkbox + trigger AJAX
    modalCheckbox.onchange = function() {
        originalCheckbox.checked = this.checked;
        $(originalCheckbox).trigger('change'); // fires your existing AJAX code
    };
}
function showImageModal5(filePath, checkboxId) {
    // Set full-size image
    document.getElementById('modalImage5').src = filePath;

    // Copy the state & data of original checkbox
    const originalCheckbox = document.getElementById(checkboxId);
    const modalCheckbox = document.getElementById('modalCheckbox5');
    const modalLabel = document.getElementById('modalCheckboxLabel5');

    modalCheckbox.checked = originalCheckbox.checked;
    modalCheckbox.dataset.column = originalCheckbox.dataset.column;
    modalCheckbox.dataset.value = originalCheckbox.dataset.value;
    modalCheckbox.dataset.case = originalCheckbox.dataset.case;
    modalLabel.innerText = "Select this accident";

    // When modal checkbox changes, update original checkbox + trigger AJAX
    modalCheckbox.onchange = function() {
        originalCheckbox.checked = this.checked;
        $(originalCheckbox).trigger('change'); // fires your existing AJAX code
    };
}


</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        lightbox.option({
            'resizeDuration': 200,
            'wrapAround': true,
            'fadeDuration': 300
        });
    </script>


<script>

document.querySelectorAll('.toggle-edit').forEach(radio => {
  radio.addEventListener('change', () => {
    const target = document.querySelector(radio.dataset.target);
    if (target) target.style.display = 'block';
  });
});


    // function confirmFakeData() {
    //     if (confirm("Are you sure  want to mark this section as fake data?")) {
    //         document.getElementById('fakeDataForm').submit();
    //     }
    // }

    function submitFakeDataForm() {
    document.getElementById('fakeDataForm').submit();
}




    document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.select-trigger').forEach(function (select) {
    select.addEventListener('change', function () {
    const garageId = this.dataset.id;
    const column = this.dataset.column;
    const input = document.getElementById(`other_input_${garageId}_${column}`);

    if (this.value === 'Other') {
        input.style.display = 'block';
    } else {
        input.style.display = 'none';
        input.value = ''; // Optional: clear text if not Other
    }
    });
    });
    });

 
    document.addEventListener('DOMContentLoaded', function () {
        const reassignModal = document.getElementById('reassignModal');
        reassignModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const reportId = button.getAttribute('data-report-id');
            document.getElementById('modalReportId').value = reportId;
        });
    });


      document.addEventListener('DOMContentLoaded', function () {
        const reassignModal = document.getElementById('reassignModal2');
        reassignModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const reportId = button.getAttribute('data-report-id');
            document.getElementById('modalReportId').value = reportId;
        });
    });

     document.addEventListener('DOMContentLoaded', function () {
        const reassignModal = document.getElementById('reassignModal3');
        reassignModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const reportId = button.getAttribute('data-report-id');
            document.getElementById('modalReportId').value = reportId;
        });
    });

        document.addEventListener('DOMContentLoaded', function () {
        const reassignModal = document.getElementById('reassignModal4');
        reassignModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const reportId = button.getAttribute('data-report-id');
            document.getElementById('modalReportId').value = reportId;
        });
    });

        document.addEventListener('DOMContentLoaded', function () {
        const reassignModal = document.getElementById('reassignModal5');
        reassignModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const reportId = button.getAttribute('data-report-id');
            document.getElementById('modalReportId').value = reportId;
        });
    });

</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const radios = document.querySelectorAll('.toggle-edit');
        const wrappers = document.querySelectorAll('.field-wrapper');
        const submitBtn = document.getElementById('submitButtonWrapper');

        radios.forEach(radio => {
            radio.addEventListener('change', function () {
                // Hide all inputs
                wrappers.forEach(w => w.classList.add('d-none'));

                // Show the matching one
                const targetId = this.getAttribute('data-target');
                const targetWrapper = document.querySelector(targetId);
                if (targetWrapper) {
                    targetWrapper.classList.remove('d-none');
                }

                // Show submit button
                submitBtn.classList.remove('d-none');
            });
        });
    });
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    // ===== Gate Entry Radios =====
    const gateRadios = document.querySelectorAll('.toggle-gate');
    const gateInputs = document.querySelectorAll('.garage-input-gate');
    const gateButton = document.getElementById('updateGateButtonWrapper');

    gateRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            gateInputs.forEach(input => input.classList.add('d-none'));
            const input = document.getElementById(this.dataset.inputId);
            if (input) input.classList.remove('d-none');
            if (gateButton) gateButton.classList.remove('d-none');
        });
    });

    // ===== Garage Job Card Radios =====
    const jobRadios = document.querySelectorAll('.toggle-job');
    const jobInputs = document.querySelectorAll('.garage-input-job');
    const jobButton = document.getElementById('updateJobButtonWrapper');

    jobRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            jobInputs.forEach(input => input.classList.add('d-none'));
            const input = document.getElementById(this.dataset.inputId);
            if (input) input.classList.remove('d-none');
            if (jobButton) jobButton.classList.remove('d-none');
        });
    });

    // ===== Fitness Particular Radios =====
    const fitnessRadios = document.querySelectorAll('.toggle-fitness');
    const fitnessSelects = document.querySelectorAll('.garage-select-fitness');
    const fitnessButton = document.getElementById('fitnessButton');

    fitnessRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            fitnessSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`fitnessSelect${radio.id.replace('fitnessCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (fitnessButton) fitnessButton.classList.remove('d-none');
        });
    });

    const permitRadios = document.querySelectorAll('.toggle-permit');
    const permitSelects = document.querySelectorAll('.garage-select-permit');
    const permitButton = document.getElementById('permitButton');

    permitRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            permitSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`permitSelect${radio.id.replace('permitCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (permitButton) permitButton.classList.remove('d-none');
        });
    });

    const particularRadios = document.querySelectorAll('.toggle-particular');
    const particularSelects = document.querySelectorAll('.garage-select-particular');
    const particularButton = document.getElementById('particularButton');

    particularRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            particularSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`particularSelect${radio.id.replace('particularCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (particularButton) particularButton.classList.remove('d-none');
        });
    });


    const motorRadios = document.querySelectorAll('.toggle-motor');
    const motorSelects = document.querySelectorAll('.garage-select-motor');
    const motorButton = document.getElementById('motorButton');

    motorRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            motorSelects.forEach(select => select.classList.add('d-none'));
            const select = document.getElementById(`motorSelect${radio.id.replace('motorCheck', '')}`);
            if (select) select.classList.remove('d-none');
            if (motorButton) motorButton.classList.remove('d-none');
        });
    });


});
</script>


<script>
    $(document).ready(function() {
        $('.ajax-form').on('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            var form = $(this);
            var url = form.attr('action');
            var formData = form.serialize(); // Serialize the form data

            $.ajax({
                type: 'POST',
                url: url,
                data: formData,
                success: function(response) {
                    // Handle success (show message, update UI, etc.)
                    alert('Re-Assigned successfully!');
                },
                error: function(xhr, status, error) {
                    // Handle error
                    alert('An error occurred: ' + error);
                }
            });
        });
    });
</script>

<script>
    function editFieldDriver(id) {
        const form = document.getElementById('edit-form' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldGarage(id) {
        const form = document.getElementById('edit-form-garage' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldSpot(id) {
        const form = document.getElementById('edit-form-spot' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldOwner(id) {
        const form = document.getElementById('edit-form-owner' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }

    function editFieldAccident(id) {
        const form = document.getElementById('edit-form-accident' + id);
        if (form.style.display === 'block') {
            form.style.display = 'none';
        } else {
            form.style.display = 'block';
        }
    }





$('input.select-answer-checkbox-garage').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');
    const garageId = $(this).data('garage-id');
    const isChecked = $(this).is(':checked') ? 1 : 0;

    $.ajax({
        url: "{{ route('save.selected') }}",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            garage_id: garageId,
            is_checked: isChecked,
            _token: '{{ csrf_token() }}'
        },
        success: function (response) {
            console.log(response.message);
        },
        error: function (xhr) {
            console.error('Error saving selection');
        }
    });
});



   

    // $('input.select-answer-checkbox-driver').on('change', function () {
    // const columnName = $(this).data('column');
    // const value = $(this).data('value');
    // const caseId = $(this).data('case');

    // if ($(this).is(':checked')) 
    // {
    // $(this).closest('.form-check').addClass('bg-success text-white'); 
    // } 
    // else 
    // {
    // $(this).closest('.form-check').removeClass('bg-success text-white');
    // }

    // $.ajax({
    // url: "{{ route('save.selected') }}",
    // method: 'POST',
    // data: {
    // column_name: columnName,
    // value: value,
    // case_id: caseId,
    // _token: '{{ csrf_token() }}'
    // },
    // success: function (response) {
    // console.log('Answer updated:', response.data.message);
    // },
    // error: function (xhr, status, error) {
    // console.error('Error updating answer:', error);
    // }
    // });
    // });



    $('input.select-answer-checkbox-driver').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');
    const garageId = $(this).data('driver-id');
    const isChecked = $(this).is(':checked') ? 1 : 0;

    $.ajax({
        url: "{{ route('save.selected') }}",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            garage_id: garageId,
            is_checked: isChecked,
            _token: '{{ csrf_token() }}'
        },
        success: function (response) {
            console.log(response.message);
        },
        error: function (xhr) {
            console.error('Error saving selection');
        }
    });
});


//    $('input.select-answer-checkbox-spot').on('change', function () {
//     const columnName = $(this).data('column');
//    const value = $(this).data('value');
//      const caseId = $(this).data('case');

//    if ($(this).is(':checked')) {
//     $(this).closest('.form-check').addClass('bg-success text-white'); // green background
//      } else {
//    $(this).closest('.form-check').removeClass('bg-success text-white');
//     }


//    $.ajax({
//      url: "{{ route('save.selected') }}",
//     method: 'POST',
//     data: {
//    column_name: columnName,
//     value: value,
//     case_id: caseId,
//    _token: '{{ csrf_token() }}'
//     },
//      success: function (response) {
//    console.log('Answer updated:', response.data.message);
//     },
//    error: function (xhr, status, error) {
//     console.error('Error updating answer:', error);
//     }
//     });
//      });




  $('input.select-answer-checkbox-spot').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');
    const garageId = $(this).data('spot-id');
    const isChecked = $(this).is(':checked') ? 1 : 0;

    $.ajax({
        url: "{{ route('save.selected') }}",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            garage_id: garageId,
            is_checked: isChecked,
            _token: '{{ csrf_token() }}'
        },
        success: function (response) {
            console.log(response.message);
        },
        error: function (xhr) {
            console.error('Error saving selection');
        }
    });
});





    // $('input.select-answer-checkbox-owner').on('change', function () {
    // const columnName = $(this).data('column');
    // const value = $(this).data('value');
    // const caseId = $(this).data('case');

    // if ($(this).is(':checked')) 
    // {
    // $(this).closest('.form-check').addClass('bg-success text-white'); // green background
    // } 
    // else 
    // {
    // $(this).closest('.form-check').removeClass('bg-success text-white');
    // }

    // $.ajax({
    // url: "{{ route('save.selected') }}",
    // method: 'POST',
    // data: {
    // column_name: columnName,
    // value: value,
    // case_id: caseId,
    // _token: '{{ csrf_token() }}'
    // },
    // success: function (response) {
    // console.log('Answer updated:', response.data.message);
    // },
    // error: function (xhr, status, error) {
    // console.error('Error updating answer:', error);
    // }
    // });
    // });



    $('input.select-answer-checkbox-owner').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');
    const garageId = $(this).data('owner-id');
    const isChecked = $(this).is(':checked') ? 1 : 0;

    $.ajax({
        url: "{{ route('save.selected') }}",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            garage_id: garageId,
            is_checked: isChecked,
            _token: '{{ csrf_token() }}'
        },
        success: function (response) {
            console.log(response.message);
        },
        error: function (xhr) {
            console.error('Error saving selection');
        }
    });
});


    //  $('input.select-answer-checkbox-accident').on('change', function () {
    // const columnName = $(this).data('column');
    // const value = $(this).data('value');
    // const caseId = $(this).data('case');

    // if ($(this).is(':checked')) {
    // $(this).closest('.form-check').addClass('bg-success text-white'); // green background
    // } else {
    // $(this).closest('.form-check').removeClass('bg-success text-white');
    // }

    // $.ajax({
    // url: "{{ route('save.selected') }}",
    // method: 'POST',
    // data: {
    // column_name: columnName,
    // value: value,
    // case_id: caseId,
    // _token: '{{ csrf_token() }}'
    // },
    // success: function (response) {
    // console.log('Answer updated:', response.data.message);
    // },
    // error: function (xhr, status, error) {
    // console.error('Error updating answer:', error);
    // }
    // });
    // });


      $('input.select-answer-checkbox-accident').on('change', function () {
    const columnName = $(this).data('column');
    const value = $(this).data('value');
    const caseId = $(this).data('case');
    const garageId = $(this).data('accident-id');
    const isChecked = $(this).is(':checked') ? 1 : 0;

    $.ajax({
        url: "{{ route('save.selected') }}",
        method: 'POST',
        data: {
            column_name: columnName,
            value: value,
            case_id: caseId,
            garage_id: garageId,
            is_checked: isChecked,
            _token: '{{ csrf_token() }}'
        },
        success: function (response) {
            console.log(response.message);
        },
        error: function (xhr) {
            console.error('Error saving selection');
        }
    });
});


</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const hash = window.location.hash;

        if (hash) {
            const tabTrigger = document.querySelector(`button[data-bs-target="${hash}"]`);
            if (tabTrigger) {
                const tab = new bootstrap.Tab(tabTrigger);
                tab.show();

                // OPTIONAL: Clean up the URL by removing the hash
                history.replaceState(null, null, window.location.pathname);
            }
        }
    });
</script>


@endsection
