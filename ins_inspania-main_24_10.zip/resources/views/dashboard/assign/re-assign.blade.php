<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-md-12">
            <div class="card shadow-lg rounded-lg border-0">
                <!-- Card Header -->
                <div class="card-header bg-primary text-white">
                    <h4 class="m-0 font-weight-bold">Re Assign Case</h4>
                </div>

                <!-- Card Body -->
                <div class="card-body">
                    <form action="{{ route('re.assign.update') }}" method="POST" id="caseUpdate">
                        @csrf
                        <input type="hidden" name="id" value="{{ $cases->id }}" required>

                        <!-- Customer & Company Info -->
                        <div class="mb-3">
                            <p><strong>Customer Name:</strong> {{ $customer->name }}</p>
                            <p><strong>Company Name:</strong> {{ $company->name }}</p>
                            <p><strong>Case Type:</strong> {{ $cases->type }}</p>
                        </div>

                        <!-- <div id="successMessage" class="alert alert-success d-none"></div> -->

                        <div id="successMessage" class="alert alert-success alert-dismissible fade show mb-3 d-none" 
                            style="margin-left: 20px;align-items: center;">
                        <i class="fa fa-check-circle me-2"></i>
                        <span id="successText"></span>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>

                        
                        <hr class="mb-4">

                        <!-- Two Column Layout -->
                        <div class="row">
                            <!-- Left Column -->
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="driver" class="font-weight-bold">Select Executive (Driver)</label>
                                    <select id="driver" name="driver" class="form-control" required>
                                        <option disabled>Select the executive</option>
                                        @foreach ($executives as $user)
                                            <option value="{{ $user->id }}" {{ $user->id == $cases->executive_driver ? 'selected' : '' }}>
                                                {{ $user->name }} ({{ $user->place }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="spot" class="font-weight-bold">Select Executive (Spot)</label>
                                    <select id="spot" name="spot" class="form-control" required>
                                        <option disabled>Select the executive</option>
                                        @foreach ($executives as $user)
                                            <option value="{{ $user->id }}" {{ $user->id == $cases->executive_spot ? 'selected' : '' }}>
                                                {{ $user->name }} ({{ $user->place }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="date" class="font-weight-bold">Investigation Date</label>
                                    <input type="date" name="date" id="date" class="form-control" value="{{ $cases->date }}">
                                </div>
                            </div>

                            <!-- Right Column -->
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="garage" class="font-weight-bold">Select Executive (Garage)</label>
                                    <select id="garage" name="garage" class="form-control" required>
                                        <option disabled>Select the executive</option>
                                        @foreach ($executives as $user)
                                            <option value="{{ $user->id }}" {{ $user->id == $cases->executive_garage ? 'selected' : '' }}>
                                                {{ $user->name }} ({{ $user->place }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="meeting" class="font-weight-bold">Select Executive (Meeting)</label>
                                    <select id="meeting" name="meeting" class="form-control" required>
                                        <option disabled>Select the executive</option>
                                        @foreach ($executives as $user)
                                            <option value="{{ $user->id }}" {{ $user->id == $cases->executive_meeting ? 'selected' : '' }}>
                                                {{ $user->name }} ({{ $user->place }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                               {{-- @if ($cases->type === 'MAC') --}}
                                <div class="mb-3">
                                    <label for="accident_person" class="font-weight-bold">Select Executive (Accident Person)</label>
                                    <select id="accident_person" name="accident_person" class="form-control" required>
                                        <option disabled>Select the executive</option>
                                        @foreach ($executives as $user)
                                            <option value="{{ $user->id }}" {{ $user->id == $cases->executive_accident_person ? 'selected' : '' }}>
                                                {{ $user->name }} ({{ $user->place }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                             

                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-right mt-4">
                            <button type="submit" class="btn btn-primary px-4">Update</button>
                        </div>
                    </form>
                </div> <!-- Card Body -->
            </div> <!-- Card -->
        </div>
    </div>
</div>


    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->

   <script>
    $(document).ready(function() {
$('#caseUpdate').on('submit', function(e) {
    e.preventDefault();

    $.ajax({
        url: '{{ route('re.assign.update') }}',
        type: 'POST',
        data: $(this).serialize(),
        success: function (response)
        {
        if (response.success) {
        // Set the message text inside the <span>, not the entire alert div
        $('#successText').text(response.success);

        // Remove the 'd-none' class to show the alert
        $('#successMessage').removeClass('d-none');

        // Reset the form fields and clear error messages
        $('#caseForm')[0].reset();
        $('.text-danger').text('');

        // Hide after 8 seconds and reload the page
        setTimeout(function () {
        $('#successMessage').addClass('d-none');
        location.reload();
        }, 4000);
        }
        },
        error: function(xhr) 
        {
            var errors = xhr.responseJSON.errors;
            $('.text-danger').text(''); // Clear previous error messages
            $.each(errors, function(key, value) {
                $('#' + key + '-error').text(value);
            });
        }
    });
});
});

    </script> 



 




