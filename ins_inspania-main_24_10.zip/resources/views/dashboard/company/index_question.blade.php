@extends('dashboard.layout.app')
@section('title', 'Questionnaire List')


@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-clipboard me-2 text-primary"></i> Questionnaire List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Questionnaires</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('company.create_question') }}" class="btn btn-primary">
                <i class="fas fa-clipboard me-1"></i> Add Questionnaire
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0" style="color: #fff;">Questionnaires</h5>
                <!-- <small class="text-white-50">Total: {{ $questions->count() }}</small> -->
            </div>

            <div class="card-body p-0">
                @if($questions->isEmpty())
                    <div class="p-4 text-center text-muted fst-italic">
                        No questions found.
                    </div>
                @else
                    <div class="table-responsive p-3 mb-3">
                        <table id="questionsTable" class="table table-bordered table-hover text-center align-middle mb-0" style="width:100%">
                             <thead class="thead-dark text-start">
                                <tr>
                                    <th style="width: 50px;">ID</th>
                                    <th>Question</th>
                                    <!-- <th>Input Type</th> -->
                                    <th>Category</th>
                                    <th>Templates</th>
                                    <th style="width: 120px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $i = 1; @endphp
                                @foreach($questions as $q)
                                    <tr>
                                        <td class="text-start">{{ $i++ }}</td>
                                        <td class="text-start">{{ $q->question }}</td>
                                        <!-- <td>{{ $q->input_type }}</td> -->
                                         @php
    $categories = [
        'garage_data' => 'Garage Data',
        'spot_data' => 'Spot Data',
        'owner_data' => 'Owner Data',
        'driver_data' => 'Driver Data',
        'accident_person_data' => 'Accident Person Data',
    ];
@endphp

<td class="text-start">{{ $categories[$q->data_category] ?? ucfirst(str_replace('_', ' ', $q->data_category)) }}</td>
                                        <td class="text-start">
                                            @if($q->templates->isNotEmpty())
                                                @foreach($q->templates as $template)
                                                    <span class="badge bg-primary">{{ $template->template_id }}</span>
                                                @endforeach
                                            @else
                                                <span class="text-muted">Not Assigned</span>
                                            @endif
                                        </td>
                                        <td class="text-start">
                                            <a href="{{ route('questions.edit_question', $q->id) }}" class="btn btn-sm btn-info" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                         

                                               <button type="button" 
        class="btn btn-sm btn-danger btn-delete" 
        data-bs-toggle="modal" 
        data-bs-target="#deleteModal" 
        data-url="{{ route('questions.destroy_question', $q->id) }}"
        title="Delete">
    <i class="fa-solid fa-trash-can"></i>
</button>


                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>

    </div>
</div>


<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" id="deleteForm">
      @csrf
      @method('DELETE')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Are you sure you want to delete this questions?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
        </div>
      </div>
    </form>
  </div>
</div>



<script>
document.addEventListener('DOMContentLoaded', function () {
  var deleteModal = document.getElementById('deleteModal');
  var deleteForm = document.getElementById('deleteForm');

  // Attach click event to all delete buttons
  document.querySelectorAll('.btn-delete').forEach(function(button) {
    button.addEventListener('click', function() {
      var url = this.getAttribute('data-url');
      deleteForm.setAttribute('action', url);
    });
  });
});
</script>



<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">


<style>
@media (max-width: 576px) {
    /* Hide only the Action column header */
    #questionsTable th:nth-child(6) {
        display: none !important;
    }

    /* Hide only the "Action" title in responsive child rows, keep the data visible */
    li[data-dtr-index="5"] > span.dtr-title {
        display: none !important;
    }
}
.card-header
{
border-bottom: unset;
}

</style>

  <script>
    $(document).ready(function () {
        const table = $('#questionsTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search Questionnaires..."
                },
                columnDefs: [
                    { orderable: false, targets: [4] } // Disable sorting on the "Action" column
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }
    });
</script>

  

@endsection
