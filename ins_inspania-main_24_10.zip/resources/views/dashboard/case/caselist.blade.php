<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Case Report -  {{ $executive->name }}</title>

    <!-- ✅ Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Optional: Google Fonts / Custom Styling -->
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
        }
        .nav-tabs .nav-link.active {
            font-weight: bold;
            border-bottom: 3px solid #0d6efd;
        }
        .fs-3 {
            font-size: 1.75rem;
        }
        h2 {
            margin-top: 20px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

   <div class="container">
    <h2 class="text-center mb-4">Case Report for Executive - {{ $executive->name }}</h2>

    {{-- Tabs (optional, can be included above if needed) --}}
    @php
        $periods = ['daily', 'weekly', 'monthly'];
    @endphp

    {{-- Report Table --}}
    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle text-center">
            <thead class="table-success">
                <tr>
                    <th>#</th>
                    <th>Company Name</th>
                    <th>Customer Name</th>
                    <th>Case Type</th>
                    <th>Phone</th>
                    <th>Crime Number</th>
                    <th>Policy Number</th>
                    <th>Police Station</th>
                    <th>Investigation Date</th>
                </tr>
            </thead>
            <tbody>
                @forelse($caselist as $index => $reading)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $reading->company_name ?? '-' }}</td>
                        <td>{{ $reading->customer_name ?? '-' }}</td>
                        <td>{{ $reading->insurance_type ?? '-' }}</td>
                        <td>{{ $reading->customer_phone ?? '-' }}</td>
                        <td>{{ $reading->crime_number ?? '-' }}</td>
                        <td>{{ $reading->policy_no ?? '-' }}</td>
                        <td>{{ $reading->police_station ?? '-' }}</td>
                        <td>{{ \Carbon\Carbon::parse($reading->date)->format('d-m-Y') }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="text-center text-muted">No data found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>


    <!-- ✅ Bootstrap JS Bundle (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
