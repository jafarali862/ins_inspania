@extends('dashboard.layout.app')

@section('title', 'Odometer View')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-building me-2 text-primary"></i> Odometer List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Odometer List</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
         
        </div>

        <!-- Card -->
       <div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Odometer Reading Details</h5>
    </div>

    <div class="card-body">
        <h5 class="card-title">Executive Name: <span class="text-primary">{{ $record->user_name }}</span></h5>
        <hr class="my-4">

        <div class="row mb-4">
            {{-- Check In --}}
            <div class="col-md-4">
                <p><strong>Check In KM:</strong> <span class="text-muted">{{ $record->check_in_km }}</span></p>
                <p><strong>Check In Time:</strong> <span class="text-muted">{{ $record->check_in_time }}</span></p>
                <p><strong>Check In Date:</strong> <span class="text-muted">{{ $record->check_in_date }}</span></p>
                <p><strong>Check In Location:</strong> <span class="text-muted">{{ $record->check_in_latitude_and_longitude ?? 'N/A' }}</span></p>
            </div>

            {{-- Check Out --}}
            <div class="col-md-4">
                <p><strong>Check Out KM:</strong> <span class="text-muted">{{ $record->check_out_km ?? 'N/A' }}</span></p>
                <p><strong>Check Out Time:</strong> <span class="text-muted">{{ $record->check_out_time ?? 'N/A' }}</span></p>
                <p><strong>Check Out Date:</strong> <span class="text-muted">{{ $record->check_out_date ?? 'N/A' }}</span></p>
                <p><strong>Check Out Location:</strong> <span class="text-muted">{{ $record->check_out_latitude_and_longitude ?? 'N/A' }}</span></p>
            </div>

            {{-- Totals & Duration --}}
            <div class="col-md-4">
                {{-- Total KM --}}
                @php
                    $totalKm = $record->check_out_km ? $record->check_out_km - $record->check_in_km : null;
                @endphp
                <p>
                    <strong>Total KM:</strong>
                    <span class="text-muted {{ $totalKm < 0 ? 'text-danger' : '' }}">
                        {{ $totalKm !== null ? $totalKm : 'Check Out KM not recorded' }}
                    </span>
                    @if ($totalKm < 0)
                        <span class="badge badge-danger ml-2">Wrong</span>
                    @endif
                </p>

                {{-- Work Duration --}}
                @php
                    $duration = null;
                    if ($record->check_in_time && $record->check_out_time) {
                        try {
                            $checkInTime = \Carbon\Carbon::createFromFormat('h:i A', $record->check_in_time);
                            $checkOutTime = \Carbon\Carbon::createFromFormat('h:i A', $record->check_out_time);
                            $duration = $checkOutTime->diff($checkInTime);
                        } catch (Exception $e) {
                            // Handle parsing error gracefully
                        }
                    }
                @endphp
                <p>
                    <strong>Work Duration:</strong>
                    <span class="text-muted">
                        @if ($duration)
                            {{ $duration->format('%h hours %i minutes') }}
                        @else
                            Check out time not recorded
                        @endif
                    </span>
                </p>
            </div>
        </div>

        {{-- Images --}}
        <div class="row">
            <div class="col-md-4">
                <p><strong>Check In Image:</strong></p>
                @if ($record->check_in_image)
                    <a href="{{ asset('storage/' . $record->check_in_image) }}" data-lightbox="checkin" data-title="Check In Image">
                        <img src="{{ asset('storage/' . $record->check_in_image) }}" alt="Check In Image" class="img-fluid rounded shadow-sm" style="max-width: 100%; height: auto;" />
                    </a>
                @else
                    <span class="text-warning">N/A</span>
                @endif
            </div>

            <div class="col-md-4">
                <p><strong>Check Out Image:</strong></p>
                @if ($record->check_out_image)
                    <a href="{{ asset('storage/' . $record->check_out_image) }}" data-lightbox="checkout" data-title="Check Out Image">
                        <img src="{{ asset('storage/' . $record->check_out_image) }}" alt="Check Out Image" class="img-fluid rounded shadow-sm" style="max-width: 100%; height: auto;" />
                    </a>
                @else
                    <span class="text-warning">N/A</span>
                @endif
            </div>
        </div>
    </div>
</div>



    </div>

    <style>

  .card-header
{
border-bottom: unset;
}
</style>

@endsection
