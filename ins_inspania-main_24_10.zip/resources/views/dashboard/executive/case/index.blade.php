@extends('dashboard.layout.app')
@section('title', 'Case List')

@section('content')
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h4>Case List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped text-center">
    <thead>
        <tr>
            <th>#</th>
            <th>Company Name</th>
            <th>Customer Name</th>
            <th>Executive Driver</th>
            <th>Executive Garage</th>
            <th>Executive Spot</th>
            <th>Executive Meeting</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
    </thead>

    <tbody>
        @forelse ($cases as $index => $case)
            <tr>
                <td>{{ $cases->firstItem() + $index }}</td>
                <td>{{ $case->company->name ?? '—' }}</td>
                <td>{{ $case->customer->name ?? '—' }}</td>
                <td>{{ $case->driver->name ?? '—' }}</td>
                <td>{{ $case->garage->name ?? '—' }}</td>
                <td>{{ $case->spot->name ?? '—' }}</td>
                <td>{{ $case->meeting->name ?? '—' }}</td>
                <td>
                    @if (!empty($case->date))
                        {{ \Carbon\Carbon::parse($case->date)->format('d-F-Y') }}
                    @else
                        —
                    @endif
                </td>
                <td>
                    <a href="#" class="btn btn-primary btn-sm">
                        <i class="fa fa-eye" aria-hidden="true"></i>
                    </a>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="9" class="text-center text-muted">No cases found.</td>
            </tr>
        @endforelse
    </tbody>
</table>

<div class="d-flex justify-content-end">
    {{ $cases->links() }}
</div>

                </div>                
            </div>
        </div>
    </div>
@endsection
