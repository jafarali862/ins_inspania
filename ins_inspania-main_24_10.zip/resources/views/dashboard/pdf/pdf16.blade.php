<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report - OD Case</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 30px;
            font-size: 14px;
        }

        h3 {
            margin-top: 25px;
            margin-bottom: 10px;
            text-decoration: underline;
        }

        h4 {
            margin-top: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 15px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #f2f2f2;
        }

        ul {
            line-height: 1.6;
            text-align: justify;
            margin: 0;
            padding-left: 20px;
        }

        li {
            margin-bottom: 8px;
        }

        .header {
            display: flex;
            justify-content: flex-end;
        }

        .header img {
            max-height: 60px;
        }

        .title {
            text-align: center;
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
        }

        .signature {
            margin-top: 50px;
            text-align: right;
            font-weight: bold;
        }

        .no-border td {
            border: none !important;
        }
    </style>
</head>

<body>
    <div class="header">
        <h3 style="text-align: center;"> {{$template->insurance_com_name}}</h3>
        <!-- <img src="image.png" alt="Company Logo"> -->

        @if($template->template_logo)
                <img src="{{ public_path('storage/' . $template->template_logo) }}" 
                     alt="Company Logo" 
                     style="max-width: 200px; height: auto; margin-top: 10px;">
            @endif

    </div>
    <hr>
    <div class="title">
        <h3 style="   width: 100%;
    background-color: #943634;
    text-align: center;
    font-weight: 600;
    color: #fff;
    padding: 4px;text-decoration: none;">INVESTIGATION REPORT: OD CASE</h3>
    </div>

    <!-- INTRODUCTION -->
    <h3>I. INTRODUCTION</h3>
    <table>
        <tr>
            <td>1.</td>
            <td>Name of Customer</td>
            <td>Babu</td>
        </tr>
        <tr>
            <td>2.</td>
            <td>Contact Details of Customer</td>
            <td>
                   
                        <br>Phone no:9961242550 <br>Email: samp34@gmail.com</td>
        </tr>

          <tr>
            <td>3.</td>
            <td>Permanent Adress</td>
            <td>Address New</td>
        </tr>

          <tr>
            <td>4.</td>
            <td>Policy No</td>
            <td>12344</td>
        </tr>

        
          <tr>
            <td>5.</td>
            <td>Policy Date</td>
            <td>  2025-08-10 - 

                   2025-08-12</td>
        </tr>

          <tr>
            <td>6.</td>
            <td>Police police_station</td>
            <td>Ernakulam</td>
        </tr>

          <tr>
            <td>7.</td>
            <td>Case Type</td>
            <td>MACT<</td>
        </tr>

          <tr>
            <td>8.</td>
            <td>Investigation Date</td>
            <td>  2025-08-12 

                  </td>
        </tr>

    </table>

    <!-- CASE DETAILS -->
    <h3>II. CASE/CLAIM DETAILS</h3>



       <div id="container" style="margin-top: 25px; text-align: center; margin: 0 auto;">
    <div style="width: 600px; margin: 0 auto;">

        {{-- Group questions by data_category --}}
        @php
            $groupedQuestions = $questions->groupBy('data_category');
            $counter = 1;
        @endphp

        @foreach($groupedQuestions as $category => $categoryQuestions)
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <tr>
                    <th colspan="3" style="text-align: center; background-color: yellow; padding: 10px;">
                        {{ strtoupper(str_replace('_', ' ', $category)) }}
                    </th>
                </tr>

                @foreach($categoryQuestions as $question)
                    @if($question->file_type !== 'image')
                        <tr>
                            <td style="width: 30px; border: 1px solid #000;">{{ $counter++ }}.</td>
                            <td style="width: 300px; border: 1px solid #000;"><strong>{{ $question->question }}</strong></td>
                            <td style="border: 1px solid #000;">
                                @php
                                    $value = $finalReport->{$question->column_name} ?? null;
                                @endphp

                                @if($question->input_type === 'text')
                                    {{ $value ?? 'Sample text answer' }}
                                @elseif($question->input_type === 'select')
                                    {{ $value == 1 ? 'Yes' : 'No' }}
                                @elseif($question->input_type === 'date')
                                    {{ $value ? \Carbon\Carbon::parse($value)->format('d-m-Y') : '05-08-2025' }}
                                @elseif($question->input_type === 'textarea')
                                    {{ $value ?? 'Sample Text Description' }}
                                @else
                                    N/A
                                @endif
                            </td>
                        </tr>
                    @endif
                @endforeach
            </table>
        @endforeach

        {{-- Footer --}}
        <div style="display: flex; justify-content: space-between; margin-top: 30px;">
            <div style="text-align: left;">
            
            <p>Executive Name: Executive6</p>
            <p>{{ \Carbon\Carbon::now()->format('d.m.Y H:i') }}</p>
          
                
            </div>
        </div>

        {{-- Image Questions --}}
        @php $imageCounter = 1; @endphp
           @foreach($questions as $question1)
            @if($question1->file_type === 'image')
                <div style="margin-top: 30px; text-align: center;">
                    <p><strong>{{ $imageCounter++ }}. {{ $question1->question }}</strong></p>
                    <img src="{{ public_path('storage/uploads/0sGvZo9McMzP978qZBOdmH0mXM13aS2SYSHrUY3y.jpg') }}"
                         alt="Image">
                </div>
            @endif
        @endforeach

    </div>
</div>

</body>

</html>

       
   