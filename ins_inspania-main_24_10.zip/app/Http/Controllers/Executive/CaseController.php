<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\CaseAssignment;

class CaseController extends Controller
{
    /**
     * Display a listing of the resource.
     */


public function index()
{
    $userId = Auth::id();

    $cases = CaseAssignment::with([
        'company:id,name',
        'customer:id,name',
        'driver:id,name',
        'garage:id,name',
        'spot:id,name',
        'meeting:id,name'
    ])
    ->where(function ($query) use ($userId) {
        $query->where('executive_driver', $userId)
              ->orWhere('executive_garage', $userId)
              ->orWhere('executive_spot', $userId)
              ->orWhere('executive_meeting', $userId);
    })
    ->paginate(10);

    return view('dashboard.executive.case.index', compact('cases'));
}



    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
