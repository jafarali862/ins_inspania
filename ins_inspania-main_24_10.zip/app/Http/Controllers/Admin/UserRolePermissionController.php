<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;

class UserRolePermissionController extends Controller
{
    public function showAssignForm(Request $request)
    {
        $roles = Role::all();
        $permissions = Permission::with('children')->whereNull('parent_id')->get();

        $selectedRole = null;
        $assignedPermissions = [];

        if ($request->has('role_id')) {
            $selectedRole = Role::with('permissions')->find($request->role_id);
            if ($selectedRole) {
                $assignedPermissions = $selectedRole->permissions->pluck('id')->toArray();
            }
        }

        return view('admin.assign_roles', compact(
            'roles',
            'permissions',
            'selectedRole',
            'assignedPermissions'
        ));
    }

    // Assign/update permissions for a role
    public function assign(Request $request)
    {
        $request->validate([
            'role_id' => 'required|exists:roles,id',
            'permissions' => 'nullable|array',
            'permissions.*' => 'exists:permissions,id',
        ]);

        $role = Role::findOrFail($request->role_id);

        // Sync permissions
        $role->permissions()->sync($request->permissions ?? []);

        return redirect()->back()->with('success', 'Permissions assigned/updated successfully.');
    }
}
