<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\InsuranceCase;
use App\Models\CaseAssignment;
use App\Models\AssignWorkData;
use App\Models\InsuranceCompany;
use App\Models\InsuranceCustomer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;


class InsuranceCustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
       $search = $request->input('search', '');

    $customers = InsuranceCustomer::with(['insuranceCase', 'company'])
        ->when(!empty($search), function ($query) use ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%')
                  ->orWhere('phone', 'like', '%' . $search . '%');
            });
        })
        ->orderBy('created_at', 'desc')
        ->paginate(15);
        
        return view("dashboard.case.index",compact('customers'));
    }

    
    public function view(string $id)
    { 
    $insuranceCustomer = InsuranceCustomer::all();
    $companies = InsuranceCompany::where('status', '!=', 0)->get();
    $users = User::whereNotIn('role', [1, 2])
                 ->where('status', '!=', 0)
                 ->get();

    // Fetch single customer with related data
    $customer = InsuranceCustomer::with([
            'company:id,name',
            'insuranceCase:id,customer_id,case_status,assigned_status,case_details,insurance_type',
            'caseAssignment:id,customer_id,type,date,other,executive_driver,executive_garage,executive_spot,executive_meeting,executive_accident_person,created_at',
            'caseAssignment.driver:id,name',
            'caseAssignment.garage:id,name',
            'caseAssignment.spot:id,name',
            'caseAssignment.meeting:id,name',
            'caseAssignment.accidentPerson:id,name',
        ])
        ->findOrFail($id);

    // Flatten data to look like old query
    $customers = (object)[
        'id' => $customer->id,
        'name' => $customer->name,
        'phone' => $customer->phone,
        'crime_number' => $customer->crime_number,
        'police_station' => $customer->police_station,
        'case_status' => $customer->insuranceCase->case_status ?? null,
        'assigned_status' => $customer->insuranceCase->assigned_status ?? null,
        'case_details' => $customer->insuranceCase->case_details ?? null,
        'ins_type' => $customer->insuranceCase->insurance_type ?? null,
        'custname' => $customer->company->name ?? null,
        'case_type' => $customer->caseAssignment->type ?? null,
        'case_date' => $customer->caseAssignment->date ?? null,
        'case_other' => $customer->caseAssignment->other ?? null,
        'driver_id' => $customer->caseAssignment->driver->id ?? null,
        'garage_id' => $customer->caseAssignment->garage->id ?? null,
        'spot_id' => $customer->caseAssignment->spot->id ?? null,
        'meeting_id' => $customer->caseAssignment->meeting->id ?? null,
        'accident_id' => $customer->caseAssignment->accidentPerson->id ?? null,
        'driver_name' => $customer->caseAssignment->driver->name ?? null,
        'garage_name' => $customer->caseAssignment->garage->name ?? null,
        'spot_name' => $customer->caseAssignment->spot->name ?? null,
        'meeting_name' => $customer->caseAssignment->meeting->name ?? null,
        'accident_name' => $customer->caseAssignment->accidentPerson->name ?? null,
        'created_at' => $customer->caseAssignment->created_at ?? $customer->created_at,
    ];

    return view('dashboard.case.view', compact('customers', 'companies', 'id', 'users', 'insuranceCustomer'));  
    }



  public function markFakeData(Request $request)
{
    try {
        $caseId = $request->input('case_id');

        // Validate case ID
        if (!$caseId) {
            return back()->withErrors(['error' => 'Case ID is required.']);
        }

        $case = CaseAssignment::find($caseId);

        if (!$case) {
            return back()->withErrors(['error' => 'Insurance case not found.']);
        }

        $case->is_fake = true; 
        $case->save();

        return back()->with('success', 'This section has been marked as fake data.');

    } catch (\Exception $e) {
        // Log the exception for debugging
        Log::error('Error marking fake data: ' . $e->getMessage(), [
            'case_id' => $request->input('case_id'),
            'user_id' => auth()->id() ?? 'guest',
        ]);

        // Return a user-friendly error message
        return back()->withErrors(['error' => 'An unexpected error occurred. Please try again later.']);
    }
}



    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $insuranceCustomer = InsuranceCustomer::all();
        $companies = InsuranceCompany::where('status', '!=', 0)->orderBy('id','desc')->get();
        $users = User::where('role', '!=', 1)->where('role', '!=', 2)->where('status', '!=', 0)->get();
        $executives = User::where('role', '!=', 1)->get();
        
        return view("dashboard.insurance.create")->with(["companies" => $companies, "executives" => $executives,"users"=>$users,'insuranceCustomer'=>$insuranceCustomer]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    // ✅ Step 1: Validate input
        $request->validate([
        "company" => "required",
        "name" => "required|string",
        "father_name" => "required|string",
        "phone" => "required|size:10",
        "email" => "required|email",
        "emergency_contact_number" => "required|size:10",
        "present_address" => "required|string",
        "permanent_address" => "required|string",
        "insurance_type" => "required|string",
        "case_details" => "required|string",
        "policy_no" => "required|string",
        "policy_start" => "required|date",
        "policy_end" => "required|date|after_or_equal:policy_start",
        "investigation_type" => "required|string",
        "Default_Executive" => "required|integer",
        "executive_driver" => "required|integer",
        "executive_garage" => "required|integer",
        "executive_spot" => "required|integer",
        "executive_meeting" => "required|integer",
        "country_code" => "required",
        "date" => "required|date",
        "other_details" => "nullable|string",
        "mact_type" => "nullable|string",
        "intimation_report" => "nullable|file|mimes:jpeg,png,jpg,pdf,doc,docx|max:5120",
    ]);

    DB::beginTransaction();

    try {
  
        $intimationReportPath = null;
        if ($request->hasFile('intimation_report')) {
            $file = $request->file('intimation_report');
            $filename = time() . '_' . preg_replace('/\s+/', '_', $file->getClientOriginalName());
            $intimationReportPath = $file->storeAs('uploads/intimation_reports', $filename, 'public');
        }


        $customer = InsuranceCustomer::create([
            'company_id' => $request->company,
            'name' => $request->name,
            'father_name' => $request->father_name,
            'phone' => $request->phone,
            'emergency_contact_number' => $request->emergency_contact_number,
            'email' => $request->email,
            'present_address' => $request->present_address,
            'permanent_address' => $request->permanent_address,
            'status' => 1,
            'create_by' => Auth::id(),
            'update_by' => Auth::id(),
            'policy_no' => $request->policy_no,
            'policy_start' => $request->policy_start,
            'policy_end' => $request->policy_end,
            'insurance_type' => $request->investigation_type,
            'crime_number' => $request->crime_no,
            'police_station' => $request->police_station,
            'intimation_report' => $intimationReportPath,
            'country_code' => $request->country_code,
            'mact_type' => $request->mact_type,
        ]);


        $case = InsuranceCase::create([
            'company_id' => $request->company,
            'customer_id' => $customer->id,
            'insurance_type' => $request->insurance_type,
            'case_details' => $request->case_details,
            'status' => 1,
            'assigned_status' => 1,
            'case_status' => 2,
            'create_by' => Auth::id(),
            'update_by' => Auth::id(),
        ]);

        $caseAssignment = CaseAssignment::create([
            "case_id" => $case->id,
            "company_id" => $request->company,
            "customer_id" => $customer->id,
            "executive_driver" => $request->executive_driver,
            "executive_garage" => $request->executive_garage,
            "executive_spot" => $request->executive_spot,
            "executive_meeting" => $request->executive_meeting,
            "executive_accident_person" => $request->executive_accident_person,
            "date" => $request->date,
            "type" => $request->investigation_type,
            "other" => $request->other_details,
            "status" => 1,
            "case_status" => 1,
            "create_by" => Auth::id(),
            "update_by" => Auth::id(),
        ]);


        AssignWorkData::create([
            "case_id" => $caseAssignment->id,
        ]);

        DB::commit();

        return response()->json([
            'success' => 'New insurance customer added successfully.',
            'redirect_url' => route('case.index'),
        ]);

    } catch (\Throwable $e) {
   
        DB::rollBack();

        Log::error('Error in InsuranceCustomerController@store', [
            'error' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'user_id' => Auth::id(),
            'input' => $request->all(),
        ]);

        return response()->json([
            'error' => 'An unexpected error occurred while saving the data. Please try again later.',
        ], 500);
    }
}

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        
    }

  

public function showAssignForm($customerId)
{
    try {
        // ✅ Load customer with its company in one query
        $insuranceCustomer = InsuranceCustomer::with('company')
            ->findOrFail($customerId);

        // ✅ Fetch company directly from loaded relationship
        $insuranceCompany = $insuranceCustomer->company;

        // ✅ Retrieve active non-admin users (roles != 1 & 2, status = 1)
        $users = User::whereNotIn('role', [1, 2])
            ->where('status', 1)
            ->get();

        // ✅ Fetch insurance case with first() instead of multiple calls
        $case = InsuranceCase::where('customer_id', $customerId)->first();

        // ✅ Retrieve existing assignment if it exists
        $caseAssignment = $case
            ? CaseAssignment::where('case_id', $case->id)->first()
            : null;

        return view('dashboard.assign.create', compact(
            'insuranceCustomer',
            'insuranceCompany',
            'users',
            'case',
            'caseAssignment'
        ));

    } catch (\Throwable $e) {
        // ✅ Log error details
        Log::error('Error showing assign form', [
            'customer_id' => $customerId,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'user_id' => auth()->id(),
        ]);

        // ✅ Optional graceful fallback
        return redirect()->back()->withErrors([
            'error' => 'Unable to load the assignment form. Please try again later.'
        ]);
    }
}


    /**
     * Show the form for editing the specified resource.
     */
   public function edit(string $id)
{
    try {
        // ✅ Eager load related models in one query
        $customerDetails = InsuranceCustomer::with([
            'company',
            'insuranceCase:id,customer_id,case_status,assigned_status,case_details,insurance_type',
            'caseAssignment.driver:id,name',
            'caseAssignment.garage:id,name',
            'caseAssignment.spot:id,name',
            'caseAssignment.meeting:id,name',
            'caseAssignment.accidentPerson:id,name',
        ])->findOrFail($id);

        // ✅ Supporting data
        $companies = InsuranceCompany::where('status', 1)->get(['id', 'name']);
        $users = User::select('id', 'name', 'role','place')
            ->whereNotIn('role', [1, 2])
            ->where('status', 1)
            ->get();

        return view('dashboard.case.edit', compact(
            'customerDetails',
            'companies',
            'users'
        ));

    } catch (\Throwable $e) {
        Log::error('Error loading insurance case edit form', [
            'customer_id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'user_id' => auth()->id(),
        ]);

        return redirect()->back()->withErrors([
            'error' => 'Unable to load the case edit form. Please try again later.'
        ]);
    }
}


    /**
     * Update the specified resource in storage.
     */

public function update(Request $request, $id)
{
    $validator = Validator::make($request->all(), [
        "company" => "required",
        "name" => "required|string|max:255",
        "father_name" => "required|string|max:255",
        "country_code" => "required|string|max:10",
        "phone" => "required|digits_between:10,15",
        "emergency_contact_number" => "required|digits_between:10,15",
        "present_address" => "required|string",
        "permanent_address" => "required|string",
        "insurance_type" => "required|string",
        "case_details" => "required|string",
        'policy_no' => "required|string",
        'policy_start' => "required|date",
        'policy_end' => "required|date|after_or_equal:policy_start",
        'investigation_type' => 'required|string',
        "Default_Executive" => "required|integer",
        "executive_driver" => "required|integer",
        "executive_garage" => "required|integer",
        "executive_spot" => "required|integer",
        "executive_meeting" => "required|integer",
        "date" => "required|date",
        'other' => "nullable|string",
        'intimation_report' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:2048'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'errors' => $validator->errors()
        ], 422);
    }

    DB::beginTransaction();

    try {
        $customer = InsuranceCustomer::findOrFail($id);
        $intimationReportPath = $customer->intimation_report;

        // Handle file upload
        if ($request->hasFile('intimation_report')) {
            $file = $request->file('intimation_report');
            $filename = time() . '_' . $file->getClientOriginalName();
            $newPath = $file->storeAs('uploads/intimation_reports', $filename, 'public');

            // Delete old file if exists
            if ($intimationReportPath && Storage::disk('public')->exists($intimationReportPath)) {
                Storage::disk('public')->delete($intimationReportPath);
            }

            $intimationReportPath = $newPath;
        }

        // ✅ Update Insurance Customer
        $customer->update([
            'company_id' => $request->company,
            'name' => $request->name,
            'father_name' => $request->father_name,
            'country_code' => $request->country_code,
            'phone' => $request->phone,
            'emergency_contact_number' => $request->emergency_contact_number,
            'email' => $request->email,
            'present_address' => $request->present_address,
            'permanent_address' => $request->permanent_address,
            'policy_no' => $request->policy_no,
            'policy_start' => $request->policy_start,
            'policy_end' => $request->policy_end,
            'insurance_type' => $request->investigation_type,
            'crime_number' => $request->crime_no,
            'police_station' => $request->police_station,
            'intimation_report' => $intimationReportPath,
            'mact_type' => $request->mact_type,
            'status' => 1,
            'update_by' => Auth::id(),
        ]);

        // ✅ Update or Create Insurance Case
        InsuranceCase::updateOrCreate(
            ['customer_id' => $id],
            [
                'company_id' => $request->company,
                'insurance_type' => $request->insurance_type,
                'case_details' => $request->case_details,
                'update_by' => Auth::id(),
            ]
        );

        // ✅ Update or Create Case Assignment
        CaseAssignment::updateOrCreate(
            ['customer_id' => $id],
            [
                "executive_driver" => $request->executive_driver,
                "executive_garage" => $request->executive_garage,
                "executive_spot" => $request->executive_spot,
                "executive_meeting" => $request->executive_meeting,
                "executive_accident_person" => $request->executive_accident_person,
                "date" => $request->date,
                "type" => $request->investigation_type,
                "other" => $request->other ?? null,
                "update_by" => Auth::id(),
            ]
        );

        DB::commit();

        return response()->json([
            'success' => true,
            'message' => 'Insurance customer updated successfully.',
            'redirect_url' => route('case.index'),
        ]);

    } catch (\Exception $e) {
        DB::rollBack();

        Log::error('Insurance Case Update Failed', [
            'error' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while updating the insurance case.',
            'error' => $e->getMessage(), 
        ], 500);
    }
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
