<?php

namespace App\Http\Controllers;

use App\Models\GarageData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class GarageUpdateController extends Controller
{
   
   public function updateGarageDatanew(Request $request)
{
    try {
        $selected = $request->input('selected_field');

        if (!$selected || !str_contains($selected, ':')) {
            return back()->withErrors(['error' => 'Please select a garage record to update.']);
        }

        [$fieldName, $garageId] = explode(':', $selected);

        // Sanitize the field name to prevent mass assignment or invalid column updates
        $fieldName = preg_replace('/[^a-zA-Z0-9_]/', '', $fieldName);

        $garage = GarageData::findOrFail($garageId);

        $inputKey = "field_value.$garageId.$fieldName";
        $otherKey = "other_value.$garageId.$fieldName";

        $finalValue = null;

        if ($request->hasFile($inputKey)) {
            $file = $request->file($inputKey);
            $path = $file->store('garage_uploads', 'public');
            $finalValue = $path;
        } elseif ($request->filled($inputKey)) {
            $value = $request->input($inputKey);
            if ($value === 'Other' && $request->filled($otherKey)) {
                $finalValue = $request->input($otherKey);
            } else {
                $finalValue = $value;
            }
        } else {
            return back()->withErrors(['error' => 'No valid input found to update.']);
        }

        $garage->$fieldName = $finalValue;
        $garage->save();

        $tab = $request->input('tab', '');
        return redirect()->back()->withFragment($tab)->with('success', 'Garage Data Updated Successfully!');
    } catch (\Exception $e) {
        // Log the error message
        Log::error('Error updating garage data: ' . $e->getMessage());

        // Return back with a general error message
        return back()->withErrors(['error' => 'An error occurred while updating garage data. Please try again.']);
    }
}


    public function garageSpecialCase($id)
    {
            
    try {
        $accidentData = GarageData::findOrFail($id);
        $accidentData->sp_case = 1;
        $accidentData->save();

        return back()->with('success', 'Garage section data reassigned successfully!');
    } catch (\Exception $e) {
        Log::error('Error in garage SpecialCase', [
            'garage_data_id' => $id,
            'error' => $e->getMessage(),
        ]);

        return back()->withErrors(['error' => 'Something went wrong while reassigning driver data. Please try again.']);
    }
       
    }

   
}
