<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CaseAssignment extends Model
{
    use HasFactory;

    protected $fillable = [
        "case_id",
        "company_id",
        "customer_id",
        "executive_driver",
        "driver_reassign_status",
        "executive_garage",
        "garage_reassign_status",
        "executive_spot",
        "spot_reassign_status",
        "executive_meeting",
        "owner_reassign_status",
        "executive_accident_person",
        "accident_person_reassign_status",
        "date",
        "type",
        "other",
        "status",
        "case_status",
        "create_by",
        "update_by",
    ] ;



    public function case()
    {
    return $this->hasOne(InsuranceCase::class, 'customer_id', 'customer_id');
    }



    public function customer()
    {
    return $this->belongsTo(InsuranceCustomer::class, 'customer_id', 'id');
    }

    public function company()
    {
    return $this->belongsTo(InsuranceCompany::class, 'company_id');
    }


    public function driver()
    {
    return $this->belongsTo(User::class, 'executive_driver');
    }

    public function garage()
    {
    return $this->belongsTo(User::class, 'executive_garage');
    }

    public function spot()
    {
    return $this->belongsTo(User::class, 'executive_spot');
    }

    public function accidentPerson()
    {
    return $this->belongsTo(User::class, 'executive_accident_person');
    }

    public function meeting()
    {
    return $this->belongsTo(User::class, 'executive_meeting');
    }

    public function template()
    {
    return $this->hasOne(Template::class, 'company_id', 'company_id');
    }





    

}
