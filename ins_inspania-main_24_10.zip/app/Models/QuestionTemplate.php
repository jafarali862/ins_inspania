<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionTemplate extends Model
{
    // If your table is named question_template, not question_templates, specify table name
    protected $table = 'question_template';

    // If primary key is "id" and it's auto-increment and timestamps exist, defaults are OK.
    // If timestamps are present, ensure model expects them:
    public $timestamps = true;

    // Define which attributes are mass‐assignable
    protected $fillable = [
        'question_id',
        'template_id',
        // if needed created_at, updated_at etc but usually not
    ];

    // Relations

    /**
     * Get the Question linked to this pivot/template mapping
     */
    public function question()
    {
        return $this->belongsTo(Question::class, 'question_id');
    }

    /**
     * Optionally, if you have a Template model,
     * relation to Template
     */
    public function template()
    {
        return $this->belongsTo(Template::class, 'template_id');
    }
}
