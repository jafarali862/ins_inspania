<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
      protected $fillable = ['name', 'route', 'parent_id', 'icon'];

   public function roles()
    {
        return $this->belongsToMany(Role::class, 'permission_role');
    }

    /** ✅ Parent permission (for nested menus) */
    public function parent()
    {
        return $this->belongsTo(Permission::class, 'parent_id');
    }

    /** ✅ Child permissions (submenus) */
    public function children()
    {
        return $this->hasMany(Permission::class, 'parent_id');
    }
}
